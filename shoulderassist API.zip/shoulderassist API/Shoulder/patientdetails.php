<?php
require("dbh.php");

// Check if the request method is POST and 'patient_id' is set
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['patient_id'])) {
    $patient_id = $_POST['patient_id'];

    try {
        // Prepare a statement to select data
        $stmt = $conn->prepare("SELECT * FROM patientsdetails WHERE patient_id = :patient_id");
        $stmt->bindParam(':patient_id', $patient_id);
        $stmt->execute();

        // Fetch data as an associative array
        $dataRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Check if there are results

        if ($dataRows) {



            foreach ($dataRows as &$row) {
                $profileImage = $row['dp'];
                if (!empty($profileImage) && file_exists($profileImage)) {
                    // Convert the image to base64
                    $base64Image = base64_encode(file_get_contents($profileImage));
                    $row['dp'] = $base64Image;
                } else {
                    // Set a default image or handle the absence of the image
                    $row['dp'] = ''; // You can set a default image here if needed
                }
            }

            foreach ($dataRows as &$row) {
                $profileImage = $row['im'];
                if (!empty($profileImage) && file_exists($profileImage)) {
                    // Convert the image to base64
                    $base64Image = base64_encode(file_get_contents($profileImage));
                    $row['im'] = $base64Image;
                } else {
                    // Set a default image or handle the absence of the image
                    $row['im'] = ''; // You can set a default image here if needed
                }
            }
            // Convert fetched data to JSON format
            $jsonResponse = json_encode($dataRows);

            // Output the JSON response
            header('Content-Type: application/json');

            echo $jsonResponse;
        } else {
            // Handle if no data found for the provided patient_id
            echo "No data found for the patient ID: $patient_id";
        }
    } catch (PDOException $e) {
        // Handle PDO errors
        echo "Error: " . $e->getMessage();
    }
} else {
    // Handle if 'patient_id' is not set in the POST request or if it's not a POST request
    echo "Patient ID not found in the request or invalid request method";
}
?>
