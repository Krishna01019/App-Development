<?php
require("dbh.php");

$response = array();

if (isset($_POST["patient_id"])) {
    $patient_id = $_POST["patient_id"];

    $sql = "SELECT patient_id, im AS image FROM patientsdetails WHERE patient_id = :patient_id";
    
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':patient_id', $patient_id);
    $stmt->execute();

    $images = array();

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        // Store the image details in an array
        $imageDetails = array(
            'patient_id' => $row['patient_id'],
            'image' => $row['image']
        );

        // Add the image details to the images array
        $images[] = $imageDetails;
    }

    if (!empty($images)) {
        // If images are found, set success response with image data
        $response['status'] = 'success';
        $response['message'] = 'Images retrieved successfully.';
        $response['data'] = $images;
    } else {
        // If no images are found, set error response
        $response['status'] = 'error';
        $response['message'] = 'No images found for the given patient_id.';
    }
} else {
    // If patient_id is not provided, set error response
    $response['status'] = 'error';
    $response['message'] = 'Invalid request.';
}

// Output the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
