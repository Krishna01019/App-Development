<?php
// Include the database connection file
include 'conn.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from POST
    $id = $_POST['id'];
    $yes_no = $_POST['yes_no'];
    $feedback = $_POST['feedback'];
    $date = $_POST['date'];

    // Prepare the SQL statement
    $sql = "INSERT INTO feedback VALUES ('$id','$yes_no','$feedback','$date')";

    // Execute the statement
    if ($conn->query($sql) === TRUE) {
        $response = array(
            "status" => "success",
            "message" => "Data inserted successfully"
        );
    } else {
        $response = array(
            "status" => "error",
            "message" => "Error: " . $conn->error
        );
    }

    // Close connection
    $conn->close();

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    // If the form is not submitted via POST method
    $response = array(
        "status" => "error",
        "message" => "Form submission method not allowed"
    );
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
