<?php
// Include database connection
include("dbh.php");

$response = array(); // Initialize an array to hold the response data

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming you receive the necessary parameters in the POST request
    // Adjust these as per your form or JSON payload
    $patient_id = $_POST['patient_id'];
    $name = $_POST['name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $phone_number = $_POST['phone_number'];
    $admitted_on = $_POST['admitted_on'];
    $diagnosis = $_POST['diagnosis'];
    $examination = $_POST['examination'];
    $brief_history = $_POST['brief_history'];
    
    

    try {
        // Update user table with the last four digits of patient_id as password
        $password = substr($patient_id, -4);
        $sqlUpdateUser = "UPDATE patient_login SET password = :password WHERE patient_id = :patient_id";
        $userUpdateStmt = $conn->prepare($sqlUpdateUser);
        $userUpdateStmt->bindParam(':password', $password);
        $userUpdateStmt->bindParam(':patient_id', $patient_id);
        if ($userUpdateStmt->execute()) {
            $response['user_password_updated'] = true;
        } else {
            $response['user_password_updated'] = false;
            $response['error_updating_user_password'] = $userUpdateStmt->errorInfo();
        }

        // Insert into user table
        $sqlInsertUser = "INSERT INTO patient_login (patient_id, password) VALUES (:patient_id, :password)";
        $userStmt = $conn->prepare($sqlInsertUser);
        $userStmt->bindParam(':patient_id', $patient_id);
        $userStmt->bindParam(':password', $password);
        if ($userStmt->execute()) {
            $response['user_inserted'] = true;
        } else {
            $response['user_inserted'] = false;
        $response['error_inserting_user'] = $userStmt->errorInfo();
        }



        // Insert into addpatient table
        $sqlInsertAddPatient = "
        INSERT INTO addpatient (patient_id, name, age, gender, phone_number, admitted_on, diagnosis, examination, brief_history)
        VALUES (:patient_id, :name, :age, :gender, :phone_number,:admitted_on, :diagnosis, :examination, :brief_history)
        ";
        $addPatientStmt = $conn->prepare($sqlInsertAddPatient);
        $addPatientStmt->bindParam(':patient_id', $patient_id);
        $addPatientStmt->bindParam(':name', $name);
        $addPatientStmt->bindParam(':age', $age);
        $addPatientStmt->bindParam(':gender', $gender);
        $addPatientStmt->bindParam(':phone_number', $phone_number);
        $addPatientStmt->bindParam(':admitted_on', $admitted_on);
        $addPatientStmt->bindParam(':diagnosis', $diagnosis);
        $addPatientStmt->bindParam(':examination', $examination);
        $addPatientStmt->bindParam(':brief_history', $brief_history);
       

        if ($addPatientStmt->execute()) {
            $response['addpatient_inserted'] = true;
        } else {
            $response['addpatient_inserted'] = false;
            $response['error_inserting_addpatient'] = $addPatientStmt->errorInfo();
        }


         // Insert into patientsdetails table
         $sqlInsertPatientsDetails = "
         INSERT INTO patientsdetails (patient_id, name, age, gender, phone_number, admitted_on, diagnosis, examination, brief_history)
         VALUES (:patient_id, :name, :age, :gender, :phone_number,:admitted_on, :diagnosis, :examination, :brief_history)
         ";
         $patientsDetailsStmt = $conn->prepare($sqlInsertPatientsDetails);
         $patientsDetailsStmt->bindParam(':patient_id', $patient_id);
         $patientsDetailsStmt->bindParam(':name', $name);
         $patientsDetailsStmt->bindParam(':age', $age);
         $patientsDetailsStmt->bindParam(':gender', $gender);
         $patientsDetailsStmt->bindParam(':phone_number', $phone_number);
         $patientsDetailsStmt->bindParam(':admitted_on', $admitted_on);
         $patientsDetailsStmt->bindParam(':diagnosis', $diagnosis);
         $patientsDetailsStmt->bindParam(':examination', $examination);
         $patientsDetailsStmt->bindParam(':brief_history', $brief_history);
         
 
         if ($patientsDetailsStmt->execute()) {
             $response['patientsdetails_inserted'] = true;
         } else {
             $response['patientdetails_inserted'] = false;
             $response['error_inserting_patientdetails'] = $patientsDetailsStmt->errorInfo();
         }
 


        // Insert into p_profile table
        $sqlInsertPProfile = "
        INSERT INTO p_profile (patient_id, name, age, gender, phone_number)
        VALUES (:patient_id, :name, :age, :gender, :phone_number)
        ";
        $pProfileStmt = $conn->prepare($sqlInsertPProfile);
        $pProfileStmt->bindParam(':patient_id', $patient_id);
        $pProfileStmt->bindParam(':name', $name);
        $pProfileStmt->bindParam(':age', $age);
        $pProfileStmt->bindParam(':gender', $gender);
        $pProfileStmt->bindParam(':phone_number', $phone_number);

        if ($pProfileStmt->execute()) {
            $response['p_profile_inserted'] = true;
        } else {
            $response['p_profile_inserted'] = false;
            $response['error_inserting_p_profile'] = $pProfileStmt->errorInfo();
        }

        
    } catch (PDOException $e) {
        $response['error'] = true;
        $response['message'] = $e->getMessage();
    }
} else {
    $response['error'] = true;
    $response['message'] = "Invalid request method";
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);