<?php
require("dbh.php");

$response = array();

$sql = "SELECT patient_id, name, dp AS image FROM patientsdetails";
    
$stmt = $conn->prepare($sql);
$stmt->execute();

$images = array();

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    // Store the image details in an array
    $imageDetails = array(
        'patient_id' => $row['patient_id'],
        'name' => $row['name'],
        'image' => $row['image']
    );

    // Add the image details to the images array
    $images[] = $imageDetails;
}

if (!empty($images)) {
    // If images are found, set success response with image data
    $response['status'] = 'success';
    $response['message'] = 'Images retrieved successfully.';
    $response['data'] = $images;
} else {
    // If no images are found, set error response
    $response['status'] = 'error';
    $response['message'] = 'No images found in the patientsdetails table.';
}

// Output the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
