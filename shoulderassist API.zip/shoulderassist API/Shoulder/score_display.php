<?php
// Database connection details
require("dbh.php");

// Initialize response array
$response = array();

// Extract data from the POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required fields are set
    if (isset($_POST['patient_id'])) {
        // Sanitize and validate the input data
        $patient_id = htmlspecialchars($_POST['patient_id']);
        $date = htmlspecialchars($_POST['date']);
        // Retrieve data from the database
        $sql = "SELECT date, total_score FROM score WHERE patient_id = ? AND date = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$patient_id,$date]);

        // Check if there are rows returned
        if ($stmt->rowCount() > 0) {
            // Initialize an array to store the retrieved data
            $data = array();

            // Fetch data and store it in the array
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $data[] = array(
                    "date" => $row['date'],
                    "total_score" => $row['total_score']
                );
            }

            // Set success response
            $response['status'] = 'success';
            $response['data'] = $data;
        } else {
            // No data found
            $response['status'] = 'error';
            $response['message'] = 'No scores found for the specified patient ID';
        }
    } else {
        // Required fields not set
        $response['status'] = 'error';
        $response['message'] = 'Missing required fields';
    }
} else {
    // Request method is not POST
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method';
}

// Encode response to JSON format and echo it
echo json_encode($response);

// Close statement and database connection
$stmt = null;
$conn = null;
?>
