<?php
require("conn.php");

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Check connection
    if ($conn->connect_error) {
        $response = array(
            'status' => false,
            'message' => 'Connection failed: ' . $conn->connect_error,
            'data' => null
        );
    } else {
        // Query to get video URLs and titles
        $sql = "SELECT video1, video_title FROM videos1";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $videosArray = array();

            // Fetch all rows and store in an array
            while ($row = $result->fetch_assoc()) {
                $videoItem = array(
                    'url' => $row['video1'],
                    'title' => $row['video_title']
                );
                $videosArray[] = $videoItem;
            }

            $response = array(
                'status' => true,
                'message' => 'Videos found',
                'data' => $videosArray
            );
        } else {
            $response = array(
                'status' => true,
                'message' => 'No videos found',
                'data' => null
            );
        }

        $conn->close();
    }

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    echo "Invalid request";
}
?>
