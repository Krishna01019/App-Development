<?php
// Database connection details
require("conn.php");

$uploadDir = "videos/";

$response = array();

try {
    // Check if the request method is POST and required fields are set
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['uploaded_file']) && isset($_POST['video_title'])) {
        // Extract data from the request
        $file = $_FILES['uploaded_file'];
        $fileName = basename($file['name']);
        $uploadPath = $uploadDir . $fileName;
        $videoTitle = $_POST['video_title'];

        // Move uploaded file to destination directory
        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            // Prepare SQL statement for updating videos table
            $sql_videos = "INSERT INTO videos (video_title, video) VALUES ('$videoTitle', '$uploadPath') 
                               ON DUPLICATE KEY UPDATE video = '$uploadPath', video_title = '$videoTitle'";

            // Execute SQL statement for videos table
            $result_videos = $conn->query($sql_videos);

            // Check if the query was successful
            if ($result_videos === TRUE) {
                $response = array(
                    "status" => true,
                    "message" => "Video information updated successfully"
                );
            } else {
                $response = array(
                    "status" => false,
                    "message" => "Error updating video information: " . $conn->error
                );
            }
        } else {
            $response = array(
                "status" => false,
                "message" => "Error uploading the file"
            );
        }
    } else {
        $response = array(
            "status" => false,
            "message" => "Invalid request"
        );
    }
} catch (Exception $e) {
    $response = array(
        "status" => false,
        "message" => "Error: " . $e->getMessage()
    );
}

// Encode response to JSON format and echo it
echo json_encode($response);

// Close database connection
$conn->close();
?>
