<?php
// Database connection parameters
require("conn.php");

// Check if ID and data are sent from the frontend
if(isset($_POST['id']) && isset($_POST['data'])) {
    // Extract ID and data from the POST request
    $id = $_POST['id'];
    $data = $_POST['data'];

    // Create connection
    

    // Check connection
  

    // Escape special characters to prevent SQL injection
    $id = $conn->real_escape_string($id);
    $data = $conn->real_escape_string($data);

    // Query to get total score from Questionaries table based on ID
    $sql = "SELECT total_sum from questionaries where patient_id = '$id' and  date='$data'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            $total_score = $row['total_sum'];
            $response = array(
                "status" => "success",
                "total_score" => $total_score
            );
            header('Content-Type: application/json');
            echo json_encode($response);
        }
    } else {
        $response = array(
            "status" => "error",
            "message" => "No data found for the provided ID."
        );
        header('Content-Type: application/json');
        echo json_encode($response);
    }

    // Close connection
    $conn->close();
} else {
    $response = array(
        "status" => "error",
        "message" => "ID and data not provided from frontend."
    );
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
