<?php
require("dbh.php");

$response = array();

if (isset($_POST["patient_id"]) && isset($_FILES["image"])) {
    $patient_id = $_POST["patient_id"];
    $fileName = $_FILES["image"]["name"];
    $tempName = $_FILES["image"]["tmp_name"];
    $folder = "image/" . $fileName;

    // Retrieve the current image path for the patient_id from the database
    $sql_select = "SELECT im FROM patientsdetails WHERE patient_id = :patient_id";
    $stmt_select = $conn->prepare($sql_select);
    $stmt_select->bindParam(':patient_id', $patient_id);
    $stmt_select->execute();
    $current_image_path = $stmt_select->fetchColumn();

    if (move_uploaded_file($tempName, $folder)) {
        // Check if there's already an existing image path
        if ($current_image_path) {
            // If there's an existing image path, delete the old file
            unlink($current_image_path);
        }

        // Update the image path in the database
        $sql_update = "UPDATE patientsdetails SET dp = :folder WHERE patient_id = :patient_id";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bindParam(':folder', $folder);
        $stmt_update->bindParam(':patient_id', $patient_id);

        if ($stmt_update->execute()) {
            $response['status'] = 'success';
            $response['message'] = 'Data updated successfully.';
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Data not updated. Error: ' . $stmt_update->errorInfo()[2];
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'File upload failed.';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request.';
}

header('Content-Type: application/json');
echo json_encode($response);
?>
