<?php
require("conn.php");

// Check if all required parameters are set
if(isset($_POST["patient_id"], $_POST["date"])) {
    // Retrieve parameters from POST
    $patient_id = $_POST["patient_id"];
    $date = $_POST["date"];

    // SQL query to retrieve data based on patient_id and date
    $sql = "SELECT feedback, range_of_movement, stretches, strengthening_exercise FROM daily_task WHERE patient_id = ? AND date = ?";

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);

    if($stmt) {
        // Bind parameters and execute the statement
        $stmt->bind_param("ss", $patient_id, $date);
        if ($stmt->execute()) {
            // Bind result variables
            $stmt->bind_result($feedback, $range_of_movement, $stretches, $strengthening_exercise);
            
            // Fetch result
            $stmt->fetch();

            // Prepare response
            $response = array(
                "status" => "success",
                "data" => array(
                    "feedback" => $feedback,
                    "range_of_movement" => $range_of_movement,
                    "stretches" => $stretches,
                    "strengthening_exercise" => $strengthening_exercise
                )
            );
        } else {
            $response = array(
                "status" => "error",
                "message" => "Error executing query: " . $stmt->error
            );
        }

        // Close statement
        $stmt->close();
    } else {
        $response = array(
            "status" => "error",
            "message" => "Error preparing statement: " . $conn->error
        );
    }
} else {
    $response = array(
        "status" => "error",
        "message" => "Missing parameters. Please provide all required parameters."
    );
}

// Close connection
$conn->close();

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
