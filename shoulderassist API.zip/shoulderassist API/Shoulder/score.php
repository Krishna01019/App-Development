<?php
// Database connection details
require("dbh.php");

// Extract data from the POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required fields are set
    if (isset($_POST['patient_id']) && isset($_POST['date']) && isset($_POST['total_score'])) {
        // Sanitize and validate the input data
        $patient_id = htmlspecialchars($_POST['patient_id']);
        $date = htmlspecialchars($_POST['date']);
        $total_score = htmlspecialchars($_POST['total_score']);

        // Insert data into the database
        $sql = "INSERT INTO score (patient_id, date, total_score) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$patient_id, $date, $total_score]);

        if ($stmt->rowCount() > 0) {
            // Data insertion successful
            $response = array(
                "status" => "success",
                "message" => "Patient score data inserted successfully"
            );
        } else {
            // Error in data insertion
            $errorInfo = $stmt->errorInfo();
            $response = array(
                "status" => "error",
                "message" => "Error inserting patient score data: " . $errorInfo[2]
            );
        }
    } else {
        // Required fields not set
        $response = array(
            "status" => "error",
            "message" => "Missing required fields"
        );
    }
} else {
    // Request method is not POST
    $response = array(
        "status" => "error",
        "message" => "Invalid request method"
    );
}

// Encode response to JSON format and echo it
echo json_encode($response);

// Close statement and database connection
$stmt = null;
$conn = null;
?>
