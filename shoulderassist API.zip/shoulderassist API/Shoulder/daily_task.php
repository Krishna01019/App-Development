<?php
require("conn.php");

// Check if all required parameters are set
if(isset($_POST["patient_id"], $_POST["date"], $_POST["range_of_movement"], $_POST["stretches"], $_POST["strengthening_exercise"], $_POST["feedback"])) {
    // Sample data for insertion
    $patient_id = $_POST["patient_id"];
    $date = $_POST["date"];
    $range_of_movement = $_POST["range_of_movement"];
    $stretches =  $_POST["stretches"];
    $strengthening_exercise = $_POST["strengthening_exercise"];
    $feedback = $_POST["feedback"]; // New parameter for feedback

    // SQL query to insert data into the table using prepared statements
    $sql = "INSERT INTO daily_task (patient_id, date, range_of_movement, stretches, strengthening_exercise, feedback) VALUES (?, ?, ?, ?, ?, ?)";

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);

    if($stmt) {
        // Bind parameters and execute the statement
        $stmt->bind_param("ssssss", $patient_id, $date, $range_of_movement, $stretches, $strengthening_exercise, $feedback);
        if ($stmt->execute()) {
            $response = array(
                "status" => "success",
                "message" => "Data inserted successfully"
            );
        } else {
            $response = array(
                "status" => "error",
                "message" => "Error executing query: " . $stmt->error
            );
        }

        // Close statement
        $stmt->close();
    } else {
        $response = array(
            "status" => "error",
            "message" => "Error preparing statement: " . $conn->error
        );
    }
} else {
    $response = array(
        "status" => "error",
        "message" => "Missing parameters. Please provide all required parameters."
    );
}

// Close connection
$conn->close();

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
