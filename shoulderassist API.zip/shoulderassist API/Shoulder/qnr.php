<?php
// Database connection parameters
require("conn.php");

// Extract values from POST
$patient_id = $_POST['patient_id'];
$date = $_POST['date'];
$values = array();
for ($i = 1; $i <= 13; $i++) {
    $values[$i] = $_POST[$i];
}

// Prepare the values for insertion
$patient_id = $conn->real_escape_string($patient_id);
$date = $conn->real_escape_string($date);



// SQL query to insert data into the table
$sql = "INSERT INTO questionaries (`patient id`, `date`, `1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`, `9`, `10`, `11`, `12`, `13`)
        VALUES ('$patient_id', '$date', '$values[1]','$values[2]','$values[3]','$values[4]','$values[5]','$values[6]','$values[7]','$values[8]','$values[9]','$values[10]','$values[11]','$values[12]','$values[13]')";

if ($conn->query($sql) === TRUE) {
    $response = array(
        "status" => "success",
        "message" => "Data inserted successfully"
    );
} else {
    $response = array(
        "status" => "error",
        "message" => "Error: " . $sql . "<br>" . $conn->error
    );
}

// Close connection
$conn->close();

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
