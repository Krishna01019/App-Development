<?php
// Include database connection
include("dbh.php");

$response = array(); // Initialize an array to hold the response data

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming you receive the necessary parameters in the POST request
    // Adjust these as per your form or JSON payload
    $patient_id = $_POST['patient_id'];
    $name = $_POST['name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $phone_number = $_POST['phone_number'];
    $admitted_on = $_POST['admitted_on'];
    $diagnosis = $_POST['diagnosis'];
    $examination = $_POST['examination'];
    $brief_history = $_POST['brief_history'];
    
    

    try {
        
         // Insert into patientsdetails table
         $sqlInsertPatientsDetails = "
         UPDATE patientsdetails
SET name = :name,
    age = :age,
    gender = :gender,
    phone_number = :phone_number,
    admitted_on = :admitted_on,
    diagnosis = :diagnosis,
    examination = :examination,
    brief_history = :brief_history
WHERE patient_id = :patient_id;

         ";
         $patientsDetailsStmt = $conn->prepare($sqlInsertPatientsDetails);
         $patientsDetailsStmt->bindParam(':patient_id', $patient_id);
         $patientsDetailsStmt->bindParam(':name', $name);
         $patientsDetailsStmt->bindParam(':age', $age);
         $patientsDetailsStmt->bindParam(':gender', $gender);
         $patientsDetailsStmt->bindParam(':phone_number', $phone_number);
         $patientsDetailsStmt->bindParam(':admitted_on', $admitted_on);
         $patientsDetailsStmt->bindParam(':diagnosis', $diagnosis);
         $patientsDetailsStmt->bindParam(':examination', $examination);
         $patientsDetailsStmt->bindParam(':brief_history', $brief_history);
         
 
         if ($patientsDetailsStmt->execute()) {
             $response['patientsdetails_inserted'] = true;
         } else {
             $response['patientdetails_inserted'] = false;
             $response['error_inserting_patientdetails'] = $patientsDetailsStmt->errorInfo();
         }
 


        

        
    } catch (PDOException $e) {
        $response['error'] = true;
        $response['message'] = $e->getMessage();
    }
} else {
    $response['error'] = true;
    $response['message'] = "Invalid request method";
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);