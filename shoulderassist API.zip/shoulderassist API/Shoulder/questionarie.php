<?php

include("dbh.php");

// SQL query to retrieve data
$sql = "SELECT `Question_id`, `Questions`, `option1`, `option2`, `option3`, `option4`, `option5` FROM `questionaries`";

// Execute the query
$result = $conn->query($sql);

// Check if the query was successful
if ($result !== false) {
    // Check if there are rows in the result set
    if ($result->rowCount() > 0) {
        // Fetch data and store it in an array
        $data = array();

        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            // Create a new array for each question
            $questionArray = array(
                "Question_id" => $row["Question_id"],
                "Questions" => $row["Questions"],
                "Options" => array(
                    $row["option1"],
                    $row["option2"],
                    $row["option3"],
                    $row["option4"],
                    $row["option5"]
                )
            );

            // Add the question array to the main data array
            $data[] = $questionArray;
        }

        // Convert data array to JSON
        $jsonResponse = json_encode($data);

        // Output JSON response
        header('Content-Type: application/json');
        echo $jsonResponse;
    } else {
        // Output JSON response for no records found
        echo json_encode(["message" => "No records found."]);
    }
} else {
    // Output JSON response for error
    echo json_encode(["error" => "Error: " . $sql . "<br>" . $conn->errorInfo()[2]]);
}

// Close the connection
$conn = null;
?>
