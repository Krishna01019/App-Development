<?php
// Include the database connection configuration
require("dbh.php");

// Create an associative array to hold the API response
$response = array();

try {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // SQL query to fetch patient information
        $sql = "SELECT patient_id, name,dp FROM patientsdetails";

        // Prepare the SQL query
        $stmt = $conn->prepare($sql);

        // Execute the query
        $stmt->execute();

        // Fetch all rows as an associative array
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($data as $row) {
            // Retrieve profile image path from the row
            $profileImage = $row['dp'];
            
            if (!empty($profileImage) && file_exists($profileImage)) {
                // Convert the image to base64
                $base64Image = base64_encode(file_get_contents($profileImage));
                $row['dp'] = $base64Image;
            } else {
                // Set a default image or handle the absence of the image
                $row['dp'] = ''; // You can set a default image here if needed
            }
            
            // Add modified row to the patient list array
            $patientList[] = $row;
        }

        if (count($data) > 0) {
            $response['success'] = true;
            $response['data'] = $patientList;
        } else {
            $response['success'] = false;
            $response['message'] = "0 results";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Invalid request method. Only POST requests are allowed.";
    }
} catch (Exception $e) {
    // Handle any exceptions
    $response['success'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

// Convert the response array to JSON and echo it
header('Content-Type: application/json');
echo json_encode($response);

// Close the statement and database connection
$stmt = null;
$conn = null;
?>
