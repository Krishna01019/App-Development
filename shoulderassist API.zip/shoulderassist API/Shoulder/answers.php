<?php

include("dbh.php"); // Include your database connection file

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the necessary fields are set in the POST request
    if (isset($_POST['patient_id']) && isset($_POST['question_id']) && isset($_POST['selected_option'])) {
        // Assign the POST data to variables
        $patient_id = $_POST['patient_id'];
        $question_id = $_POST['question_id'];
        $new_marks = $_POST['selected_option']; // Assuming new_marks represent the marks obtained in the latest question

        try {
            // Retrieve existing marks for the patient and question
            $retrieve_sql = "SELECT selected_option FROM answers WHERE patient_id = :patient_id AND question_id = :question_id";
            $retrieve_stmt = $conn->prepare($retrieve_sql);
            $retrieve_stmt->bindParam(':patient_id', $patient_id);
            $retrieve_stmt->bindParam(':question_id', $question_id);
            $retrieve_stmt->execute();

            // If a record exists, update the marks, else insert a new record
            if ($retrieve_stmt->rowCount() > 0) {
                $row = $retrieve_stmt->fetch(PDO::FETCH_ASSOC);
                $existing_marks = $row['marks'];
                $new_total_marks = $existing_marks + $new_marks;

                // Update marks in the database
                $update_sql = "UPDATE answers SET marks = :new_total_marks WHERE patient_id = :patient_id AND question_id = :question_id";
                $stmt = $conn->prepare($update_sql);
                $stmt->bindParam(':new_total_marks', $new_total_marks);
                $stmt->bindParam(':patient_id', $patient_id);
                $stmt->bindParam(':question_id', $question_id);
                $stmt->execute();

                echo "Marks updated successfully";
            } else {
                // Insert new record with marks
                $insert_sql = "INSERT INTO answers (patient_id, question_id, selected_option) VALUES (:patient_id, :question_id, :new_marks)";
                $stmt = $conn->prepare($insert_sql);
                $stmt->bindParam(':patient_id', $patient_id);
                $stmt->bindParam(':question_id', $question_id);
                $stmt->bindParam(':new_marks', $new_marks);
                $stmt->execute();

                echo "New marks inserted successfully";
            }
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }

        // Close connection
        $conn = null;
    } else {
        // Handle case where required fields are not set
        echo "Error: Required fields not set.";
    }
} else {
    // Handle case where request method is not POST
    echo "Error: Only POST requests are allowed.";
}
?>
