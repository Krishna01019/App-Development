package com.example.shoulder;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class today_task_patient extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_today_task_patient);

        Button bt1 = findViewById(R.id.bt1);
        bt1.setOnClickListener(view -> {
            Intent it = new Intent(this, upld1.class);
            startActivity(it);
        });
        Button bt2 = findViewById(R.id.bt2);
        bt2.setOnClickListener(view -> {
            Intent it = new Intent(this, upld2.class);
            startActivity(it);
        });
        Button bt3 = findViewById(R.id.bt3);
        bt3.setOnClickListener(view -> {
            Intent it = new Intent(this, upld3.class);
            startActivity(it);
        });


    }
}