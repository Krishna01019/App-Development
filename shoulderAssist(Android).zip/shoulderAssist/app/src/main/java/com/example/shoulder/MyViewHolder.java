package com.example.shoulder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolder extends RecyclerView.ViewHolder {
    ImageView imageviewone;
    TextView  textviewone,textviewtwo;

    public MyViewHolder(@NonNull View itemView) {
        super(itemView);
        imageviewone = itemView.findViewById(R.id.imageviewone);
        textviewone = itemView.findViewById(R.id.textviewone);
        textviewtwo = itemView.findViewById(R.id.textviewtwo);

    }
}
