package com.example.shoulder;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class daily_progress extends AppCompatActivity {

    private String username,Date,fd,c1,c2,c3;
    private EditText efd;
    private CalendarView calendar;
    private RadioButton q1y,q1n,q2y,q2n,q3y,q3n;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_daily_progress);
        username = getIntent().getStringExtra("username");
        q1y=findViewById(R.id.dyes1);
        q1n=findViewById(R.id.dno1);
        q2y=findViewById(R.id.dyes11);
        q2n=findViewById(R.id.dno12);
        q3y=findViewById(R.id.dyes111);
        q3n=findViewById(R.id.dno122);
        efd = findViewById(R.id.fd);

        calendar = (CalendarView)
                findViewById(R.id.calendarView);


        // Add Listener in calendar
        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override

            // In this Listener have one method
            // and in this method we will
            // get the value of DAYS, MONTH, YEARS
            public void onSelectedDayChange(
                    @NonNull CalendarView view,
                    int year,
                    int month,
                    int dayOfMonth)
            {

                // Store the value of date with
                // format in String type Variable
                // Add 1 in month because month
                // index is start with 0
                Date
                        =  year+ "-"
                        + (month + 1) + "-" + dayOfMonth;

                // set this date in TextView for Display
                //date_view.setText(Date);
            }
        });

        Button bt = findViewById(R.id.bt);
        bt.setOnClickListener(view -> {
            fd=efd.getText().toString().trim();
            if(q1y.isChecked()){
                c1="yes";
            } else if (q1n.isChecked()) {
                c1="no";
            }
            if(q2y.isChecked()){
                c2="yes";
            } else if (q2n.isChecked()) {
                c2="no";
            }
            if(q3y.isChecked()){
                c3="yes";
            } else if (q3n.isChecked()) {
                c3="no";
            }
            sendLoginRequest(username,Date);

        });

    }

    private void sendLoginRequest(final String username,final String date) {
        String URL = ip.ipn+"daily_task.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleResponse(response,username);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleError(error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Send the username and password as POST parameters
                Map<String, String> data = new HashMap<>();

                data.put("patient_id", username);
                data.put("date", date);
                data.put("range_of_movement", c1);
                data.put("stretches", c2);
                data.put("strengthening_exercise", c3);
                data.put("feedback", fd);



                return data;
            }
        };

        // Customize the retry policy
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        // Initialize the Volley request queue and add the request
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    // Handle the JSON response
    private void handleResponse(String response, String username) {
        Log.d("JSON Response", response);

        try {
            JSONObject jsonObject = new JSONObject(response);
            String status = jsonObject.getString("status");

            if (status.equals("success")) {
                Toast.makeText(this, "Data inserted successfully!!!", Toast.LENGTH_SHORT).show();
                Intent it = new Intent(this, patientdashboard.class);
                it.putExtra("username",username);
                startActivity(it);

            }
            else{

            }
        } catch (JSONException e) {

            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }




    private void handleError(VolleyError error) {
        System.out.println("boooooo");
    }
}