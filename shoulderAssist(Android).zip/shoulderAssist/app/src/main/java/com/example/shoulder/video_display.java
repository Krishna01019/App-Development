package com.example.shoulder;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class video_display extends AppCompatActivity {
    private String url;
    private VideoView videoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.video_display);
        url = getIntent().getStringExtra("url");
        videoView=findViewById(R.id.videoView);
        System.out.println(url);
        playVideo(ip.ipn+url);
    }
    private void playVideo(String videoPath) {
        MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(videoView);

        videoView.setMediaController(mediaController);
        videoView.setVideoPath(videoPath);
        videoView.requestFocus();
        videoView.start();
    }
}