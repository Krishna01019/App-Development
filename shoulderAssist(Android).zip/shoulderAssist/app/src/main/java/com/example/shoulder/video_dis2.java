package com.example.shoulder;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class video_dis2 extends AppCompatActivity {

    private List<Video> patientList;
    private ListView gridView;

    private videoAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.video_dis2);
        gridView = findViewById(R.id.Listview);
        patientList = new ArrayList<>();

        adapter = new videoAdapter(this, patientList);
        gridView.setAdapter(adapter);

        // Set item click listener to open pat_view activity with selected patient details
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Video selectedPatient = patientList.get(position);
                Intent intent = new Intent(video_dis2.this, video_display.class);
                intent.putExtra("name", selectedPatient.getName());
                intent.putExtra("url", selectedPatient.geturl());
                startActivity(intent);
            }
        });

        String url = ip.ipn +"display1.php";
        makeRequest(url);
    }
    private void makeRequest(String url) {
        StringRequest stringRequest = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        System.out.println(response);
                        Log.d("Volley Response", response);
                        parseResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volley Error", error.toString());
                        Toast.makeText(video_dis2.this, "Error fetching data", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void parseResponse(String response) {
        Log.d("JSON Response", response);

        try {
            JSONObject jsonResponse = new JSONObject(response);
            JSONArray data = jsonResponse.getJSONArray("data");

            // Ensure there is data in the response
            if (data.length() > 0) {
                // Clear existing data
                patientList.clear();

                // Iterate through the data array and add patients to the list
                for (int i = 0; i < data.length(); i++) {
                    JSONObject patientObject = data.getJSONObject(i);
                    String patientId = patientObject.getString("url");
                    String name = patientObject.getString("title");
//                    String age = patientObject.getString("pat_age");
//                    String dp = patientObject.getString("dp");

                    // Add the patient to the list
                    patientList.add(new Video(name, patientId));
                }

                // Notify the adapter that the data set has changed
                adapter.notifyDataSetChanged();
            } else {
                // Handle case where there is no data in the response
                Log.e("Handle Response", "No data in the response");
            }
        } catch (JSONException e) {
            e.printStackTrace();
            // Handle JSON parsing error
            Log.e("Handle Response", "Error parsing JSON response: " + e.getMessage());
        }
    }
}