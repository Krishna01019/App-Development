package com.example.shoulder;

public class Video {

    private String name,url;



    public Video(String name,  String user) {
        this.name = name;
        this.url = user;
        //this.dp=dp;

    }

    public String getName() {
        return name;
    }
    public String geturl() {
        return url;
    }
}
