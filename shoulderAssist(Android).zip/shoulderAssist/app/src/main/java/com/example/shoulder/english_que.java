package com.example.shoulder;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class english_que extends AppCompatActivity {

    private TextView rs;
    private RadioButton q1c1, q1c2, q1c3, q1c4, q1c5;
    private RadioButton q2c1, q2c2, q2c3, q2c4, q2c5;
    private RadioButton q3c1, q3c2, q3c3, q3c4, q3c5;
    private RadioButton q4c1, q4c2, q4c3, q4c4, q4c5;
    private RadioButton q5c1, q5c2, q5c3, q5c4, q5c5;
    private RadioButton q6c1, q6c2, q6c3, q6c4, q6c5;
    private RadioButton q7c1, q7c2, q7c3, q7c4, q7c5;
    private RadioButton q8c1, q8c2, q8c3, q8c4, q8c5;
    private RadioButton q9c1, q9c2, q9c3, q9c4, q9c5;
    private RadioButton q10c1, q10c2, q10c3, q10c4, q10c5;
    private RadioButton q11c1, q11c2, q11c3, q11c4, q11c5;
    private RadioButton q12c1, q12c2, q12c3, q12c4, q12c5;
    private RadioButton q13c1, q13c2, q13c3, q13c4, q13c5;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_english_que);
        username = getIntent().getStringExtra("username");
        RadioButton t=findViewById(R.id.english);
        t.setChecked(true);
        RadioButton r = findViewById(R.id.tamil);
        r.setOnClickListener(view -> {
            Intent it = new Intent(this,tamil_que.class);
            it.putExtra("username",username);
            startActivity(it);
        });
        rs = findViewById(R.id.totalscore);

        q1c1 = findViewById(R.id.ans1);
        q1c2 = findViewById(R.id.ams2);
        q1c3 = findViewById(R.id.ans3);
        q1c4 = findViewById(R.id.ans4);
        q1c5 = findViewById(R.id.ans5);

// Initialize radio buttons for question 2
        q2c1 = findViewById(R.id.two1);
        q2c2 = findViewById(R.id.two2);
        q2c3 = findViewById(R.id.three3);
        q2c4 = findViewById(R.id.four4);
        q2c5 = findViewById(R.id.five5);

// Initialize radio buttons for question 3
        q3c1 = findViewById(R.id.threeanss1);
        q3c2 = findViewById(R.id.threeans2);
        q3c3 = findViewById(R.id.threeans3);
        q3c4 = findViewById(R.id.threeans4);
        q3c5 = findViewById(R.id.threeans5);

// Initialize radio buttons for question 4
        q4c1 = findViewById(R.id.threeans1);
        q4c2 = findViewById(R.id.threean2);
        q4c3 = findViewById(R.id.threean3);
        q4c4 = findViewById(R.id.threean4);
        q4c5 = findViewById(R.id.threean5);

// Initialize radio buttons for question 5
        q5c1 = findViewById(R.id.fiveans1);
        q5c2 = findViewById(R.id.fiveans2);
        q5c3 = findViewById(R.id.fiveans3);
        q5c4 = findViewById(R.id.fiveans4);
        q5c5 = findViewById(R.id.fiveans);

        // Initialize radio buttons for question 6
        q6c1 = findViewById(R.id.sixans1);
        q6c2 = findViewById(R.id.sixans2);
        q6c3 = findViewById(R.id.sixans3);
        q6c4 = findViewById(R.id.sixans4);
        q6c5 = findViewById(R.id.sixans5);

// Initialize radio buttons for question 7
        q7c1 = findViewById(R.id.sevenans1);
        q7c2 = findViewById(R.id.sevenans2);
        q7c3 = findViewById(R.id.sevenans3);
        q7c4 = findViewById(R.id.sevenans4);
        q7c5 = findViewById(R.id.sevenans5);

// Initialize radio buttons for question 8
        q8c1 = findViewById(R.id.eightans1);
        q8c2 = findViewById(R.id.eightans2);
        q8c3 = findViewById(R.id.eightans3);
        q8c4 = findViewById(R.id.eightans4);
        q8c5 = findViewById(R.id.eightans5);

// Initialize radio buttons for question 9
        q9c1 = findViewById(R.id.nineans1);
        q9c2 = findViewById(R.id.nineans2);
        q9c3 = findViewById(R.id.nineans3);
        q9c4 = findViewById(R.id.nineans4);
        q9c5 = findViewById(R.id.nineans5);

// Initialize radio buttons for question 10
        q10c1 = findViewById(R.id.tenans1);
        q10c2 = findViewById(R.id.tenans2);
        q10c3 = findViewById(R.id.tenans3);
        q10c4 = findViewById(R.id.tenans4);
        q10c5 = findViewById(R.id.tenans5);

// Initialize radio buttons for question 11
        q11c1 = findViewById(R.id.elevenans1);
        q11c2 = findViewById(R.id.elevenans2);
        q11c3 = findViewById(R.id.elevenans3);
        q11c4 = findViewById(R.id.elevenans4);
        q11c5 = findViewById(R.id.elevenans5);

// Initialize radio buttons for question 12
        q12c1 = findViewById(R.id.twelveans1);
        q12c2 = findViewById(R.id.twelveans2);
        q12c3 = findViewById(R.id.twelveans3);
        q12c4 = findViewById(R.id.twelveans4);
        q12c5 = findViewById(R.id.twelveans5);

// Initialize radio buttons for question 13
        q13c1 = findViewById(R.id.hirteenans1);
        q13c2 = findViewById(R.id.hirteenans2);
        q13c3 = findViewById(R.id.hirteenans3);
        q13c4 = findViewById(R.id.hirteenans4);
        q13c5 = findViewById(R.id.thirteenans5);

        Button sb=findViewById(R.id.sb);
        sb.setOnClickListener(view -> {
            int score=0;
            if(q1c1.isChecked()){
                score+=1;
            } else if (q1c2.isChecked()) {
                score+=2;
            } else if (q1c3.isChecked()) {
                score+=3;
            } else if (q1c4.isChecked()) {
                score+=4;
            } else if (q1c5.isChecked()) {
                score+=5;
            }
            // Calculate score for question 2
            if (q2c1.isChecked()) {
                score += 1;
            } else if (q2c2.isChecked()) {
                score += 2;
            } else if (q2c3.isChecked()) {
                score += 3;
            } else if (q2c4.isChecked()) {
                score += 4;
            } else if (q2c5.isChecked()) {
                score += 5;
            }

// Calculate score for question 3
            if (q3c1.isChecked()) {
                score += 1;
            } else if (q3c2.isChecked()) {
                score += 2;
            } else if (q3c3.isChecked()) {
                score += 3;
            } else if (q3c4.isChecked()) {
                score += 4;
            } else if (q3c5.isChecked()) {
                score += 5;
            }

// Calculate score for question 4
            if (q4c1.isChecked()) {
                score += 1;
            } else if (q4c2.isChecked()) {
                score += 2;
            } else if (q4c3.isChecked()) {
                score += 3;
            } else if (q4c4.isChecked()) {
                score += 4;
            } else if (q4c5.isChecked()) {
                score += 5;
            }

// Calculate score for question 5
            if (q5c1.isChecked()) {
                score += 1;
            } else if (q5c2.isChecked()) {
                score += 2;
            } else if (q5c3.isChecked()) {
                score += 3;
            } else if (q5c4.isChecked()) {
                score += 4;
            } else if (q5c5.isChecked()) {
                score += 5;
            }
            // Calculate score for question 6
            if (q6c1.isChecked()) {
                score += 1;
            } else if (q6c2.isChecked()) {
                score += 2;
            } else if (q6c3.isChecked()) {
                score += 3;
            } else if (q6c4.isChecked()) {
                score += 4;
            } else if (q6c5.isChecked()) {
                score += 5;
            }

// Calculate score for question 7
            if (q7c1.isChecked()) {
                score += 1;
            } else if (q7c2.isChecked()) {
                score += 2;
            } else if (q7c3.isChecked()) {
                score += 3;
            } else if (q7c4.isChecked()) {
                score += 4;
            } else if (q7c5.isChecked()) {
                score += 5;
            }

// Calculate score for question 8
            if (q8c1.isChecked()) {
                score += 1;
            } else if (q8c2.isChecked()) {
                score += 2;
            } else if (q8c3.isChecked()) {
                score += 3;
            } else if (q8c4.isChecked()) {
                score += 4;
            } else if (q8c5.isChecked()) {
                score += 5;
            }

// Calculate score for question 9
            if (q9c1.isChecked()) {
                score += 1;
            } else if (q9c2.isChecked()) {
                score += 2;
            } else if (q9c3.isChecked()) {
                score += 3;
            } else if (q9c4.isChecked()) {
                score += 4;
            } else if (q9c5.isChecked()) {
                score += 5;
            }

// Calculate score for question 10
            if (q10c1.isChecked()) {
                score += 1;
            } else if (q10c2.isChecked()) {
                score += 2;
            } else if (q10c3.isChecked()) {
                score += 3;
            } else if (q10c4.isChecked()) {
                score += 4;
            } else if (q10c5.isChecked()) {
                score += 5;
            }

// Calculate score for question 11
            if (q11c1.isChecked()) {
                score += 1;
            } else if (q11c2.isChecked()) {
                score += 2;
            } else if (q11c3.isChecked()) {
                score += 3;
            } else if (q11c4.isChecked()) {
                score += 4;
            } else if (q11c5.isChecked()) {
                score += 5;
            }

// Calculate score for question 12
            if (q12c1.isChecked()) {
                score += 1;
            } else if (q12c2.isChecked()) {
                score += 2;
            } else if (q12c3.isChecked()) {
                score += 3;
            } else if (q12c4.isChecked()) {
                score += 4;
            } else if (q12c5.isChecked()) {
                score += 5;
            }

// Calculate score for question 13
            if (q13c1.isChecked()) {
                score += 1;
            } else if (q13c2.isChecked()) {
                score += 2;
            } else if (q13c3.isChecked()) {
                score += 3;
            } else if (q13c4.isChecked()) {
                score += 4;
            } else if (q13c5.isChecked()) {
                score += 5;
            }

            rs.setText(String.valueOf(score));
            sendLoginRequest(username,String.valueOf(score));


        });


    }

    private void sendLoginRequest(final String username,final String score) {
        String URL = ip.ipn+"score.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleResponse(response,username,score);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleError(error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Send the username and password as POST parameters
                Map<String, String> data = new HashMap<>();

                LocalDate currentDate = LocalDate.now();

                // Define the date format
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

                // Format the current date
                String Date = currentDate.format(formatter);
                data.put("patient_id", username);
                data.put("date", Date);
                data.put("total_score", score);




                return data;
            }
        };

        // Customize the retry policy
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        // Initialize the Volley request queue and add the request
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    // Handle the JSON response
    private void handleResponse(String response, String username,String score) {
        Log.d("JSON Response", response);

        try {
            JSONObject jsonObject = new JSONObject(response);
            String status = jsonObject.getString("status");

            if (status.equals("success")) {
                Toast.makeText(this, "Data inserted successfully!!!", Toast.LENGTH_SHORT).show();

                Dialog myDialog = new Dialog(this);
                myDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                //myDialog.setCancelable(false);
                myDialog.setContentView(R.layout.score);
                myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                TextView sc=myDialog.findViewById(R.id.textView104);
                sc.setText(" "+score);
                myDialog.show();
                Button yes = myDialog.findViewById(R.id.button11);
                yes.setOnClickListener(view1 -> {
                    Intent it = new Intent(this, patientdashboard.class);
                    it.putExtra("username",username);
                    startActivity(it);
                });


            }
            else{

            }
        } catch (JSONException e) {

            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }




    private void handleError(VolleyError error) {
        System.out.println("boooooo");
    }
}