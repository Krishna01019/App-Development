package com.example.shoulder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {

    private Context context;
    private List<itemClass> items;
    private int defaultImage;

    public MyAdapter(Context context, List<itemClass> items) {
        this.context = context;
        this.items = items;
        this.defaultImage = defaultImage;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        itemClass currentItem = items.get(position);
        holder.textviewone.setText(currentItem.getName());
        holder.textviewtwo.setText(currentItem.getPatientId());
        holder.imageviewone.setImageResource(currentItem.getImage() != 0 ? currentItem.getImage() : defaultImage);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }


}
