package com.example.shoulder;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class patientdetails extends AppCompatActivity {

    private String username;
    private EditText epid,epname,ecntct,eage,egndr,eadmt,edgns,eexm,ebrf;
    private static final int GALLERY_REQUEST_CODE = 1;
    private static final int CAMERA_GALLERY_REQUEST_CODE = 1001;
    private Intent lastActivityResultData;
    private Uri selectedImageUri,s1,s2;




    private String pid,pname,cntct,age,gndr,admt,dgns,exm,brf;
    private ImageView im1 , im2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_patientdetails);
        username = getIntent().getStringExtra("username");
        epid = findViewById(R.id.pidedit);
        epname= findViewById(R.id.nameedit);
        ecntct = findViewById(R.id.contactNo);
        eage = findViewById(R.id.age);
        egndr =findViewById(R.id.sex);
        eadmt = findViewById(R.id.admittedOn);
        edgns = findViewById(R.id.diagret);
        eexm = findViewById(R.id.exm);
        ebrf = findViewById(R.id.brf);
        im1= findViewById(R.id.im1);
        im2 = findViewById(R.id.imageaddview);
        Button ts = findViewById(R.id.ts);
        ts.setOnClickListener(view -> {
            Intent it = new Intent(this, task_doc.class);
            it.putExtra("username",username);
            startActivity(it);
        });
        Button vd = findViewById(R.id.button7);
        vd.setOnClickListener(view -> {
            Intent it = new Intent(this, today_task_patient.class);
            startActivity(it);
        });
        sendLoginRequest(username);

        im1.setOnClickListener(view -> {

            openCameraOrGallery();
//            s1=selectedImageUri;
//            im1.setImageURI(s1);

        });

        im2.setOnClickListener(view -> {
            openGallery();
//            s2=selectedImageUri;
//            im2.setImageURI(s2);

        });
        Button addButton = findViewById(R.id.save);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get patient details from EditText fields
                pid = epid.getText().toString().trim();
                String name = epname.getText().toString();
                String age = eage.getText().toString();
                String sex = egndr.getText().toString();
                String contact = ecntct.getText().toString();
                String admittedOn = eadmt.getText().toString();
                String diagnosis = edgns.getText().toString();
                String examination = eexm.getText().toString();
                String briefHistory = ebrf.getText().toString();

                // Send patient details to the server
                System.out.println(pid);
                sendPatientDetailsToServer(pid, name, age, sex, contact, admittedOn, diagnosis, examination, briefHistory);

                if (s1 != null || lastActivityResultData != null) {
                    try {
                        Bitmap bitmap;
                        if (s1 != null && s1.toString().startsWith("content://")) {
                            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), s1);
                            bitmap = ImageDecoder.decodeBitmap(source);
                        } else {
                            // Camera image captured
                            Bitmap photo = (Bitmap) lastActivityResultData.getExtras().get("data");
                            bitmap = photo;
                        }

                        String base64Image = convertBitmapToBase64(bitmap);
                        // Execute AsyncTask to send data to the server
                        new SendDataToServer().execute(pid, s1 != null ? s1.toString() : "", base64Image);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    Toast.makeText(patientdetails.this, "Please select an image first", Toast.LENGTH_SHORT).show();
                }

                if (s2 != null) {
                    try {
                        ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), s2);
                        Bitmap bitmap = ImageDecoder.decodeBitmap(source);

                        String base64Image = convertBitmapToBase64(bitmap);

                        // Execute AsyncTask to send data to the server
                        new SendDataToServer1().execute(pid, s2.toString(), base64Image);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    Toast.makeText(patientdetails.this, "Please select an image first", Toast.LENGTH_SHORT).show();
                }
                Intent it = new Intent(patientdetails.this,doctorsdsshboard.class);
                it.putExtra("username", ip.doc);
                startActivity(it);


            }

        });
    }

    private void sendLoginRequest(final String username) {
        String URL = ip.ipn+"patientdetails.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleResponse(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleError(error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Send the username and password as POST parameters
                Map<String, String> data = new HashMap<>();
                data.put("patient_id", username);
                return data;
            }
        };

        // Customize the retry policy
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        // Initialize the Volley request queue and add the request
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    // Handle the JSON response
    private void handleResponse(String response) {
        Log.d("JSON Response", response);

        // Handle your JSON response here without assuming a 'status' field
        // You can parse the response and handle success/failure accordingly
        try {
            JSONArray jsonArray = new JSONArray(response);

            // Assuming there's only one object in the array
            JSONObject jsonObject = jsonArray.getJSONObject(0);

            // Extracting values from the JSON object

            String patientId = jsonObject.getString("patient_id");
            String name = jsonObject.getString("name");
            int age = jsonObject.getInt("age");
            String gender = jsonObject.getString("gender");
            String phoneNumber = jsonObject.getString("phone_number");
            String admittedOn = jsonObject.getString("admitted_on");
            String diagnosis = jsonObject.getString("diagnosis");
            String examination = jsonObject.getString("examination");
            String briefHistory = jsonObject.getString("brief_history");
            String dp = jsonObject.getString("dp");
            String im = jsonObject.getString("im");

            epid.setText(patientId);
            epname.setText(name);
            eage.setText(String.valueOf(age));
            egndr.setText(gender);
            ecntct.setText(phoneNumber);
            eadmt.setText(admittedOn);
            edgns.setText(diagnosis);
            eexm.setText(examination);
            ebrf.setText(briefHistory);
            if (dp != null && !dp.isEmpty()) {
                byte[] decodedImageBytes = Base64.decode(dp, Base64.DEFAULT);
                Bitmap decodedBitmap = BitmapFactory.decodeByteArray(decodedImageBytes, 0, decodedImageBytes.length);

                im1.setImageBitmap(decodedBitmap);
            }
            if (im != null && !im.isEmpty()) {
                byte[] decodedImageBytes = Base64.decode(im, Base64.DEFAULT);
                Bitmap decodedBitmap = BitmapFactory.decodeByteArray(decodedImageBytes, 0, decodedImageBytes.length);

                im2.setImageBitmap(decodedBitmap);
            }


        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle network request errors
    private void handleError(VolleyError error) {
        if (error instanceof TimeoutError) {
            Toast.makeText(this, "Request timed out. Check your internet connection.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, error.toString().trim(), Toast.LENGTH_SHORT).show();
        }
    }










    private String convertBitmapToBase64(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }

    private void openGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, GALLERY_REQUEST_CODE);
    }



    private void openCameraOrGallery() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        // Create a chooser intent to allow the user to select between camera and gallery
        Intent chooser = Intent.createChooser(galleryIntent, "Select Image Source");
        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[] { cameraIntent });

        startActivityForResult(chooser, CAMERA_GALLERY_REQUEST_CODE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            // Gallery image selected
            s2 = data.getData();
            // Process the selected image from gallery
            // For example: set the image URI to ImageView
            im2.setImageURI(selectedImageUri);
        } else if (requestCode == CAMERA_GALLERY_REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                // Gallery image selected
                s1 = data.getData();
                // Process the selected image from gallery
                // For example: set the image URI to ImageView
                im1.setImageURI(selectedImageUri);
            } else if (data != null && data.getExtras() != null && data.getExtras().get("data") != null) {
                // Camera image captured
                lastActivityResultData = data;
                Bitmap photo = (Bitmap) data.getExtras().get("data");
                // Process the captured photo
                // For example: set the Bitmap to ImageView
                im1.setImageBitmap(photo);
            }
        }
    }


    private void sendPatientDetailsToServer(String pid, String name, String age, String sex, String contact,
                                            String admittedOn, String diagnosis, String examination, String briefHistory) {
        String URL = ip.ipn+"editpatient.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleResponse(response,pid);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleError(error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Send the username and password as POST parameters
                Map<String, String> data = new HashMap<>();

                //Toast.makeText(addpatient.this, pid, Toast.LENGTH_SHORT).show();
                data.put("patient_id", pid);
                data.put("name", name);
                data.put("age", age);
                data.put("gender", sex);
                data.put("phone_number", contact);
                data.put("admitted_on", admittedOn);
                data.put("diagnosis", diagnosis);
                data.put("examination", examination);
                data.put("brief_history", briefHistory);

                return data;
            }
        };

        // Customize the retry policy
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        // Initialize the Volley request queue and add the request
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    // Handle the JSON response
    private void handleResponse(String response,String username) {
        Log.d("JSON Response", response);

        // Handle your JSON response here without assuming a 'status' field
        // You can parse the response and handle success/failure accordingly
        try {
            // Example: Check if the response contains "success"
            if (response.toLowerCase().contains("true")) {
                Toast.makeText(this, "Sign Up successful", Toast.LENGTH_SHORT).show();


            } else {
                Toast.makeText(this, "Sign Up failed", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }





    private class SendDataToServer extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            try {
                String username = params[0];
                String imageUriString = params[1];
                String base64Image = params[2];
                System.out.println(base64Image);
                // Create a JSON object
                JSONObject jsonParams = new JSONObject();
                jsonParams.put("patient_id", username);
                jsonParams.put("base64image", base64Image);

                // Convert JSON object to string
                String jsonData = jsonParams.toString();

                URL url = new URL(ip.ipn+"dp_upld.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                urlConnection.setRequestMethod("POST");
                urlConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
                urlConnection.setDoOutput(true);

                // Write JSON data to the server
                try (OutputStream os = urlConnection.getOutputStream()) {
                    byte[] input = jsonData.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                // Get the response from the server
                InputStream inputStream = urlConnection.getInputStream();
                int responseCode = urlConnection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    return "Data inserted successfully";
                } else {
                    return "Failed to insert data";
                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null && result.equals("Data inserted successfully")) {
                Toast.makeText(patientdetails.this, "successful", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class SendDataToServer1 extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            try {
                String username = params[0];
                String imageUriString = params[1];
                String base64Image = params[2];
                System.out.println(base64Image);
                // Create a JSON object
                JSONObject jsonParams = new JSONObject();
                jsonParams.put("patient_id", username);
                jsonParams.put("base64image", base64Image);

                // Convert JSON object to string
                String jsonData = jsonParams.toString();

                URL url = new URL(ip.ipn+"im_upld.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                urlConnection.setRequestMethod("POST");
                urlConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
                urlConnection.setDoOutput(true);

                // Write JSON data to the server
                try (OutputStream os = urlConnection.getOutputStream()) {
                    byte[] input = jsonData.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                // Get the response from the server
                InputStream inputStream = urlConnection.getInputStream();
                int responseCode = urlConnection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    return "Data inserted successfully";
                } else {
                    return "Failed to insert data";
                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
            return null;
        }


    }
}


