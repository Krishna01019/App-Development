package com.example.shoulder;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class addpatient extends AppCompatActivity {

    private static final int GALLERY_REQUEST_CODE = 1;
    private static final int CAMERA_GALLERY_REQUEST_CODE = 1001;
    private Intent lastActivityResultData;
    private Uri selectedImageUri,s1,s2;


    private EditText pidEditText, nameEditText, ageEditText, sexEditText, contactEditText, admittedOnEditText,
            diagnosisEditText, examinationEditText, briefHistoryEditText;
    private String pid;
    private ImageView im,dp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addpatient);
        String username = getIntent().getStringExtra("username");
        // Initialize EditText fields
        pidEditText = findViewById(R.id.pidedit);
        nameEditText = findViewById(R.id.nameedit);
        ageEditText = findViewById(R.id.age);
        sexEditText = findViewById(R.id.sex);
        contactEditText = findViewById(R.id.contactNo);
        admittedOnEditText = findViewById(R.id.admittedOn);
        diagnosisEditText = findViewById(R.id.diagret);
        examinationEditText = findViewById(R.id.examinationret);
        briefHistoryEditText = findViewById(R.id.briefhisret);
        dp=findViewById(R.id.dp);
        im=findViewById(R.id.imageaddview);
        Button vd = findViewById(R.id.addvideos);
        vd.setOnClickListener(view -> {
            Intent it = new Intent(this, today_task_patient.class);
            startActivity(it);
        });

        dp.setOnClickListener(view -> {

            openCameraOrGallery();
//            s1=selectedImageUri;
//            im1.setImageURI(s1);

        });

        im.setOnClickListener(view -> {
            openGallery();
//            s2=selectedImageUri;
//            im2.setImageURI(s2);

        });

        Button addButton = findViewById(R.id.add_patient_button);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get patient details from EditText fields
                pid = pidEditText.getText().toString().trim();
                String name = nameEditText.getText().toString();
                String age = ageEditText.getText().toString();
                String sex = sexEditText.getText().toString();
                String contact = contactEditText.getText().toString();
                String admittedOn = admittedOnEditText.getText().toString();
                String diagnosis = diagnosisEditText.getText().toString();
                String examination = examinationEditText.getText().toString();
                String briefHistory = briefHistoryEditText.getText().toString();

                // Send patient details to the server
                System.out.println(pid);
                sendPatientDetailsToServer(pid, name, age, sex, contact, admittedOn, diagnosis, examination, briefHistory);

                if (s1 != null || lastActivityResultData != null) {
                    try {
                        Bitmap bitmap;
                        if (s1 != null && s1.toString().startsWith("content://")) {
                            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), selectedImageUri);
                            bitmap = ImageDecoder.decodeBitmap(source);
                        } else {
                            // Camera image captured
                            Bitmap photo = (Bitmap) lastActivityResultData.getExtras().get("data");
                            bitmap = photo;
                        }

                        String base64Image = convertBitmapToBase64(bitmap);
                        // Execute AsyncTask to send data to the server
                        new SendDataToServer().execute(pid, s1 != null ? s1.toString() : "", base64Image);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    Toast.makeText(addpatient.this, "Please select an image first", Toast.LENGTH_SHORT).show();
                }

                if (s2 != null) {
                    try {
                        ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), s2);
                        Bitmap bitmap = ImageDecoder.decodeBitmap(source);

                        String base64Image = convertBitmapToBase64(bitmap);

                        // Execute AsyncTask to send data to the server
                        new SendDataToServer1().execute(pid, s2.toString(), base64Image);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    Toast.makeText(addpatient.this, "Please select an image first", Toast.LENGTH_SHORT).show();
                }
                Intent it = new Intent(addpatient.this,doctorsdsshboard.class);
                it.putExtra("username", username);
                startActivity(it);


            }

        });



    }

    private String convertBitmapToBase64(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }

    private void openGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, GALLERY_REQUEST_CODE);
    }


    private void openCameraOrGallery() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        // Create a chooser intent to allow the user to select between camera and gallery
        Intent chooser = Intent.createChooser(galleryIntent, "Select Image Source");
        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[] { cameraIntent });

        startActivityForResult(chooser, CAMERA_GALLERY_REQUEST_CODE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            // Gallery image selected
            s2 = data.getData();
            // Process the selected image from gallery
            // For example: set the image URI to ImageView
            im.setImageURI(s2);
        } else if (requestCode == CAMERA_GALLERY_REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                // Gallery image selected
                s1 = data.getData();
                // Process the selected image from gallery
                // For example: set the image URI to ImageView
                dp.setImageURI(s1);
            } else if (data != null && data.getExtras() != null && data.getExtras().get("data") != null) {
                // Camera image captured
                lastActivityResultData = data;
                Bitmap photo = (Bitmap) data.getExtras().get("data");
                // Process the captured photo
                // For example: set the Bitmap to ImageView
                dp.setImageBitmap(photo);
            }
        }
    }


    private void sendPatientDetailsToServer(String pid, String name, String age, String sex, String contact,
                                            String admittedOn, String diagnosis, String examination, String briefHistory) {
        String URL = ip.ipn+"addpatient.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleResponse(response,pid);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handleError(error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Send the username and password as POST parameters
                Map<String, String> data = new HashMap<>();

                //Toast.makeText(addpatient.this, pid, Toast.LENGTH_SHORT).show();
                data.put("patient_id", pid);
                data.put("name", name);
                data.put("age", age);
                data.put("gender", sex);
                data.put("phone_number", contact);
                data.put("admitted_on", admittedOn);
                data.put("diagnosis", diagnosis);
                data.put("examination", examination);
                data.put("brief_history", briefHistory);

                return data;
            }
        };

        // Customize the retry policy
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        // Initialize the Volley request queue and add the request
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    // Handle the JSON response
    private void handleResponse(String response,String username) {
        Log.d("JSON Response", response);

        // Handle your JSON response here without assuming a 'status' field
        // You can parse the response and handle success/failure accordingly
        try {
            // Example: Check if the response contains "success"
            if (response.toLowerCase().contains("true")) {
                Toast.makeText(this, "Sign Up successful", Toast.LENGTH_SHORT).show();


            } else {
                Toast.makeText(this, "Sign Up failed", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleError(VolleyError error) {
        System.out.println("boooooo");
    }



    private class SendDataToServer extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            try {
                String username = params[0];
                String imageUriString = params[1];
                String base64Image = params[2];
                System.out.println(base64Image);
                // Create a JSON object
                JSONObject jsonParams = new JSONObject();
                jsonParams.put("patient_id", username);
                jsonParams.put("base64image", base64Image);

                // Convert JSON object to string
                String jsonData = jsonParams.toString();

                URL url = new URL(ip.ipn+"dp_upld.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                urlConnection.setRequestMethod("POST");
                urlConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
                urlConnection.setDoOutput(true);

                // Write JSON data to the server
                try (OutputStream os = urlConnection.getOutputStream()) {
                    byte[] input = jsonData.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                // Get the response from the server
                InputStream inputStream = urlConnection.getInputStream();
                int responseCode = urlConnection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    return "Data inserted successfully";
                } else {
                    return "Failed to insert data";
                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null && result.equals("Data inserted successfully")) {
                Toast.makeText(addpatient.this, "successful", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class SendDataToServer1 extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            try {
                String username = params[0];
                String imageUriString = params[1];
                String base64Image = params[2];
                System.out.println(base64Image);
                // Create a JSON object
                JSONObject jsonParams = new JSONObject();
                jsonParams.put("patient_id", username);
                jsonParams.put("base64image", base64Image);

                // Convert JSON object to string
                String jsonData = jsonParams.toString();

                URL url = new URL(ip.ipn+"im_upld.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                urlConnection.setRequestMethod("POST");
                urlConnection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
                urlConnection.setDoOutput(true);

                // Write JSON data to the server
                try (OutputStream os = urlConnection.getOutputStream()) {
                    byte[] input = jsonData.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                // Get the response from the server
                InputStream inputStream = urlConnection.getInputStream();
                int responseCode = urlConnection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    return "Data inserted successfully";
                } else {
                    return "Failed to insert data";
                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
            return null;
        }


    }




}
