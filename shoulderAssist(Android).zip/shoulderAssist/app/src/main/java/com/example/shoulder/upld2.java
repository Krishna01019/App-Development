package com.example.shoulder;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class upld2 extends AppCompatActivity {
    private static final int REQUEST_CODE = 100;

    private Button selectBtn;
    private String selectedVideoPath;
    private EditText ettle;
    private  String ttle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.upld2);
        ettle = findViewById(R.id.titleret);
        selectBtn = findViewById(R.id.selectVideoBtn);
        selectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                selectVideoFromGallery();


            }
        });
        Button b1 = findViewById(R.id.saveBtn);
        b1.setOnClickListener(view -> {
            ttle= ettle.getText().toString().trim();

            if (!ttle.isEmpty() &&selectedVideoPath != null) {
                System.out.println(selectedVideoPath);
                uploadVideo(selectedVideoPath,ttle);
            } else {
                System.out.println("adadadada");
                Toast.makeText(upld2.this, "Please select a video first", Toast.LENGTH_SHORT).show();
            }

        });
    }

    private void selectVideoFromGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Uri selectedVideoUri = data.getData();
            selectedVideoPath = getPathFromUri(selectedVideoUri);
        }
    }

    private String getPathFromUri(Uri contentUri) {
        String[] proj = { MediaStore.Video.Media.DATA };
        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA);
        cursor.moveToFirst();
        String path = cursor.getString(column_index);
        cursor.close();
        return path;
    }

    private void uploadVideo(final String selectedPath, final String videoTitle) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String serverURL = ip.ipn + "videos1.php";
                    HttpURLConnection connection = null;
                    DataOutputStream dataOutputStream = null;
                    FileInputStream fileInputStream = new FileInputStream(selectedPath);

                    URL url = new URL(serverURL);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setDoInput(true);
                    connection.setDoOutput(true);
                    connection.setUseCaches(false);
                    connection.setRequestMethod("POST");
                    connection.setRequestProperty("Connection", "Keep-Alive");
                    connection.setRequestProperty("ENCTYPE", "multipart/form-data");
                    connection.setRequestProperty("Content-Type", "multipart/form-data;boundary=***");

                    dataOutputStream = new DataOutputStream(connection.getOutputStream());

                    // Add video_title field
                    dataOutputStream.writeBytes("--***\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"video_title\"\r\n\r\n");
                    dataOutputStream.writeBytes(videoTitle + "\r\n");

                    // Add uploaded_file field (video file)
                    dataOutputStream.writeBytes("--***\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\";filename=\"" + selectedPath + "\"" + "\r\n");
                    dataOutputStream.writeBytes("\r\n");

                    int bytesRead, bufferSize;
                    byte[] buffer;
                    int maxBufferSize = 1 * 1024 * 1024;

                    bufferSize = Math.min(fileInputStream.available(), maxBufferSize);
                    buffer = new byte[bufferSize];

                    bytesRead = fileInputStream.read(buffer, 0, bufferSize);

                    while (bytesRead > 0) {
                        dataOutputStream.write(buffer, 0, bufferSize);
                        bufferSize = Math.min(fileInputStream.available(), maxBufferSize);
                        bytesRead = fileInputStream.read(buffer, 0, bufferSize);
                    }

                    dataOutputStream.writeBytes("\r\n");
                    dataOutputStream.writeBytes("--***--\r\n");

                    int serverResponseCode = connection.getResponseCode();
                    String serverResponseMessage = connection.getResponseMessage();

                    fileInputStream.close();
                    dataOutputStream.flush();
                    dataOutputStream.close();

                    if (serverResponseCode == 200) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(upld2.this, "Video uploaded successfully", Toast.LENGTH_SHORT).show();


                            }
                        });
                    } else {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(upld2.this, "Failed to upload video", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }

                } catch (MalformedURLException e) {
                    System.out.println("111111");
                    e.printStackTrace();
                } catch (IOException e) {
                    System.out.println("222222");
                    e.printStackTrace();
                }
            }
        }).start();
    }
}