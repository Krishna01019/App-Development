package com.example.shoulder;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
//import com.practise1.shoulder_final.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class patient_login extends AppCompatActivity {

    private EditText patientIdEditText, passwordEditText;
    private Button loginButton;
    private RequestQueue requestQueue;
    private static final String URL = ip.ipn+"patient_login.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_login);

        patientIdEditText = findViewById(R.id.tx1);
        passwordEditText = findViewById(R.id.tx2);
        passwordEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        // Inside onCreate method after initializing epassword EditText
        // Inside your activity's onCreate method
        EditText passwordEditText = findViewById(R.id.tx2);
        final boolean[] isPasswordVisible = {false};

// Set the OnTouchListener to detect clicks on the drawable
        passwordEditText.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Check if the event is an ACTION_UP (finger lifted from screen)
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    Drawable[] drawables = passwordEditText.getCompoundDrawables();

                    if (drawables[2] != null) { // Check if the right drawable exists
                        // Get the width of the right drawable
                        int drawableWidth = drawables[2].getBounds().width();

                        // If the touch occurred within the bounds of the drawable
                        if (event.getX() >= (passwordEditText.getWidth() - passwordEditText.getPaddingRight() - drawableWidth)) {
                            // Toggle password visibility
                            isPasswordVisible[0] = !isPasswordVisible[0];

                            // Get the current cursor position
                            int cursorPosition = passwordEditText.getSelectionStart();

                            if (isPasswordVisible[0]) {
                                passwordEditText.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                            } else {
                                passwordEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                            }

                            // Restore the cursor position
                            passwordEditText.setSelection(cursorPosition);

                            return true; // Indicates that the event was handled
                        }
                    }
                }

                return false; // Indicates that the event wasn't handled, allowing default behavior
            }
        });




        loginButton = findViewById(R.id.btn);
        requestQueue = Volley.newRequestQueue(this);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String patientId = patientIdEditText.getText().toString().trim();
                final String password = passwordEditText.getText().toString().trim();

                if (!patientId.isEmpty() && !password.isEmpty()) {
                    login(patientId, password);
                } else {
                    Toast.makeText(patient_login.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void login(final String patientId, final String password) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");

                            if (success) {
                                // Login successful, start new activity or perform other actions
                                Toast.makeText(patient_login.this, "Login Successful", Toast.LENGTH_SHORT).show();
                                // Example: Start a new activity
                                Intent intent = new Intent(patient_login.this, patientdashboard.class);
                                intent.putExtra("username",patientId);
                                startActivity(intent);
                            } else {
                                // Login failed, show error message
                                String message = jsonObject.getString("message");
                                Toast.makeText(patient_login.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(patient_login.this, "JSON Exception: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(patient_login.this, "Volley Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("patient_id", patientId);
                params.put("password", password);
                return params;
            }
        };

        requestQueue.add(stringRequest);
    }
}