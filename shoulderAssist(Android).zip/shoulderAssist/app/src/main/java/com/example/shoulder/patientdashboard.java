package com.example.shoulder;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.navigation.NavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class patientdashboard extends AppCompatActivity {
    private static final String fetchDataUrl = ip.ipn+"p_profile.php";
    TextView t1, t2;
    private String username;
    private ImageView im1;
    private DrawerLayout drawerLayout;
    private Toolbar toolbar;
    private NavigationView navigationView;
    private ActionBarDrawerToggle toggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patientdashboard);
        username = getIntent().getStringExtra("username");
        t1=findViewById(R.id.t1);
        t2=findViewById(R.id.t2);
        im1 = findViewById(R.id.im1);
        String url = ip.ipn +"p_dash.php";
        makeRequest(url);

        Button bt = findViewById(R.id.button3);
        bt.setOnClickListener(view -> {
            Intent it = new Intent(this, daily_progress.class);
            it.putExtra("username",username);
            startActivity(it);
        });
        Button bt1 = findViewById(R.id.button);
        bt1.setOnClickListener(view -> {
            Intent it = new Intent(this, videosadd_main.class);
            startActivity(it);
        });
        Button bt2 = findViewById(R.id.button4);
        bt2.setOnClickListener(view -> {
            Intent it = new Intent(this, english_que.class);
            it.putExtra("username",username);
            startActivity(it);
        });
//        ImageView imageView9 = findViewById(R.id.imageView9);
//        imageView9.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // Handle click event for imageView9
//                Intent intent = new Intent(patientdashboard.this, patient_profile.class);
//                intent.putExtra("username",username);
//                startActivity(intent);
//            }
//        });

        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.tb);
        drawerLayout = findViewById(R.id.mainmenu);
        // Set item click listener for navigation menu items
        setSupportActionBar(toolbar);

        toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.OpenDrawer, R.string.CloseDrawer
        );
        toggle.getDrawerArrowDrawable().setColor(getResources().getColor(R.color.white));
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.profile) {
                // Handle "Profile" item click
                Intent intent1 = new Intent(patientdashboard.this, patient_profile.class);
//                 intent1.putExtra("username", doctorId);
                intent1.putExtra("username",username);
                startActivity(intent1);
            } else if (id == R.id.logout) {
                Intent intent2 = new Intent(patientdashboard.this, doctor_patiemt_login.class);
                intent2.putExtra("username",username);
                startActivity(intent2);
                finish();
            }

            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });
    }
    private void makeRequest(String url) {
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        System.out.println(response);
                        Log.d("Volley Response", response);
                        parseResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volley Error", error.toString());
                        Toast.makeText(patientdashboard.this, "Error fetching data", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    // Handle the JSON response
    private void parseResponse(String response) {
        Log.d("JSON Response", response);

        try {
            JSONObject jsonObject = new JSONObject(response);
            boolean success = jsonObject.getBoolean("success");

            if (success) {
                JSONArray dataArray = jsonObject.getJSONArray("data");
                if (dataArray.length() > 0) {
                    JSONObject dataObject = dataArray.getJSONObject(0); // Assuming there's only one item in the array
                    String name = dataObject.getString("name");
                    String phoneNumber = dataObject.getString("phone_number");

                    t1.setText(name);
                    t2.setText(phoneNumber);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (toggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}