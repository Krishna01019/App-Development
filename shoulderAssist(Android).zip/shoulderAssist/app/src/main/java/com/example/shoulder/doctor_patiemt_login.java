package com.example.shoulder;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class doctor_patiemt_login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_doctor_patiemt_login);

        Button docLoginButton = findViewById(R.id.doclogin);
        Button patLoginButton = findViewById(R.id.patlogin);

        docLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to Doctor Login Activity
                Intent intent = new Intent(doctor_patiemt_login.this, doctor_login.class);
                startActivity(intent);
            }
        });

        patLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to Patient Login Activity
                Intent intent = new Intent(doctor_patiemt_login.this, patient_login.class);
                startActivity(intent);
            }
        });
    }
}
