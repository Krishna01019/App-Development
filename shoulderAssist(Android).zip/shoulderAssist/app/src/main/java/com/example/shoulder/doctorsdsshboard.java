package com.example.shoulder;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class doctorsdsshboard extends AppCompatActivity {

    private List<Patient> patientList;
    private ListView gridView;
    private SearchView searchView;
    private patientAdapter adapter;
    private String username;
    private DrawerLayout drawerLayout;
    private Toolbar toolbar;
    private NavigationView navigationView;
    private ActionBarDrawerToggle toggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctorsdsshboard);
        gridView = findViewById(R.id.Listview);
        patientList = new ArrayList<>();

        username = getIntent().getStringExtra("username");

        adapter = new patientAdapter(this, patientList);
        gridView.setAdapter(adapter);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.tb);
        drawerLayout = findViewById(R.id.mainmenu);
        // Set item click listener for navigation menu items
        setSupportActionBar(toolbar);

        toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.OpenDrawer, R.string.CloseDrawer
        );
        toggle.getDrawerArrowDrawable().setColor(getResources().getColor(R.color.white));
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.profile) {
                // Handle "Profile" item click
                Intent intent1 = new Intent(doctorsdsshboard.this, doc_profile.class);
                intent1.putExtra("username",username);
                startActivity(intent1);
            } else if (id == R.id.logout) {
                Intent intent2 = new Intent(doctorsdsshboard.this, doctor_patiemt_login.class);
                intent2.putExtra("username",username);
                startActivity(intent2);
                finish();
            }

            drawerLayout.closeDrawer(GravityCompat.START);
            return true;
        });

//        ImageView imageView9 = findViewById(R.id.imageView9);
//        imageView9.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // Handle click event for imageView9
//                drawerLayout.openDrawer(GravityCompat.START);
//            }
//        });

        // Set item click listener to open pat_view activity with selected patient details
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Patient selectedPatient = patientList.get(position);
                Intent intent = new Intent(doctorsdsshboard.this, patientdetails.class);
                intent.putExtra("username", selectedPatient.getuser());
                startActivity(intent);
            }
        });

        String url = ip.ipn + "patientlist.php";
        makeRequest(url);

        Button addButton = findViewById(R.id.button);
        Button listPatientsButton = findViewById(R.id.button3);
        Button videos = findViewById(R.id.button4);
        videos.setOnClickListener(view -> {
            Intent it = new Intent(this, videosadd_main.class);
            startActivity(it);
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click event for addButton
                Intent intent = new Intent(doctorsdsshboard.this, addpatient.class);
                intent.putExtra("username", username);
                startActivity(intent);
            }
        });

        listPatientsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click event for listPatientsButton
                Intent intent = new Intent(doctorsdsshboard.this, list_patients.class);
                startActivity(intent);
            }
        });
    }

    private void makeRequest(String url) {
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        System.out.println(response);
                        Log.d("Volley Response", response);
                        parseResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volley Error", error.toString());
                        Toast.makeText(doctorsdsshboard.this, "Error fetching data", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void parseResponse(String response) {
        Log.d("JSON Response", response);

        try {
            JSONObject jsonResponse = new JSONObject(response);
            JSONArray data = jsonResponse.getJSONArray("data");

            // Ensure there is data in the response
            if (data.length() > 0) {
                // Clear existing data
                patientList.clear();

                // Start from the end of the data array and add the last 5 patients
                int startIndex = Math.max(0, data.length() - 5);
                for (int i = startIndex; i < data.length(); i++) {
                    JSONObject patientObject = data.getJSONObject(i);
                    String patientId = patientObject.getString("patient_id");
                    String name = patientObject.getString("name");
                    String dp = patientObject.getString("dp");

                    // Add the patient to the list
                    patientList.add(new Patient(name, patientId, dp));
                }

                // Notify the adapter that the data set has changed
                adapter.notifyDataSetChanged();
            } else {
                // Handle case where there is no data in the response
                Log.e("Handle Response", "No data in the response");
            }
        } catch (JSONException e) {
            e.printStackTrace();
            // Handle JSON parsing error
            Log.e("Handle Response", "Error parsing JSON response: " + e.getMessage());
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (toggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
