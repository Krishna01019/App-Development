package com.example.shoulder;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class doc_profile extends AppCompatActivity {
    TextView t1, t2, t4, t5;
    private Button btn;

    private String username;
    // Replace this URL with your server URL
    private static final String fetchDataUrl = ip.ipn+"d_profile.php";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc_profile);
        username = getIntent().getStringExtra("username");
        t1 = findViewById(R.id.tx1);
        t2 = findViewById(R.id.tx2);
        t4 = findViewById(R.id.tx3);
        t5 = findViewById(R.id.tx4);
        Button bt = findViewById(R.id.btn);
        bt.setOnClickListener(view -> {
            Intent it = new Intent(this, doctor_patiemt_login.class);
            startActivity(it);
        });

        fetchData(username);

    }

    private void fetchData(final String doctorId) {
        StringRequest request = new StringRequest(Request.Method.POST, fetchDataUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("FetchDataResponse", response);
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optBoolean("success")) {
                                JSONObject data = jsonObject.getJSONObject("data");

                                t1.setText(data.optString("doctor_id"));
                                t2.setText(data.optString("name"));
                                t4.setText(data.optString("spaciality")); // Corrected key name
                                t5.setText(data.optString("phone_number"));
                            } else {
                                Toast.makeText(getApplicationContext(), "No results found", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "Error parsing JSON", Toast.LENGTH_SHORT).show();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Error fetching data: " + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("doctor_id", doctorId);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        queue.add(request);
    }
}
