package com.example.shoulder;

public class itemClass {

    String name;
    String patientId;
    int image;

    public itemClass(String name, String patientId, int image) {
        this.name = name;
        this.patientId = patientId;
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
