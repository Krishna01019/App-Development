package com.example.shoulder;


public class ip {
    public static String doc;
    static String ipn ="http://172.20.10.10:80/Shoulder/";
}

