package com.example.shoulder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;

import java.util.ArrayList;
import java.util.List;

public class videoAdapter extends BaseAdapter implements Filterable {

    private Context context;
    private List<Video> patientList;
    private List<Video> filteredList;

    public videoAdapter(Context context, List<Video> patients) {
        this.context = context;
        this.patientList = patients;
        this.filteredList = new ArrayList<>(patients);
    }

    @Override
    public int getCount() {
        return patientList.size();
    }

    @Override
    public Object getItem(int position) {
        return patientList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        patientAdapter.ViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.video_item, parent, false);
            holder = new patientAdapter.ViewHolder();

            holder.nameTextView = convertView.findViewById(R.id.textView5);

            //holder.im = convertView.findViewById(R.id.imageView5);
            convertView.setTag(holder);
        } else {
            holder = (patientAdapter.ViewHolder) convertView.getTag();
        }

        Video patient = patientList.get(position);

        holder.nameTextView.setText(patient.getName());

//        if(patient.getdp().equals("")){}
//        else{
//            String base64Image = patient.getdp();
//            if (base64Image != null && !base64Image.isEmpty()) {
//                byte[] decodedImageBytes = Base64.decode(base64Image, Base64.DEFAULT);
//                Bitmap decodedBitmap = BitmapFactory.decodeByteArray(decodedImageBytes, 0, decodedImageBytes.length);
//                Bitmap circularBitmap = Utils.getCircleBitmap(decodedBitmap);
//                holder.im.setImageBitmap(circularBitmap);
//            }
//        }


        return convertView;
    }

    static class ViewHolder {
        VideoView videoView;

        ImageView im;
        TextView userTextView;
        TextView nameTextView;
        TextView ageTextView;

    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults results = new FilterResults();
                List<Video> filtered = new ArrayList<>();
                if (constraint == null || constraint.length() == 0) {
                    // If constraint is null or empty, return the original list
                    filtered.addAll(patientList);
                } else {
                    String filterPattern = constraint.toString().toLowerCase().trim();
                    for (Video patient : patientList) {
                        // Filter the data based on the name containing the filter pattern
                        if (patient.getName().toLowerCase().contains(filterPattern)) {
                            filtered.add(patient);
                        }
                    }
                }
                results.values = filtered;
                results.count = filtered.size();
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                filteredList.clear();
                filteredList.addAll((List<Video>) results.values);
                notifyDataSetChanged();
            }
        };
    }
}
