-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2024 at 05:17 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoulder`
--

-- --------------------------------------------------------

--
-- Table structure for table `addpatient`
--

CREATE TABLE `addpatient` (
  `s.no` int(11) NOT NULL,
  `patient_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `age` int(20) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `phone_number` int(25) DEFAULT NULL,
  `admitted_on` date DEFAULT NULL,
  `diagnosis` text DEFAULT NULL,
  `examination` text DEFAULT NULL,
  `brief_history` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addpatient`
--

INSERT INTO `addpatient` (`s.no`, `patient_id`, `name`, `age`, `gender`, `phone_number`, `admitted_on`, `diagnosis`, `examination`, `brief_history`) VALUES
(25, 'p1234', 'lokesh', 21, 'male', 1234569878, '2024-05-01', 'hwrhiornonihguqjnklmq;lgm,lwjkbopjwrmkkpwmbnkwmbpojwijhbinr b', 'jjrbijierbnkwbopwjobjiwjrifjiwfkwejfgiIG4Hijwrbivrwgjirwjijg', 'irhiwh4ugouwn4igvjpiwh4gihihbijwojbiphwrnbowonbinibeh2q'),
(26, '009', 'Elamaran', 33, 'male', 9, '2001-03-24', 'Yes	', 'Yes	', 'Yes	'),
(27, 'p12345', 'chhe', 2024, 'male', 1245487, '2024-02-01', 'Sdsdsdgsdgsfgsgsgsdgsdgsds', '1.jshfef\n2\n', 'Theth jeet-har'),
(29, 'p1234980', 'luffy', 21, 'male', 1234569878, '2024-05-01', 'hwrhiornonihguqjnklmq;lgm,lwjkbopjwrmkkpwmbnkwmbpojwijhbinr b', 'jjrbijierbnkwbopwjobjiwjrifjiwfkwejfgiIG4Hijwrbivrwgjirwjijg', 'irhiwh4ugouwn4igvjpiwh4gihihbijwojbiphwrnbowonbinibeh2q'),
(33, 'p123498010', 'hello world', 21, 'male', 1234569878, '2024-05-01', 'hwrhiornonihguqjnklmq;lgm,lwjkbopjwrmkkpwmbnkwmbpojwijhbinr b', 'jjrbijierbnkwbopwjobjiwjrifjiwfkwejfgiIG4Hijwrbivrwgjirwjijg', 'irhiwh4ugouwn4igvjpiwh4gihihbijwojbiphwrnbowonbinibeh2q'),
(35, 'p12349801015', 'phone', 21, 'male', 1234569878, '2024-08-01', 'hwrhiornonihguqjnklmq;lgm,lwjkbopjwrmkkpwmbnkwmbpojwijhbinr b', 'jjrbijierbnkwbopwjobjiwjrifjiwfkwejfgiIG4Hijwrbivrwgjirwjijg', 'irhiwh4ugouwn4igvjpiwh4gihihbijwojbiphwrnbowonbinibeh2q'),
(36, 'ppppppp', 'pppp', 12, 'male', 12121212, '2024-02-02', 'ghjjdjjdjdjd', 'gfcdgfcghcg', 'hgcggfc'),
(37, NULL, 'aa', 54, 'male', 627283, '0000-00-00', 'hsbsb', 'gshsbs', 'gsbbs'),
(38, NULL, '', 0, '', 0, '0000-00-00', '', '', ''),
(39, NULL, 'gshsb', 12, 'male', 637383, '0000-00-00', 'bsbsbs', 'vsbsb', 'hshsh'),
(40, NULL, '', 0, '', 0, '0000-00-00', '', '', ''),
(41, NULL, '', 0, '', 0, '0000-00-00', '', '', ''),
(42, 'tttttt', '', 0, '', 0, '0000-00-00', '', '', ''),
(43, 'ssss', 'sss', 13, 'male', 6374849, '2023-12-03', 'hsbsbs\n', 'hsbsbdbd', 'hshshs'),
(44, 'ststt', 'ststs', 0, '', 0, '0000-00-00', '', '', ''),
(45, 'p8907', 'jkroll', 100, 'male ', 46875577, '0000-00-00', '', '', ''),
(47, '36215', 'ntr', 21, 'male', 0, '0000-00-00', '', '', ''),
(48, 'jeje21', 'mk145', 21, '', 0, '0000-00-00', '', '', ''),
(49, 'RTY001', 'Allu Arjun', 42, 'male', 9, '2020-03-24', 'Yes', 'Yay', 'Yes'),
(50, 'kfhg7898', 'jjj TV en', 0, 'fgb', 0, '0000-00-00', 'fi in', 'fi', 'RB'),
(51, '61496494', ';0,kunji', 0, '6th', 0, '0000-00-00', 'F6vf', 'Ff6vf6', '6fv6f6'),
(52, '975123', 'testing1', 60, 'male', 999, '0000-00-00', 'No		', '4545454	', 'Kasjlskjcjqsc'),
(53, 'p25691', 'gone56', 34, 'xbd', 0, '0000-00-00', 'xbdbdnd', 'dbdbd', 'dbdbd'),
(54, 'p277228', 'bdndjd', 0, '', 0, '0000-00-00', '', '', ''),
(55, 'p234590', 'bdjdjd', 0, '', 0, '0000-00-00', '', '', ''),
(56, 'p8484848', 'bdbdndnd', 0, '', 0, '0000-00-00', '', '', ''),
(57, 'p3738393', 'bddnnd', 0, '', 0, '0000-00-00', '', '', ''),
(58, 'p67537773', 'bfjfgtd', 0, '', 0, '0000-00-00', '', '', ''),
(59, 'p9001', 'jkrool', 0, '', 0, '0000-00-00', '', '', ''),
(60, 'p9087', 'lkjljl', 0, 'jokhke', 0, '0000-00-00', 'Ljkljkll', 'Jkljkl', 'Jkljkl'),
(62, '5252', 'testing2', 0, 'mfklsmv', 0, '0000-00-00', 'Mm			ko', 'Jk,Jkljkl', ',jk,jk,'),
(63, 'er123', 'e3fr', 0, 'qdq3d', 0, '0000-00-00', '23e23ed232', '23d23', '23ed23d'),
(64, 'pjack2', 'jack555', 7373, '', 0, '0000-00-00', '', '', ''),
(65, 'psbsbs', 'bsndnd', 0, 'dhdbd', 0, '0000-00-00', 'hdhe', 'hhe', 'hhehe');

-- --------------------------------------------------------

--
-- Table structure for table `daily_task`
--

CREATE TABLE `daily_task` (
  `s.no` int(11) NOT NULL,
  `patient_id` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `range_of_movement` varchar(50) DEFAULT NULL,
  `stretches` varchar(50) DEFAULT NULL,
  `strengthening_exercise` varchar(50) DEFAULT NULL,
  `feedback` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `daily_task`
--

INSERT INTO `daily_task` (`s.no`, `patient_id`, `date`, `range_of_movement`, `stretches`, `strengthening_exercise`, `feedback`) VALUES
(1, '0', '2024-02-25', 'yes', 'yes', 'no', 'not good hvgyhvj'),
(2, '0', '2024-02-25', 'yes', 'yes', 'no', 'not good hvgyhvj'),
(3, 'P12345', '2024-02-25', 'yes', 'yes', 'no', 'not good hvgyhvj'),
(4, 'P1234', '2024-02-25', 'yes', 'yes', 'no', 'not good hvgyhvj habibi'),
(5, 'P1234', '2024-02-28', 'yes', 'yes', 'no', 'not good hvgyhvj habibi'),
(6, 'P1234', '2024-02-29', 'No', 'No', 'No', 'hello world'),
(7, 'P1234', '2024-02-16', 'No', 'Yes', 'No', 'k '),
(8, 'P1234', '2024-02-16', 'No', 'Yes', 'No', 'k '),
(9, 'P1234', '2024-02-25', 'yes', 'yes', 'no', 'not good hvgyhvj habibi'),
(10, 'P1234', '2024-02-28', 'yes', 'yes', 'no', 'not good hvgyhvj habibi'),
(11, 'P1234', '2024-03-30', 'Yes', 'No', 'Yes', ' good'),
(12, 'P1234', '2024-03-31', 'No', 'No', 'No', '1000'),
(13, 'P1234', '2024-02-15', 'Yes', 'No', 'Yes', 'good all done'),
(14, 'p1234', '2024-03-25', 'yes', 'no', 'yes', 'hi'),
(15, 'P1234', '2024-04-04', 'Yes', 'Yes', 'Yes', 'worked all good movements'),
(16, 'P1234', '2024-04-15', 'Yes', 'Yes', 'Yes', 'chghj'),
(17, 'p1234', '2024-04-24', 'yes', 'yes', 'no', 'thank you'),
(18, 'p1234', '2024-04-24', 'yes', 'no', 'yes', '25'),
(19, 'kfhg7898', '2024-04-29', 'yes', 'yes', 'yes', 'fgbnn'),
(20, 'P1234', '2024-05-31', 'Yes', 'Yes', 'Yes', 'good well done'),
(21, 'P1234', '2024-05-30', 'Yes', 'Yes', 'Yes', 'good'),
(22, 'P1234', '2024-05-07', 'Yes', 'Yes', 'Yes', 'uur'),
(23, 'p1234', '2024-05-07', 'yes', 'yes', 'yes', 'fix do if f BN');

-- --------------------------------------------------------

--
-- Table structure for table `d_login`
--

CREATE TABLE `d_login` (
  `s.no` int(11) NOT NULL,
  `doctor_id` varchar(255) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `d_login`
--

INSERT INTO `d_login` (`s.no`, `doctor_id`, `password`) VALUES
(1, 'D2024001', 'welcome'),
(3, 'D2024002', 'welcome');

-- --------------------------------------------------------

--
-- Table structure for table `d_profile`
--

CREATE TABLE `d_profile` (
  `s.no` int(30) NOT NULL,
  `doctor_id` varchar(30) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `spaciality` varchar(30) DEFAULT NULL,
  `phone_number` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `d_profile`
--

INSERT INTO `d_profile` (`s.no`, `doctor_id`, `name`, `spaciality`, `phone_number`) VALUES
(1, 'D2024001', 'Naveen', 'Ortho', '9685476254'),
(4, 'D2024002', 'Naveen2', 'heart', '29929258');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `patient_id` varchar(30) NOT NULL,
  `yes/no` varchar(30) NOT NULL,
  `feedback` varchar(1000) NOT NULL,
  `date1` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`patient_id`, `yes/no`, `feedback`, `date1`) VALUES
('P2023001', 'yes', 'good', NULL),
('p12345', 'yes', 'good', '20-10-2003'),
('P2023001', 'yes', 'hri0jirn', '2012-01-12'),
('P2023001', 'yes', 'hri0jirn', '2012-01-12'),
('p1234', 'yes', 'hello ios developer', '20-10-2003'),
('p1234', 'yes', 'hello ios developer', '2024-02-21');

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `s_no` int(11) NOT NULL,
  `patient_id` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`s_no`, `patient_id`, `image`) VALUES
(15, 'p1234', 'image/7B68CE39-7E6D-428B-8E45-65A1C0B7F08B.jpg'),
(16, '009', 'image/852A54DC-AA0F-4B0D-9222-8A5AC6B86A13.jpg'),
(17, 'p12345', 'image/7BDDE6EF-3D6D-4371-A2EE-341C2998C5A0.jpg'),
(18, 'RTY001', 'image/0CDE48D3-D2B9-48C8-819D-8785FAB64447.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `patientsdetails`
--

CREATE TABLE `patientsdetails` (
  `s.no` int(11) NOT NULL,
  `patient_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `phone_number` varchar(11) DEFAULT NULL,
  `admitted_on` date DEFAULT NULL,
  `diagnosis` text DEFAULT NULL,
  `examination` text DEFAULT NULL,
  `brief_history` text DEFAULT NULL,
  `dp` varchar(300) DEFAULT NULL,
  `im` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patientsdetails`
--

INSERT INTO `patientsdetails` (`s.no`, `patient_id`, `name`, `age`, `gender`, `phone_number`, `admitted_on`, `diagnosis`, `examination`, `brief_history`, `dp`, `im`) VALUES
(19, 'p1234', 'lokesh', 21, 'male', '1234569878', '2024-05-01', 'hwrhiornonihguqjnklmq;lgm,lwjkbopjwrmkkpwmbnkwmbpojwijhbinr b', 'jjrbijierbnkwbopwjobjiwjrifjiwfkwejfgiIG4Hijwrbivrwgjirwjijg', 'irhiwh4ugouwn4igvjpiwh4gihihbijwojbiphwrnbowonbinibeh2q', 'image/image 102 (1).png', 'image/image 102 (1).png'),
(20, '009', 'Elamaran', 33, 'male', '9', '2001-03-24', 'Yes	', 'Yes	', 'Yes	', 'image/pur Ellipse 39.png', 'image/7.png'),
(21, 'p12345', 'chher', 2024, 'male', '1245487', '2024-02-01', 'Sdsdsdgsdgsfgsgsgsdgsdgsds', '1.jshfef\n2\n', 'Theth jeet-har', 'image/1714965050.jpg', 'image/7.png'),
(22, 'p1234980', 'luffy1', 22, 'djdh', 'hhr', '2024-05-01', 'hwrhiornonihguqjnklmq;lgm,lwjkbopjwrmkkpwmbnkwmbpojwijhbinr b', 'jjrbijierbnkwbopwjobjiwjrifjiwfkwejfgiIG4Hijwrbivrwgjirwjijg', 'irhiwh4ugouwn4igvjpiwh4gihihbijwojbiphwrnbowonbinibeh2q', 'image/1715082518.jpg', 'image/1715082519.jpg'),
(26, 'p123498010', 'hello worldhfdhhfgh', 21, 'male', '1234569878', '2024-05-01', 'hwrhiornonihguqjnklmq;lgm,lwjkbopjwrmkkpwmbnkwmbpojwijhbinr b', 'jjrbijierbnkwbopwjobjiwjrifjiwfkwejfgiIG4Hijwrbivrwgjirwjijg', 'irhiwh4ugouwn4igvjpiwh4gihihbijwojbiphwrnbowonbinibeh2q', 'image/dflt.png', 'image/7.png'),
(27, 'p12349801015', 'phone', 21, 'male', '1234569878', '2024-08-01', 'hwrhiornonihguqjnklmq;lgm,lwjkbopjwrmkkpwmbnkwmbpojwijhbinr b', 'jjrbijierbnkwbopwjobjiwjrifjiwfkwejfgiIG4Hijwrbivrwgjirwjijg', 'irhiwh4ugouwn4igvjpiwh4gihihbijwojbiphwrnbowonbinibeh2q', 'image/dflt.png', 'image/7.png'),
(28, 'ppppppp', 'pppp', 12, 'male', '12121212', '2024-02-02', 'ghjjdjjdjdjd', 'gfcdgfcghcg', 'hgcggfc', 'image/dflt.png', 'image/7.png'),
(34, 'tttttt', '', 0, '', '', '0000-00-00', '', '', '', 'image/1711204406.jpg', 'image/1711204406.jpg'),
(35, 'ssss', 'pp', 12, 'male', '12121212', '2024-02-22', 'ghjjdjjdjdjd', 'gfcdgfcghcg', 'hgcggfc', 'image/1711211926.jpg', 'image/1711211927.jpg'),
(37, 'p8907', 'jkroll', 100, 'male ', '46875577', '0000-00-00', '', '', '', 'image/image 102 (1).png', 'image/image 102 (1).png'),
(45, '36215', 'ntr', 21, 'male', '', '0000-00-00', '', '', '', 'image/dflt.php', 'image/7.png'),
(46, 'jeje21', 'mk145', 21, '', '', '0000-00-00', '', '', '', 'image/1712893327.jpg', 'image/7.png'),
(47, 'RTY001', 'Allu Arjun', 42, 'male', '009', '2020-03-24', 'Yes', 'Yay', 'Yes', 'image/1713681494.jpg', 'image/7.png'),
(48, 'kfhg7898', 'jjj TV en', 0, 'fgb', 'f757', '0000-00-00', 'fi in', 'fi', 'RB', 'image/1714306278.jpg', 'image/1714306278.jpg'),
(49, '61496494', ';0,kunji', 0, '6th', 'hnu', '0000-00-00', 'F6vf', 'Ff6vf6', '6fv6f6', 'image/dflt.php', 'image/7.png'),
(50, '975123', 'testing1', 60, 'male', '999', '0000-00-00', 'No		', '4545454	', 'Kasjlskjcjqsc', 'image/pur Ellipse 39.png', 'image/7.png'),
(51, 'p25691', 'sammy67', 98, 'male', '894445812', '0000-00-00', 'hello world', 'hello world', 'hello world', 'image/1714915108.jpg', 'image/1714915108.jpg'),
(52, 'p277228', 'bdndjdudjdjdj98', 0, '', '', '0000-00-00', '', '', '', 'image/1714915642.jpg', 'image/1714915643.jpg'),
(53, 'p234590', 'bdjdjd', 0, '', '', '0000-00-00', '', '', '', 'image/dflt.php', 'image/7.png'),
(54, 'p8484848', 'bdbdndnd', 0, '', '', '0000-00-00', '', '', '', 'image/dflt.php', 'image/7.png'),
(55, 'p3738393', 'bddnnd', 0, '', '', '0000-00-00', '', '', '', 'image/1714933225.jpg', 'image/1714933228.jpg'),
(56, 'p67537773', 'bfjfgtd', 0, '', '', '0000-00-00', '', '', '', 'image/1714933993.jpg', 'image/1714933995.jpg'),
(57, 'p9001', 'harry Potter1', 0, '', '', '0000-00-00', '', '', '', 'image/1715084511.jpg', 'image/1715084512.jpg'),
(58, 'p9087', 'lkjljl', 0, 'jokhke', 'ullikhit', '0000-00-00', 'Ljkljkll', 'Jkljkl', 'Jkljkl', 'image/B93B3B7B-40D5-45D4-AA1A-4B027B495CB3.jpg', NULL),
(59, '5252', 'jacklo', 0, 'aag', 'few', '0000-00-00', 'fea', 'aefea', 'edfefse', 'image/65B8EFFC-F1C0-4CD8-A5C0-E2B613C0B945.jpg', 'image/74EB5201-63F0-42E2-BDA9-6EC1F80EF856.jpg'),
(60, 'er123', 'jacksoarrow', 0, 'qdq3d', 'we’ve', '0000-00-00', '23e23ed232', '23d23', '23ed23d', 'image/1715083793.jpg', 'image/1715083794.jpg'),
(61, 'pjack2', 'jack555', 7373, '', '', '0000-00-00', '', '', '', NULL, NULL),
(62, 'psbsbs', 'bsndnd', 0, 'dhdbd', 'dbdbdb', '0000-00-00', 'hdhe', 'hhe', 'hhehe', 'image/11D1BA35-6FFB-49F1-93C4-97B24E136D03.jpg', 'image/1F4B6BA8-70FF-40C8-83A9-26B412639F43.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `patient_login`
--

CREATE TABLE `patient_login` (
  `s.no` int(11) NOT NULL,
  `patient_id` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_login`
--

INSERT INTO `patient_login` (`s.no`, `patient_id`, `password`) VALUES
(1, 'P2023001', '3001'),
(2, 'P2023001', '3001'),
(3, 'P2023001', '3001'),
(4, 'P2023001', '3001'),
(5, 'P2023001', '3001'),
(6, 'P2023001', '3001'),
(7, 'P2023001', '3001'),
(8, 'p1234', '1234'),
(9, '001', '001'),
(10, 'bvhjn', 'vhjn'),
(11, '53465463', '5463'),
(12, '', ''),
(13, 'p12345', '2345'),
(14, '', ''),
(15, '', ''),
(16, 'p1234567', '4567'),
(17, '', ''),
(18, 'Pi1234', '1234'),
(19, '202', '202'),
(20, 'p1324', '1324'),
(21, '', ''),
(22, 'p1234', '1234'),
(23, 'P2023001', '3001'),
(24, 'p1234', '1234'),
(25, 'p1234', '1234'),
(26, '009', '009'),
(27, 'p12345', '2345'),
(28, 'p1234', '1234'),
(29, 'p1234980', '4980'),
(30, NULL, ''),
(31, NULL, ''),
(32, NULL, ''),
(33, 'p123498010', '8010'),
(34, 'p123498010', '8010'),
(35, 'p12349801015', '1015'),
(36, 'ppppppp', 'pppp'),
(37, NULL, ''),
(38, NULL, ''),
(39, NULL, ''),
(40, NULL, ''),
(41, NULL, ''),
(42, 'tttttt', 'tttt'),
(43, 'ssss', 'ssss'),
(44, 'ststt', 'tstt'),
(45, 'p8907', '8907'),
(46, 'p8907', '8907'),
(47, '36215', '6215'),
(48, 'jeje21', 'je21'),
(49, 'RTY001', 'Y001'),
(50, 'kfhg7898', '7898'),
(51, '61496494', '6494'),
(52, '975123', '5123'),
(53, 'p25691', '5691'),
(54, 'p277228', '7228'),
(55, 'p234590', '4590'),
(56, 'p8484848', '4848'),
(57, 'p3738393', '8393'),
(58, 'p67537773', '7773'),
(59, 'p9001', '9001'),
(60, 'p9087', '9087'),
(61, 'p67537773', '7773'),
(62, '5252', '5252'),
(63, 'er123', 'r123'),
(64, 'pjack2', 'ack2'),
(65, 'psbsbs', 'bsbs');

-- --------------------------------------------------------

--
-- Table structure for table `pdf_upload`
--

CREATE TABLE `pdf_upload` (
  `s.no` int(11) NOT NULL,
  `patient_id` varchar(255) NOT NULL,
  `pdf` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `p_login`
--

CREATE TABLE `p_login` (
  `s.no` int(20) NOT NULL,
  `patient_id` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `p_login`
--

INSERT INTO `p_login` (`s.no`, `patient_id`, `password`) VALUES
(12, 'P2023001', '3001');

-- --------------------------------------------------------

--
-- Table structure for table `p_profile`
--

CREATE TABLE `p_profile` (
  `s.no` int(20) NOT NULL,
  `patient_id` varchar(20) DEFAULT NULL,
  `name` varchar(25) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `phone_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `p_profile`
--

INSERT INTO `p_profile` (`s.no`, `patient_id`, `name`, `age`, `gender`, `phone_number`) VALUES
(1, 'P2023001', 'abcdeef', 100, 'male', 111111111),
(3, 'p1234', 'lokesh', 100, 'male', 1234456789),
(4, '001', 'like ash', 15, 'male', 9),
(5, 'bvhjn', '', 0, '', 0),
(6, '53465463', 'bnbvhj', 0, 'gjygj', 0),
(7, '', '', 0, '', 0),
(8, 'p12345', 'mohith', 21, 'male', 165465495),
(9, '', '', 0, '', 0),
(10, '', '', 0, '', 0),
(11, 'p1234567', 'what', 100, 'make', 214235),
(12, '', '', 0, '', 0),
(13, 'Pi1234', 'Sushanth reddy', 21, 'male', 2147483647),
(14, '202', 'Katie', 24, 'Male', 2147483647),
(15, 'p1324', 'Svedberg', 0, 'Edward', 0),
(16, '', '', 0, '', 0),
(17, 'p1234', 'Lokesh', 21, 'male', 54645444),
(18, 'P2023001', 'postman', 100, 'binary', 1234569878),
(19, 'p1234', 'lokesh', 21, 'male', 1234569878),
(20, 'p1234', 'lokesh', 21, 'male', 1234569878),
(21, '009', 'Elamaran', 33, 'male', 9),
(22, 'p12345', 'chhe', 2024, 'male', 1245487),
(23, 'p1234980', 'luffy', 21, 'male', 1234569878),
(24, NULL, NULL, NULL, NULL, NULL),
(25, NULL, NULL, NULL, NULL, NULL),
(26, NULL, NULL, NULL, NULL, NULL),
(27, 'p123498010', 'hello world', 21, 'male', 1234569878),
(28, 'p12349801015', 'phone', 21, 'male', 1234569878),
(29, 'ppppppp', 'pppp', 12, 'male', 12121212),
(30, NULL, 'aa', 54, 'male', 627283),
(31, NULL, '', 0, '', 0),
(32, NULL, 'gshsb', 12, 'male', 637383),
(33, NULL, '', 0, '', 0),
(34, NULL, '', 0, '', 0),
(35, 'tttttt', '', 0, '', 0),
(36, 'ssss', 'sss', 13, 'male', 6374849),
(37, 'ststt', 'ststs', 0, '', 0),
(38, 'p8907', 'jkroll', 100, 'male ', 46875577),
(39, '36215', 'ntr', 21, 'male', 0),
(40, 'jeje21', 'mk145', 21, '', 0),
(41, 'RTY001', 'Allu Arjun', 42, 'male', 9),
(42, 'kfhg7898', 'jjj TV en', 0, 'fgb', 0),
(43, '61496494', ';0,kunji', 0, '6th', 0),
(44, '975123', 'testing1', 60, 'male', 999),
(45, 'p25691', 'gone56', 34, 'xbd', 0),
(46, 'p277228', 'bdndjd', 0, '', 0),
(47, 'p234590', 'bdjdjd', 0, '', 0),
(48, 'p8484848', 'bdbdndnd', 0, '', 0),
(49, 'p3738393', 'bddnnd', 0, '', 0),
(50, 'p67537773', 'bfjfgtd', 0, '', 0),
(51, 'p9001', 'jkrool', 0, '', 0),
(52, 'p9087', 'lkjljl', 0, 'jokhke', 0),
(53, '5252', 'testing2', 0, 'mfklsmv', 0),
(54, 'er123', 'e3fr', 0, 'qdq3d', 0),
(55, 'pjack2', 'jack555', 7373, '', 0),
(56, 'psbsbs', 'bsndnd', 0, 'dhdbd', 0);

-- --------------------------------------------------------

--
-- Table structure for table `questionaries`
--

CREATE TABLE `questionaries` (
  `s.no` int(30) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `1` int(11) NOT NULL,
  `2` int(11) NOT NULL,
  `3` int(11) NOT NULL,
  `4` int(11) NOT NULL,
  `5` int(11) NOT NULL,
  `6` int(11) NOT NULL,
  `7` int(11) NOT NULL,
  `8` int(11) NOT NULL,
  `9` int(11) NOT NULL,
  `10` int(11) NOT NULL,
  `11` int(11) NOT NULL,
  `12` int(11) NOT NULL,
  `13` int(11) NOT NULL,
  `total_sum` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questionaries`
--

INSERT INTO `questionaries` (`s.no`, `patient_id`, `date`, `1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`, `9`, `10`, `11`, `12`, `13`, `total_sum`) VALUES
(1, 0, '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 0, '0000-00-00', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3, 0, '2024-02-01', 4, 5, 6, 1, 2, 5, 3, 5, 2, 5, 3, 1, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `score`
--

CREATE TABLE `score` (
  `s.no` int(11) NOT NULL,
  `patient_id` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `total_score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `score`
--

INSERT INTO `score` (`s.no`, `patient_id`, `date`, `total_score`) VALUES
(1, 'P2024001', '2024-02-19', 50),
(2, 'P2024001', '2024-02-19', 50),
(3, 'p1234', '2024-02-21', 500),
(4, 'p1234', '2024-02-21', 100),
(5, 'P1234', '2024-02-20', 25),
(6, 'P1234', '2024-02-22', 25),
(7, 'P1234', '2024-02-28', 37),
(8, 'P1234', '2024-02-28', 37),
(9, 'P1234', '2024-02-28', 38),
(10, 'P1234', '2024-02-28', 45),
(11, 'P1234', '2024-03-04', 38),
(12, 'P1234', '2024-03-04', 11),
(13, 'P1234', '2024-03-09', 31),
(14, 'p1234', '2024-03-23', 51),
(15, 'P1234', '2024-04-04', 59),
(16, 'P1234', '2024-04-15', 47),
(17, 'p1234', '2024-04-23', 32),
(18, 'p1234', '2024-04-23', 0),
(19, 'kfhg7898', '2024-04-28', 41),
(20, 'P1234', '2024-05-07', 5),
(21, 'P1234', '2024-05-07', 5),
(22, 'P1234', '2024-05-07', 10),
(23, 'p1234', '2024-05-07', 55);

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `video` varchar(1000) NOT NULL,
  `video_title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `video`, `video_title`) VALUES
(82, 'videos/basdd.mp4', 'gt65'),
(83, 'videos/goodzoro.mp4', 'gt800'),
(84, 'videos/verybad.mp4', 'gt800'),
(85, 'videos/verybad.mp4', 'gt800'),
(86, 'videos/42B6566B-D8D5-47DE-B253-C000DBEE0FB5.mov', 'fight'),
(87, 'videos/verybad.mp4', 'gt800'),
(88, 'videos/verybad.mp4', 'gt800'),
(89, 'videos/goodzoro.mp4', 'helloworld'),
(90, 'videos/goodzoro.mp4', 'helloworld'),
(91, 'videos/Screenrecording_20240322_124159_com.ea.gp.fifamobile.mp4', 'Maldini'),
(92, 'videos/shoulder1.mp4', 'gaamechanger1');

-- --------------------------------------------------------

--
-- Table structure for table `videos1`
--

CREATE TABLE `videos1` (
  `id` int(11) NOT NULL,
  `video1` varchar(1000) NOT NULL,
  `video_title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `videos1`
--

INSERT INTO `videos1` (`id`, `video1`, `video_title`) VALUES
(5, 'videos1/bird_small_animal_feathers_river_679.mp4', 'zoro'),
(6, 'videos1/bird_small_animal_feathers_river_679.mp4', 'zoro'),
(24, 'videos1\\basdd.mp4', 'car'),
(25, 'videos1\\goodzoro.mp4', 'bike'),
(26, 'videos1/goodzoro.mp4', 'bike'),
(27, 'videos1/Screenrecording_20240322_124159_com.ea.gp.fifamobile.mp4', 'Maldini');

-- --------------------------------------------------------

--
-- Table structure for table `videos2`
--

CREATE TABLE `videos2` (
  `id` int(11) NOT NULL,
  `videos2` varchar(1000) NOT NULL,
  `video_title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `videos2`
--

INSERT INTO `videos2` (`id`, `videos2`, `video_title`) VALUES
(11, 'videos2/goodzoro.mp4', 'bike');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addpatient`
--
ALTER TABLE `addpatient`
  ADD PRIMARY KEY (`s.no`),
  ADD UNIQUE KEY `patient_id` (`patient_id`);

--
-- Indexes for table `daily_task`
--
ALTER TABLE `daily_task`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `d_login`
--
ALTER TABLE `d_login`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `d_profile`
--
ALTER TABLE `d_profile`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `patientsdetails`
--
ALTER TABLE `patientsdetails`
  ADD PRIMARY KEY (`s.no`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `patient_login`
--
ALTER TABLE `patient_login`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `pdf_upload`
--
ALTER TABLE `pdf_upload`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `p_login`
--
ALTER TABLE `p_login`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `p_profile`
--
ALTER TABLE `p_profile`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `questionaries`
--
ALTER TABLE `questionaries`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `score`
--
ALTER TABLE `score`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos1`
--
ALTER TABLE `videos1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos2`
--
ALTER TABLE `videos2`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addpatient`
--
ALTER TABLE `addpatient`
  MODIFY `s.no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `daily_task`
--
ALTER TABLE `daily_task`
  MODIFY `s.no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `d_login`
--
ALTER TABLE `d_login`
  MODIFY `s.no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `d_profile`
--
ALTER TABLE `d_profile`
  MODIFY `s.no` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `patientsdetails`
--
ALTER TABLE `patientsdetails`
  MODIFY `s.no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `patient_login`
--
ALTER TABLE `patient_login`
  MODIFY `s.no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `pdf_upload`
--
ALTER TABLE `pdf_upload`
  MODIFY `s.no` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `p_login`
--
ALTER TABLE `p_login`
  MODIFY `s.no` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `p_profile`
--
ALTER TABLE `p_profile`
  MODIFY `s.no` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `questionaries`
--
ALTER TABLE `questionaries`
  MODIFY `s.no` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `score`
--
ALTER TABLE `score`
  MODIFY `s.no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `videos1`
--
ALTER TABLE `videos1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `videos2`
--
ALTER TABLE `videos2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `patientsdetails`
--
ALTER TABLE `patientsdetails`
  ADD CONSTRAINT `patientsdetails_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `addpatient` (`patient_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
