//
//  videostwoViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 27/01/24.
//

import UIKit

class videostwoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

  

}
//func doctorLogin() {
//            
//            
//            let formDat/Users/sail/Downloads/shoulder pathology1/shoulder pathology1/Base.lproj/Main.storyboarda = ["doctor_id": doctorId.text ?? "",
//                            "password": passwordField.text ?? ""]
//   
//
//    APIHandler().postAPIValues(type: DoctorLogin.self, apiUrl: ServiceAPI.doctorLoginURL , method: "POST", formData: formData) { [weak self] result in
//                         switch result {
//                         case .success(let data):
//                            print(data)
//                            DispatchQueue.main.async {
//                                if data.success == true {
//                                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//                                    let vc = storyBoard.instantiateViewController(withIdentifier: "doctorhomeViewController")
//                                    as! doctorhomeViewController
//                                    self?.navigationController?.pushViewController(vc, animated:true)
//                                    
//                                }else {
//                                if let navigation = self?.navigationController  {
//                                    DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
//                                }
//                                   
//                                   
//                                }
//                            }
//                         case .failure(let error):
//                            print(error)
//                            DispatchQueue.main.async {
//                            if let navigation = self?.navigationController  {
//                                DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
//                            }
//                            }
//                         }
//                        
//        }
//                 
// 
//        
//}
