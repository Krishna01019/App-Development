//
//  questionariespatientViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 25/01/24.
//

import UIKit

class questionariespatientViewController: UIViewController {
    
    
    @IBOutlet weak var btn1: UIButton!
    
    @IBOutlet weak var btn2: UIButton!
    
    @IBOutlet weak var submitCurve: UIButton!
    
    @IBOutlet weak var btn3: UIButton!
    
    @IBOutlet weak var btn4: UIButton!
    
    
    @IBOutlet weak var btm5: UIButton!
    
    @IBOutlet weak var btn6: UIButton!
    
   
    @IBOutlet weak var btn7: UIButton!
    
    
    @IBOutlet weak var btn8: UIButton!
    
    
    @IBOutlet weak var btn9: UIButton!
    
    
    @IBOutlet weak var btn10: UIButton!
    
    @IBOutlet weak var btn11: UIButton!
    
    
    @IBOutlet weak var btn12: UIButton!
    
    
    @IBOutlet weak var btn13: UIButton!
    
    @IBOutlet weak var btn14: UIButton!
    
    @IBOutlet weak var btn15: UIButton!
    
    
    @IBOutlet weak var btn16: UIButton!
    
    
    
    @IBOutlet weak var btn17: UIButton!
    
    
    
    @IBOutlet weak var btn18: UIButton!
    
    
    @IBOutlet weak var btn19: UIButton!
    
    @IBOutlet weak var btn20: UIButton!
    
    @IBOutlet weak var btn21: UIButton!
    
    
    
    @IBOutlet weak var btn22: UIButton!
    
    @IBOutlet weak var btn23: UIButton!
    
    @IBOutlet weak var btn24: UIButton!
    
    
    @IBOutlet weak var btn25: UIButton!
    
    @IBOutlet weak var btn26: UIButton!
    
   
    @IBOutlet weak var btn27: UIButton!
    
    @IBOutlet weak var btn28: UIButton!
    
    @IBOutlet weak var btn29: UIButton!
    
    
    @IBOutlet weak var btn30: UIButton!
    
    @IBOutlet weak var btn31: UIButton!
    
    @IBOutlet weak var btn32: UIButton!
    
    @IBOutlet weak var btn33: UIButton!
    
    @IBOutlet weak var btn34: UIButton!
    
    @IBOutlet weak var btn35: UIButton!
    
    @IBOutlet weak var btn36: UIButton!
    
    
    @IBOutlet weak var btn37: UIButton!
    
    
    @IBOutlet weak var btn38: UIButton!
    
    @IBOutlet weak var btn39: UIButton!
    
    
    @IBOutlet weak var btn40: UIButton!
    
    @IBOutlet weak var btn41: UIButton!
    
    @IBOutlet weak var btn42: UIButton!
    
    
    @IBOutlet weak var btn43: UIButton!
    
    @IBOutlet weak var btn44: UIButton!
   
    @IBOutlet weak var btn45: UIButton!
    
    
    @IBOutlet weak var btn46: UIButton!
    
    
    @IBOutlet weak var btn47: UIButton!
    
    
    @IBOutlet weak var btn48: UIButton!
    
    @IBOutlet weak var btn49: UIButton!
    
    @IBOutlet weak var btn50: UIButton!
    
    @IBOutlet weak var btn51: UIButton!
    
    
    @IBOutlet weak var btn52: UIButton!
    
    
    @IBOutlet weak var btn53: UIButton!
    
    @IBOutlet weak var btn54: UIButton!
    
    @IBOutlet weak var btn55: UIButton!
    
    @IBOutlet weak var btn56: UIButton!
    
    @IBOutlet weak var btn57: UIButton!
    
    @IBOutlet weak var btn58: UIButton!
    
    @IBOutlet weak var btn59: UIButton!
    
    @IBOutlet weak var btn60: UIButton!
    
    @IBOutlet weak var btn61: UIButton!
    
    
    @IBOutlet weak var btn62: UIButton!
    
    @IBOutlet weak var btn63: UIButton!
    
    @IBOutlet weak var btn64: UIButton!
    
    
    @IBOutlet weak var btn65: UIButton!

    @IBOutlet weak var tamilbtn: UIButton!
    @IBOutlet weak var tamilTap: UIButton!
    @IBOutlet weak var englishBtn: UIButton!
    @IBOutlet weak var englishtap: UIButton!
    @IBOutlet weak var submitBtnRadius: UIButton!
    @IBOutlet weak var totalScorelbl: UILabel!
    @IBOutlet weak var firstQL: UILabel!
    @IBOutlet weak var secondQl: UILabel!
    
    
    @IBOutlet weak var thirdQl: UILabel!
    
    @IBOutlet weak var fourthQl: UILabel!
    
    @IBOutlet weak var fifthQl: UILabel!
    
    @IBOutlet weak var sixthQl: UILabel!
    
    @IBOutlet weak var seventhQl: UILabel!
    
    @IBOutlet weak var eighthQl: UILabel!
    
    @IBOutlet weak var ninethQl: UILabel!
    
    
    
    @IBOutlet weak var tenthQl: UILabel!
    
    
    @IBOutlet weak var eleventhQl: UILabel!
    
    @IBOutlet weak var twelvethQl: UILabel!
    
    @IBOutlet weak var thirteenthQl: UILabel!
    
    
    
    
    
    
    
    
    var firstAnswer = Int()
    var secondAnswer = Int()
    var thirdAnswer = Int()
    var fourthAnswer = Int()
    var fifthAnswer = Int()
    var sixthAnswer = Int()
    var seventhAnswer = Int()
    var eighthAnswer = Int()
    var ninethAnswer = Int()
    var tenthAnswer = Int()
    var eleventhAnswer = Int()
    var twelvethAnswer = Int()
    var thirteenthAnswer = Int()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //submitCurve.layer.cornerRadius = 15
        submitBtnRadius.layer.cornerRadius = 15

       
    }
    

    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
        
    }
    
    
    
    @IBAction func stAnsTape(_ sender: UIButton) {
        
        switch sender.tag {
        case 1:
            btn1.setImage(UIImage(named: "select"), for: .normal)
            btn2.setImage(UIImage(named: "radient button"), for: .normal)
            btn3.setImage(UIImage(named: "radient button"), for: .normal)
            btn4.setImage(UIImage(named: "radient button"), for: .normal)
            btm5.setImage(UIImage(named: "radient button"), for: .normal)
            firstAnswer = 1
        case 2:
            btn1.setImage(UIImage(named: "radient button"), for: .normal)
            btn2.setImage(UIImage(named: "select"), for: .normal)
            btn3.setImage(UIImage(named: "radient button"), for: .normal)
            btn4.setImage(UIImage(named: "radient button"), for: .normal)
            btm5.setImage(UIImage(named: "radient button"), for: .normal)
            firstAnswer = 2
        case 3:
            btn1.setImage(UIImage(named: "radient button"), for: .normal)
            btn2.setImage(UIImage(named: "radient button"), for: .normal)
            btn3.setImage(UIImage(named: "select"), for: .normal)
            btn4.setImage(UIImage(named: "radient button"), for: .normal)
            btm5.setImage(UIImage(named: "radient button"), for: .normal)
            firstAnswer = 3
        case 4:
            btn1.setImage(UIImage(named: "radient button"), for: .normal)
            btn2.setImage(UIImage(named: "radient button"), for: .normal)
            btn3.setImage(UIImage(named: "radient button"), for: .normal)
            btn4.setImage(UIImage(named: "select"), for: .normal)
            btm5.setImage(UIImage(named: "radient button"), for: .normal)
            firstAnswer = 4
        case 5:
            btn1.setImage(UIImage(named: "radient button"), for: .normal)
            btn2.setImage(UIImage(named: "radient button"), for: .normal)
            btn3.setImage(UIImage(named: "radient button"), for: .normal)
            btn4.setImage(UIImage(named: "radient button"), for: .normal)
            btm5.setImage(UIImage(named: "select"), for: .normal)
            firstAnswer = 5
        
        default:
            print("")
        }
    
    }
    
    
    
    
    @IBAction func secondAnsTap(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            btn6.setImage(UIImage(named: "select"), for: .normal)
            btn7.setImage(UIImage(named: "radient button"), for: .normal)
            btn8.setImage(UIImage(named: "radient button"), for: .normal)
            btn9.setImage(UIImage(named: "radient button"), for: .normal)
            btn10.setImage(UIImage(named: "radient button"), for: .normal)
            secondAnswer = 1
        case 2:
            btn6.setImage(UIImage(named: "radient button"), for: .normal)
            btn7.setImage(UIImage(named: "select"), for: .normal)
            btn8.setImage(UIImage(named: "radient button"), for: .normal)
            btn9.setImage(UIImage(named: "radient button"), for: .normal)
            btn10.setImage(UIImage(named: "radient button"), for: .normal)
            secondAnswer = 2
        case 3:
            btn6.setImage(UIImage(named: "radient button"), for: .normal)
            btn7.setImage(UIImage(named: "radient button"), for: .normal)
            btn8.setImage(UIImage(named: "select"), for: .normal)
            btn9.setImage(UIImage(named: "radient button"), for: .normal)
            btn10.setImage(UIImage(named: "radient button"), for: .normal)
            secondAnswer = 3
        case 4:
            btn6.setImage(UIImage(named: "radient button"), for: .normal)
            btn7.setImage(UIImage(named: "radient button"), for: .normal)
            btn8.setImage(UIImage(named: "radient button"), for: .normal)
            btn9.setImage(UIImage(named: "select"), for: .normal)
            btn10.setImage(UIImage(named: "radient button"), for: .normal)
            secondAnswer = 4
        case 5:
            btn6.setImage(UIImage(named: "radient button"), for: .normal)
            btn7.setImage(UIImage(named: "radient button"), for: .normal)
            btn8.setImage(UIImage(named: "radient button"), for: .normal)
            btn9.setImage(UIImage(named: "radient button"), for: .normal)
            btn10.setImage(UIImage(named: "select"), for: .normal)
            secondAnswer = 5
        
        default:
            print("")
        }
    }
    
    @IBAction func thirdAnsTap(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            btn11.setImage(UIImage(named: "select"), for: .normal)
            btn12.setImage(UIImage(named: "radient button"), for: .normal)
            btn13.setImage(UIImage(named: "radient button"), for: .normal)
            btn14.setImage(UIImage(named: "radient button"), for: .normal)
            btn15.setImage(UIImage(named: "radient button"), for: .normal)
            thirdAnswer = 1
        case 2:
            btn11.setImage(UIImage(named: "radient button"), for: .normal)
            btn12.setImage(UIImage(named: "select"), for: .normal)
            btn13.setImage(UIImage(named: "radient button"), for: .normal)
            btn14.setImage(UIImage(named: "radient button"), for: .normal)
            btn15.setImage(UIImage(named: "radient button"), for: .normal)
            thirdAnswer = 2
        case 3:
            btn11.setImage(UIImage(named: "radient button"), for: .normal)
            btn12.setImage(UIImage(named: "radient button"), for: .normal)
            btn13.setImage(UIImage(named: "select"), for: .normal)
            btn14.setImage(UIImage(named: "radient button"), for: .normal)
            btn15.setImage(UIImage(named: "radient button"), for: .normal)
            thirdAnswer = 3
        case 4:
            btn11.setImage(UIImage(named: "radient button"), for: .normal)
            btn12.setImage(UIImage(named: "radient button"), for: .normal)
            btn13.setImage(UIImage(named: "radient button"), for: .normal)
            btn14.setImage(UIImage(named: "select"), for: .normal)
            btn15.setImage(UIImage(named: "radient button"), for: .normal)
            thirdAnswer = 4
        case 5:
            btn11.setImage(UIImage(named: "radient button"), for: .normal)
            btn12.setImage(UIImage(named: "radient button"), for: .normal)
            btn13.setImage(UIImage(named: "radient button"), for: .normal)
            btn14.setImage(UIImage(named: "radient button"), for: .normal)
            btn15.setImage(UIImage(named: "select"), for: .normal)
            thirdAnswer = 5
        
        default:
            print("")
        }
    }
    
    @IBAction func fourthAnsTap(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            btn16.setImage(UIImage(named: "select"), for: .normal)
            btn17.setImage(UIImage(named: "radient button"), for: .normal)
            btn18.setImage(UIImage(named: "radient button"), for: .normal)
            btn19.setImage(UIImage(named: "radient button"), for: .normal)
            btn20.setImage(UIImage(named: "radient button"), for: .normal)
            fourthAnswer = 1
        case 2:
            btn16.setImage(UIImage(named: "radient button"), for: .normal)
            btn17.setImage(UIImage(named: "select"), for: .normal)
            btn18.setImage(UIImage(named: "radient button"), for: .normal)
            btn19.setImage(UIImage(named: "radient button"), for: .normal)
            btn20.setImage(UIImage(named: "radient button"), for: .normal)
            fourthAnswer = 2
        case 3:
            btn16.setImage(UIImage(named: "radient button"), for: .normal)
            btn17.setImage(UIImage(named: "radient button"), for: .normal)
            btn18.setImage(UIImage(named: "select"), for: .normal)
            btn19.setImage(UIImage(named: "radient button"), for: .normal)
            btn20.setImage(UIImage(named: "radient button"), for: .normal)
            fourthAnswer = 3
        case 4:
            btn16.setImage(UIImage(named: "radient button"), for: .normal)
            btn17.setImage(UIImage(named: "radient button"), for: .normal)
            btn18.setImage(UIImage(named: "radient button"), for: .normal)
            btn19.setImage(UIImage(named: "select"), for: .normal)
            btn20.setImage(UIImage(named: "radient button"), for: .normal)
            fourthAnswer = 4
        case 5:
            btn16.setImage(UIImage(named: "radient button"), for: .normal)
            btn17.setImage(UIImage(named: "radient button"), for: .normal)
            btn18.setImage(UIImage(named: "radient button"), for: .normal)
            btn19.setImage(UIImage(named: "radient button"), for: .normal)
            btn20.setImage(UIImage(named: "select"), for: .normal)
            fourthAnswer = 5
        
        default:
            print("")
        }
        
    }
    
        
    @IBAction func fifthAnsTap(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            btn21.setImage(UIImage(named: "select"), for: .normal)
            btn22.setImage(UIImage(named: "radient button"), for: .normal)
            btn23.setImage(UIImage(named: "radient button"), for: .normal)
            btn24.setImage(UIImage(named: "radient button"), for: .normal)
            btn25.setImage(UIImage(named: "radient button"), for: .normal)
            fifthAnswer = 1
        case 2:
            btn21.setImage(UIImage(named: "radient button"), for: .normal)
            btn22.setImage(UIImage(named: "select"), for: .normal)
            btn23.setImage(UIImage(named: "radient button"), for: .normal)
            btn24.setImage(UIImage(named: "radient button"), for: .normal)
            btn25.setImage(UIImage(named: "radient button"), for: .normal)
            fifthAnswer = 2
        case 3:
            btn21.setImage(UIImage(named: "radient button"), for: .normal)
            btn22.setImage(UIImage(named: "radient button"), for: .normal)
            btn23.setImage(UIImage(named: "select"), for: .normal)
            btn24.setImage(UIImage(named: "radient button"), for: .normal)
            btn25.setImage(UIImage(named: "radient button"), for: .normal)
            fifthAnswer = 3
        case 4:
            btn21.setImage(UIImage(named: "radient button"), for: .normal)
            btn22.setImage(UIImage(named: "radient button"), for: .normal)
            btn23.setImage(UIImage(named: "radient button"), for: .normal)
            btn24.setImage(UIImage(named: "select"), for: .normal)
            btn25.setImage(UIImage(named: "radient button"), for: .normal)
            fifthAnswer = 4
        case 5:
            btn21.setImage(UIImage(named: "radient button"), for: .normal)
            btn22.setImage(UIImage(named: "radient button"), for: .normal)
            btn23.setImage(UIImage(named: "radient button"), for: .normal)
            btn24.setImage(UIImage(named: "radient button"), for: .normal)
            btn25.setImage(UIImage(named: "select"), for: .normal)
            fifthAnswer = 5
        
        default:
            print("")
        }
        
    }
    
    
    @IBAction func sixthAnsTap(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            btn26.setImage(UIImage(named: "select"), for: .normal)
            btn27.setImage(UIImage(named: "radient button"), for: .normal)
            btn28.setImage(UIImage(named: "radient button"), for: .normal)
            btn29.setImage(UIImage(named: "radient button"), for: .normal)
            btn30.setImage(UIImage(named: "radient button"), for: .normal)
            sixthAnswer = 1
        case 2:
            btn26.setImage(UIImage(named: "radient button"), for: .normal)
            btn27.setImage(UIImage(named: "select"), for: .normal)
            btn28.setImage(UIImage(named: "radient button"), for: .normal)
            btn29.setImage(UIImage(named: "radient button"), for: .normal)
            btn30.setImage(UIImage(named: "radient button"), for: .normal)
            sixthAnswer = 2
        case 3:
            btn26.setImage(UIImage(named: "radient button"), for: .normal)
            btn27.setImage(UIImage(named: "radient button"), for: .normal)
            btn28.setImage(UIImage(named: "select"), for: .normal)
            btn29.setImage(UIImage(named: "radient button"), for: .normal)
            btn30.setImage(UIImage(named: "radient button"), for: .normal)
            sixthAnswer = 3
        case 4:
            btn26.setImage(UIImage(named: "radient button"), for: .normal)
            btn27.setImage(UIImage(named: "radient button"), for: .normal)
            btn28.setImage(UIImage(named: "radient button"), for: .normal)
            btn29.setImage(UIImage(named: "select"), for: .normal)
            btn30.setImage(UIImage(named: "radient button"), for: .normal)
            sixthAnswer = 4
        case 5:
            btn26.setImage(UIImage(named: "radient button"), for: .normal)
            btn27.setImage(UIImage(named: "radient button"), for: .normal)
            btn28.setImage(UIImage(named: "radient button"), for: .normal)
            btn29.setImage(UIImage(named: "radient button"), for: .normal)
            btn30.setImage(UIImage(named: "select"), for: .normal)
            sixthAnswer = 5
        
        default:
            print("")
        }
        
    }
    
    @IBAction func seventhAnsTap(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            btn31.setImage(UIImage(named: "select"), for: .normal)
            btn32.setImage(UIImage(named: "radient button"), for: .normal)
            btn33.setImage(UIImage(named: "radient button"), for: .normal)
            btn34.setImage(UIImage(named: "radient button"), for: .normal)
            btn35.setImage(UIImage(named: "radient button"), for: .normal)
            seventhAnswer = 1
        case 2:
            btn31.setImage(UIImage(named: "radient button"), for: .normal)
            btn32.setImage(UIImage(named: "select"), for: .normal)
            btn33.setImage(UIImage(named: "radient button"), for: .normal)
            btn34.setImage(UIImage(named: "radient button"), for: .normal)
            btn35.setImage(UIImage(named: "radient button"), for: .normal)
            seventhAnswer = 2
        case 3:
            btn31.setImage(UIImage(named: "radient button"), for: .normal)
            btn32.setImage(UIImage(named: "radient button"), for: .normal)
            btn33.setImage(UIImage(named: "select"), for: .normal)
            btn34.setImage(UIImage(named: "radient button"), for: .normal)
            btn35.setImage(UIImage(named: "radient button"), for: .normal)
            seventhAnswer = 3
        case 4:
            btn31.setImage(UIImage(named: "radient button"), for: .normal)
            btn32.setImage(UIImage(named: "radient button"), for: .normal)
            btn33.setImage(UIImage(named: "radient button"), for: .normal)
            btn34.setImage(UIImage(named: "select"), for: .normal)
            btn35.setImage(UIImage(named: "radient button"), for: .normal)
            seventhAnswer = 4
        case 5:
            btn31.setImage(UIImage(named: "radient button"), for: .normal)
            btn32.setImage(UIImage(named: "radient button"), for: .normal)
            btn33.setImage(UIImage(named: "radient button"), for: .normal)
            btn34.setImage(UIImage(named: "radient button"), for: .normal)
            btn35.setImage(UIImage(named: "select"), for: .normal)
            seventhAnswer = 5
        
        default:
            print("")
        }
        
        
    }
    
    @IBAction func eightAnsBtn(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            btn36.setImage(UIImage(named: "select"), for: .normal)
            btn37.setImage(UIImage(named: "radient button"), for: .normal)
            btn38.setImage(UIImage(named: "radient button"), for: .normal)
            btn39.setImage(UIImage(named: "radient button"), for: .normal)
            btn40.setImage(UIImage(named: "radient button"), for: .normal)
            eighthAnswer = 1
        case 2:
            btn36.setImage(UIImage(named: "radient button"), for: .normal)
            btn37.setImage(UIImage(named: "select"), for: .normal)
            btn38.setImage(UIImage(named: "radient button"), for: .normal)
            btn39.setImage(UIImage(named: "radient button"), for: .normal)
            btn40.setImage(UIImage(named: "radient button"), for: .normal)
            eighthAnswer = 2
        case 3:
            btn36.setImage(UIImage(named: "radient button"), for: .normal)
            btn37.setImage(UIImage(named: "radient button"), for: .normal)
            btn38.setImage(UIImage(named: "select"), for: .normal)
            btn39.setImage(UIImage(named: "radient button"), for: .normal)
            btn40.setImage(UIImage(named: "radient button"), for: .normal)
            eighthAnswer = 3
        case 4:
            btn36.setImage(UIImage(named: "radient button"), for: .normal)
            btn37.setImage(UIImage(named: "radient button"), for: .normal)
            btn38.setImage(UIImage(named: "radient button"), for: .normal)
            btn39.setImage(UIImage(named: "select"), for: .normal)
            btn40.setImage(UIImage(named: "radient button"), for: .normal)
            eighthAnswer = 4
        case 5:
            btn36.setImage(UIImage(named: "radient button"), for: .normal)
            btn37.setImage(UIImage(named: "radient button"), for: .normal)
            btn38.setImage(UIImage(named: "radient button"), for: .normal)
            btn39.setImage(UIImage(named: "radient button"), for: .normal)
            btn40.setImage(UIImage(named: "select"), for: .normal)
            eighthAnswer = 5
        
        default:
            print("")
        }
        
    }
    
    @IBAction func ninethAnsTap(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            btn41.setImage(UIImage(named: "select"), for: .normal)
            btn42.setImage(UIImage(named: "radient button"), for: .normal)
            btn43.setImage(UIImage(named: "radient button"), for: .normal)
            btn44.setImage(UIImage(named: "radient button"), for: .normal)
            btn45.setImage(UIImage(named: "radient button"), for: .normal)
            ninethAnswer = 1
        case 2:
            btn41.setImage(UIImage(named: "radient button"), for: .normal)
            btn42.setImage(UIImage(named: "select"), for: .normal)
            btn43.setImage(UIImage(named: "radient button"), for: .normal)
            btn44.setImage(UIImage(named: "radient button"), for: .normal)
            btn45.setImage(UIImage(named: "radient button"), for: .normal)
            ninethAnswer = 2
        case 3:
            btn41.setImage(UIImage(named: "radient button"), for: .normal)
            btn42.setImage(UIImage(named: "radient button"), for: .normal)
            btn43.setImage(UIImage(named: "select"), for: .normal)
            btn44.setImage(UIImage(named: "radient button"), for: .normal)
            btn45.setImage(UIImage(named: "radient button"), for: .normal)
            ninethAnswer = 3
        case 4:
            btn41.setImage(UIImage(named: "radient button"), for: .normal)
            btn42.setImage(UIImage(named: "radient button"), for: .normal)
            btn43.setImage(UIImage(named: "radient button"), for: .normal)
            btn44.setImage(UIImage(named: "select"), for: .normal)
            btn45.setImage(UIImage(named: "radient button"), for: .normal)
            ninethAnswer = 4
        case 5:
            btn41.setImage(UIImage(named: "radient button"), for: .normal)
            btn42.setImage(UIImage(named: "radient button"), for: .normal)
            btn43.setImage(UIImage(named: "radient button"), for: .normal)
            btn44.setImage(UIImage(named: "radient button"), for: .normal)
            btn45.setImage(UIImage(named: "select"), for: .normal)
            ninethAnswer = 4
        
        default:
            print("")
        }
        
    }
    
  
    @IBAction func tenthAnsTap(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            btn46.setImage(UIImage(named: "select"), for: .normal)
            btn47.setImage(UIImage(named: "radient button"), for: .normal)
            btn48.setImage(UIImage(named: "radient button"), for: .normal)
            btn49.setImage(UIImage(named: "radient button"), for: .normal)
            btn50.setImage(UIImage(named: "radient button"), for: .normal)
            tenthAnswer = 1
        case 2:
            btn46.setImage(UIImage(named: "radient button"), for: .normal)
            btn47.setImage(UIImage(named: "select"), for: .normal)
            btn48.setImage(UIImage(named: "radient button"), for: .normal)
            btn49.setImage(UIImage(named: "radient button"), for: .normal)
            btn50.setImage(UIImage(named: "radient button"), for: .normal)
            tenthAnswer = 2
        case 3:
            btn46.setImage(UIImage(named: "radient button"), for: .normal)
            btn47.setImage(UIImage(named: "radient button"), for: .normal)
            btn48.setImage(UIImage(named: "select"), for: .normal)
            btn49.setImage(UIImage(named: "radient button"), for: .normal)
            btn50.setImage(UIImage(named: "radient button"), for: .normal)
            tenthAnswer = 3
        case 4:
            btn46.setImage(UIImage(named: "radient button"), for: .normal)
            btn47.setImage(UIImage(named: "radient button"), for: .normal)
            btn48.setImage(UIImage(named: "radient button"), for: .normal)
            btn49.setImage(UIImage(named: "select"), for: .normal)
            btn50.setImage(UIImage(named: "radient button"), for: .normal)
            tenthAnswer = 4
        case 5:
            btn46.setImage(UIImage(named: "radient button"), for: .normal)
            btn47.setImage(UIImage(named: "radient button"), for: .normal)
            btn48.setImage(UIImage(named: "radient button"), for: .normal)
            btn49.setImage(UIImage(named: "radient button"), for: .normal)
            btn50.setImage(UIImage(named: "select"), for: .normal)
            tenthAnswer = 5
        
        default:
            print("")
        }
        
    }
    
    @IBAction func eleventhAnsTap(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            btn51.setImage(UIImage(named: "select"), for: .normal)
            btn52.setImage(UIImage(named: "radient button"), for: .normal)
            btn53.setImage(UIImage(named: "radient button"), for: .normal)
            btn54.setImage(UIImage(named: "radient button"), for: .normal)
            btn55.setImage(UIImage(named: "radient button"), for: .normal)
            eleventhAnswer = 1
        case 2:
            btn51.setImage(UIImage(named: "radient button"), for: .normal)
            btn52.setImage(UIImage(named: "select"), for: .normal)
            btn53.setImage(UIImage(named: "radient button"), for: .normal)
            btn54.setImage(UIImage(named: "radient button"), for: .normal)
            btn55.setImage(UIImage(named: "radient button"), for: .normal)
            eleventhAnswer = 2
        case 3:
            btn51.setImage(UIImage(named: "radient button"), for: .normal)
            btn52.setImage(UIImage(named: "radient button"), for: .normal)
            btn53.setImage(UIImage(named: "select"), for: .normal)
            btn54.setImage(UIImage(named: "radient button"), for: .normal)
            btn55.setImage(UIImage(named: "radient button"), for: .normal)
            eleventhAnswer = 3
        case 4:
            btn51.setImage(UIImage(named: "radient button"), for: .normal)
            btn52.setImage(UIImage(named: "radient button"), for: .normal)
            btn53.setImage(UIImage(named: "radient button"), for: .normal)
            btn54.setImage(UIImage(named: "select"), for: .normal)
            btn55.setImage(UIImage(named: "radient button"), for: .normal)
            eleventhAnswer = 4
        case 5:
            btn51.setImage(UIImage(named: "radient button"), for: .normal)
            btn52.setImage(UIImage(named: "radient button"), for: .normal)
            btn53.setImage(UIImage(named: "radient button"), for: .normal)
            btn54.setImage(UIImage(named: "radient button"), for: .normal)
            btn55.setImage(UIImage(named: "select"), for: .normal)
            eleventhAnswer = 5
        
        default:
            print("")
        }
        
    }
    
    @IBAction func twelvethAnsTap(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            btn56.setImage(UIImage(named: "select"), for: .normal)
            btn57.setImage(UIImage(named: "radient button"), for: .normal)
            btn58.setImage(UIImage(named: "radient button"), for: .normal)
            btn59.setImage(UIImage(named: "radient button"), for: .normal)
            btn60.setImage(UIImage(named: "radient button"), for: .normal)
            twelvethAnswer = 1
        case 2:
            btn56.setImage(UIImage(named: "radient button"), for: .normal)
            btn57.setImage(UIImage(named: "select"), for: .normal)
            btn58.setImage(UIImage(named: "radient button"), for: .normal)
            btn59.setImage(UIImage(named: "radient button"), for: .normal)
            btn60.setImage(UIImage(named: "radient button"), for: .normal)
            twelvethAnswer = 2
        case 3:
            btn56.setImage(UIImage(named: "radient button"), for: .normal)
            btn57.setImage(UIImage(named: "radient button"), for: .normal)
            btn58.setImage(UIImage(named: "select"), for: .normal)
            btn59.setImage(UIImage(named: "radient button"), for: .normal)
            btn60.setImage(UIImage(named: "radient button"), for: .normal)
            twelvethAnswer = 3
        case 4:
            btn56.setImage(UIImage(named: "radient button"), for: .normal)
            btn57.setImage(UIImage(named: "radient button"), for: .normal)
            btn58.setImage(UIImage(named: "radient button"), for: .normal)
            btn59.setImage(UIImage(named: "select"), for: .normal)
            btn60.setImage(UIImage(named: "radient button"), for: .normal)
            twelvethAnswer = 4
        case 5:
            btn56.setImage(UIImage(named: "radient button"), for: .normal)
            btn57.setImage(UIImage(named: "radient button"), for: .normal)
            btn58.setImage(UIImage(named: "radient button"), for: .normal)
            btn59.setImage(UIImage(named: "radient button"), for: .normal)
            btn60.setImage(UIImage(named: "select"), for: .normal)
            twelvethAnswer = 5
        
        default:
            print("")
        }
    }
    
    @IBAction func ThirteenthAnsTap(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            btn61.setImage(UIImage(named: "select"), for: .normal)
            btn62.setImage(UIImage(named: "radient button"), for: .normal)
            btn63.setImage(UIImage(named: "radient button"), for: .normal)
            btn64.setImage(UIImage(named: "radient button"), for: .normal)
            btn65.setImage(UIImage(named: "radient button"), for: .normal)
            thirteenthAnswer = 1
        case 2:
            btn61.setImage(UIImage(named: "radient button"), for: .normal)
            btn62.setImage(UIImage(named: "select"), for: .normal)
            btn63.setImage(UIImage(named: "radient button"), for: .normal)
            btn64.setImage(UIImage(named: "radient button"), for: .normal)
            btn65.setImage(UIImage(named: "radient button"), for: .normal)
            thirteenthAnswer = 2
        case 3:
            btn61.setImage(UIImage(named: "radient button"), for: .normal)
            btn62.setImage(UIImage(named: "radient button"), for: .normal)
            btn63.setImage(UIImage(named: "select"), for: .normal)
            btn64.setImage(UIImage(named: "radient button"), for: .normal)
            btn65.setImage(UIImage(named: "radient button"), for: .normal)
            thirteenthAnswer = 3
        case 4:
            btn61.setImage(UIImage(named: "radient button"), for: .normal)
            btn62.setImage(UIImage(named: "radient button"), for: .normal)
            btn63.setImage(UIImage(named: "radient button"), for: .normal)
            btn64.setImage(UIImage(named: "select"), for: .normal)
            btn65.setImage(UIImage(named: "radient button"), for: .normal)
            thirteenthAnswer = 4
        case 5:
            btn61.setImage(UIImage(named: "radient button"), for: .normal)
            btn62.setImage(UIImage(named: "radient button"), for: .normal)
            btn63.setImage(UIImage(named: "radient button"), for: .normal)
            btn64.setImage(UIImage(named: "radient button"), for: .normal)
            btn65.setImage(UIImage(named: "select"), for: .normal)
            thirteenthAnswer = 5
        
        default:
            print("")
        }
        
        
    }
    
    
    @IBAction func englishTap(_ sender: Any) {
        
        englishBtn.setImage(UIImage(named: "select"), for: .normal)
        tamilbtn.setImage(UIImage(named: "radient button"), for: .normal)
        firstQL.text = "1.Open a tight or new jar"
        secondQl.text = "2.write"
        thirdQl.text = "3.Turn a key"
        fourthQl.text = "4.push open a heavy door"
        fifthQl.text = "5.Garden or do yard work"
        sixthQl.text = "6.change a lightbulb overhead"
        seventhQl.text = "7.Use a knife to cut food"
        eighthQl.text = "8.prepare a meal"
        ninethQl.text = "9.Make a bed"
        tenthQl.text = "10.carry a shopping bag or briefcase"
        eleventhQl.text = "11.carry a heavy object (over 10bs)"
        twelvethQl.text = "12.wash your back"
        thirteenthQl.text = "13.sexual activities"
        
    }
    
    @IBAction func tamilTap(_ sender: Any) {
        tamilbtn.setImage(UIImage(named: "select"), for: .normal)
        englishBtn.setImage(UIImage(named: "radient button"), for: .normal)
        firstQL.text = "1. இறுக்கமான அல்லது புதிய ஜாடியைத் திறக்கவும்"
        secondQl.text = "2.எழுதவும்"
        thirdQl.text = "3.ஒரு விசையைத் திருப்பவும்"
        fourthQl.text = "4. ஒரு கனமான கதவைத் திற"
        fifthQl.text = "5. தோட்டம் அல்லது முற்றத்தில் வேலை செய்யுங்கள்"
        sixthQl.text = "6. ஒரு லைட்பல்பை மாற்றவும்"
        seventhQl.text = "7.உணவை வெட்ட கத்தியை பயன்படுத்தவும்"
        eighthQl.text = "8.உணவை சமைக்கவும்"
        ninethQl.text = "9.ஒரு படுக்கையை உருவாக்குங்கள்"
        tenthQl.text = "10. ஒரு கடை பை அல்லது பிரீஃப்கேஸை எடுத்துச் செல்லுங்கள்"
        eleventhQl.text = "11. ஒரு கனமான பொருளை எடுத்துச் செல்லுங்கள் (10 பவுண்டுகளுக்கு மேல்)"
        twelvethQl.text = "12. உங்கள் முதுகைக் கழுவவும்"
        thirteenthQl.text = "13.பாலியல் செயல்பாடுகள்"
        
        
    }
    
    
    @IBAction func submitTapped(_ sender: Any) {
        let total = firstAnswer + secondAnswer + thirdAnswer + fourthAnswer + fifthAnswer + sixthAnswer + seventhAnswer + eighthAnswer + ninethAnswer + tenthAnswer + eleventhAnswer + twelvethAnswer + thirteenthAnswer
        totalScorelbl.text = "\(total)"
      //  DataManager.shared.totalScore = "\(total)"
        if totalScorelbl.text ?? "" != "" {
            updateScore()
        }else {
            
        }
       
    }
    
    
    
    func updateScore() {
        
        
        // Get the current date and time
        let currentDate = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.string(from: currentDate)

        print("Current date and time: \(dateString)")

                

        let formData = ["patient_id": DataManager.shared.patinetId,
                        "date": dateString,
                        "total_score": totalScorelbl.text ?? ""
                ]


        APIHandler().postAPIValues(type: DailyTask.self, apiUrl: ServiceAPI.scoreUpdate , method: "POST", formData: formData) { [weak self] result in
                             switch result {
                             case .success(let data):
                                print(data)
                                DispatchQueue.main.async {
                                    if data.status == "success" {
                                        if let navigation = self?.navigationController  {
                                            DataManager.shared.sendMessage(title: "Message", message: data.message, navigation: navigation)
                                        }
                                        
                                    }else {
                                    if let navigation = self?.navigationController  {
                                        DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                                    }
                                       
                                       
                                    }
                                }
                             case .failure(let error):
                                print(error)
                                DispatchQueue.main.async {
                                if let navigation = self?.navigationController  {
                                    DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                                }
                                }
                             }
                            
            }
                     
     
            
    }
    
    
}
    
    
  
    
