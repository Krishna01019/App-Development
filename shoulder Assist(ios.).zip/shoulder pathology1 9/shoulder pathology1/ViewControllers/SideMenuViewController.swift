//
//  SideMenuViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 17/04/24.
//

import UIKit

protocol SideMenuDelegate {
    func tap(index:Int)
}

class SideMenuViewController: UIViewController {
    
    
    
    var delegate:SideMenuDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func closeBtnTap(_ sender: Any) {
        self.dismiss(animated: false)
    }
    
    @IBAction func profileTap(_ sender: Any) {
        self.delegate?.tap(index: 1)
        self.dismiss(animated: false)
    }
    
    
    @IBAction func logoutTap(_ sender: Any) {
        self.delegate?.tap(index: 2)
        self.dismiss(animated: false)
    }
    
}
