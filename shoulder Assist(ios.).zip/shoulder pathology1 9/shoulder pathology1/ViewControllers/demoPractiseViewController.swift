//
//  demoPractiseViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 03/02/24.
//

import UIKit

class demoPractiseViewController: UIViewController {

    @IBOutlet weak var practiseTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

  
    }
    

}
