//
//  helpViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 14/02/24.
//

import UIKit

class helpViewController: UIViewController {
    
    
    
    @IBOutlet weak var doctorName: UILabel!
    

    @IBOutlet weak var docId: UILabel!
    
    
    @IBOutlet weak var docPhone: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        doctorName.text = DataManager.shared.doctorName
        docId.text = DataManager.shared.doctorId
       
       
    }
    

    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
        
    }
    
}
