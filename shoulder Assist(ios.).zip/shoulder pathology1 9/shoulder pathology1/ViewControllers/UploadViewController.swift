//
//  UploadViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 16/02/24.
//

import UIKit
import AVFoundation
import MobileCoreServices
class UploadViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    
    @IBOutlet weak var uploadBtn: UIButton!
    
    @IBOutlet weak var videoName: UITextField!
    
    var header = String()
    
    
    
    var uploadVideosApi = String()
    
    var videoURLName: URL?
     var selectVdo: String?
    

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    
    @IBAction func backBtn(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
    @IBAction func uploadTap(_ sender: Any) {
        
        if videoName.text ?? "" != "" {
        
        DispatchQueue.main.async{ [self] in
            let videoPicker = UIImagePickerController()
            videoPicker.sourceType = .photoLibrary
             videoPicker.mediaTypes = [kUTTypeMovie as String]
            videoPicker.videoExportPreset = AVAssetExportPreset1280x720
            videoPicker.delegate = self
            present(videoPicker, animated: true, completion: nil)
        }
        
    }
    else {
        
        if let nav = self.navigationController {
        DataManager.shared.sendMessage(title: "Alert", message: "Give video ttile", navigation: nav)
        }
    }
    
}
    @IBAction func uploadAtn(_ sender: Any) {
        postAPI()
    }
}

extension UploadViewController {

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {


        if let videoURL = info[.mediaURL] as? URL {
            // You can use the selected video URL here
            print("Selected video URL: \(videoURL)")
            self.uploadVideo(videoURL: videoURL,info: info)
        }
        picker.dismiss(animated: true, completion: nil)
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    func uploadVideo(videoURL:URL,info: [UIImagePickerController.InfoKey : Any]){
        if let fileSize = try? FileManager.default.attributesOfItem(atPath: videoURL.path)[.size] as? Int {
            let sizeInMegabytes = Double(fileSize) / (1024 * 1024)
            if sizeInMegabytes <= 100 {
                self.videoURLName = videoURL
                if let videoUrl = info[UIImagePickerController.InfoKey.mediaURL] as? URL {
                    let videoName = videoUrl.lastPathComponent
                    //                    uploadVdoLbl.text = videoName
                    uploadBtn.setTitle("Video Added", for: .normal)
                    uploadBtn.setImage(UIImage(systemName: "checkmark.seal.fill"), for: .normal)
                    //                    uploadVdoBtn.setTitleColor(UIColor.systemGreen, for: .normal)
                    //                    postAPI(url: videoURLName!)
                }
            } else{
                if let nav = self.navigationController {
                    DataManager.shared.sendMessage(title: "Alert", message: "The video size must be under 100MB", navigation: nav)
                }
                print("Video Size: \(sizeInMegabytes) MB")
            }
        }
        //    func uploadVideo(videoURL:URL,info: [UIImagePickerController.InfoKey : Any]){
        //        if let fileSize = try? FileManager.default.attributesOfItem(atPath: videoURL.path)[.size] as? Int {
        //            let sizeInMegabytes = Double(fileSize) / (1024 * 1024)
        //            if sizeInMegabytes <= 100 {
        //                self.videoURLName = videoURL
        //                if let videoUrl = info[UIImagePickerController.InfoKey.mediaURL] as? URL {
        //                    let videoNames = videoUrl.lastPathComponent
        //                    uploadBtn.setTitle("Video Added", for: .normal)
        ////                    uploadBtn.setImage(UIImage(systemName: "checkmark.seal.fill"), for: .normal)
        //                    uploadBtn.setTitleColor(UIColor.systemGreen, for: .normal)
        //
        //                }
        //            } else{
        //                if let nav = self.navigationController {
        //                DataManager.shared.sendMessage(title: "Alert", message: "The video size must be under 10MB", navigation: nav)
        //                }
        //
        //            }
        //            print("Video Size: \(sizeInMegabytes) MB")
        //        }
        //    }
        
        
        
        
        //func postAPI(){
        //
        //
        //        let apiURL = ServiceAPI.uploadVideo+uploadVideosApi
        //        print("API URL:", apiURL)
        //        let boundary = UUID().uuidString
        //        var request = URLRequest(url: URL(string: apiURL)!)
        //        request.httpMethod = "POST"
        //        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        //
        //        var body = Data()
        //        let formData: [String: Any] = [
        //            "video_title": videoName.text ?? "",
        //
        //            ]
        //        print("formData :" , formData)
        //        for (key, value) in formData {
        //            body.append(contentsOf: "--\(boundary)\r\n".utf8)
        //            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
        //            body.append(contentsOf: "\(value)\r\n".utf8)
        //        }
        //        let videoData = try! Data(contentsOf: videoURLName!)
        //        body.append(contentsOf: "--\(boundary)\r\n".utf8)
        //        body.append(contentsOf: "Content-Disposition: form-data; name=\"uploaded_file\"; uploaded_file=\"\(UUID().uuidString).mov\"\r\n".utf8)
        //        body.append(contentsOf: "Content-Type: video/quicktime\r\n\r\n".utf8)
        //        body.append(contentsOf: videoData)
        //        body.append(contentsOf: "\r\n".utf8)
        //        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
        //        request.httpBody = body
        //
        //        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
        //            if let error = error {
        //                print("Error: \(error)")
        //                return
        //            }
        //
        //            if let httpResponse = response as? HTTPURLResponse {
        //                print("Status code: \(httpResponse.statusCode)")
        //
        //                if let data = data {
        //                    print("Response Data:", String(data: data, encoding: .utf8) ?? "")
        //                    DispatchQueue.main.async {
        //
        //                        if let nav = self.navigationController {
        //                        DataManager.shared.sendMessage(title: "Message", message: "Videos Updated Succesfully", navigation: nav)
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //
        //        task.resume()
            }
        func postAPI(){
            let apiURL = ServiceAPI.uploadVideo+uploadVideosApi
            print("API URL:", apiURL)
            print("API URL:", apiURL)
            let boundary = UUID().uuidString
            var request = URLRequest(url: URL(string: apiURL)!)
            request.httpMethod = "POST"
            request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
            
            var body = Data()
            let formData: [String: Any] = [
                "video_title": videoName.text ?? ""
            ]
            for (key, value) in formData {
                body.append(contentsOf: "--\(boundary)\r\n".utf8)
                body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
                body.append(contentsOf: "\(value)\r\n".utf8)
            }
            print("formData :", formData)
            let videoData = try! Data(contentsOf: videoURLName!)
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"uploaded_file\"; filename=\"\(UUID().uuidString).mov\"\r\n".utf8)
            body.append(contentsOf: "Content-Type: video/quicktime\r\n\r\n".utf8)
            body.append(contentsOf: videoData)
            body.append(contentsOf: "\r\n".utf8)
            body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
            request.httpBody = body
            print("body :", body)
            let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                if let error = error {
                    print("Error: \(error)")
                    return
                }
                
                if let httpResponse = response as? HTTPURLResponse {
                    print("Status code: \(httpResponse.statusCode)")
                    
                    if let data = data {
                        print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                        DispatchQueue.main.async {
                            if let nav = self.navigationController {
                                DataManager.shared.sendMessage(title: "Message", message: "Videos Updated Succesfully", navigation: nav)
                            }
                        }
                    }
                }
            }
            
            task.resume()
        }
//    }
        
//        func postAPI(){
//            
//           
//            let apiURL = ServiceAPI.uploadVideo+uploadVideosApi
//            print("API URL:", apiURL)
//            let boundary = UUID().uuidString
//            var request = URLRequest(url: URL(string: apiURL)!)
//            request.httpMethod = "POST"
//            request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//            
//            var body = Data()
//            let formData: [String: Any] = [
//                "video_title": videoName.text ?? "",
//              
//                ]
//            for (key, value) in formData {
//                body.append(contentsOf: "--\(boundary)\r\n".utf8)
//                body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
//                body.append(contentsOf: "\(value)\r\n".utf8)
//            }
//            let videoData = try! Data(contentsOf: videoURLName!)
//            body.append(contentsOf: "--\(boundary)\r\n".utf8)
//            body.append(contentsOf: "Content-Disposition: form-data; name=\"uploaded_file\"; uploaded_file=\"\(UUID().uuidString).mov\"\r\n".utf8)
//            body.append(contentsOf: "Content-Type: video/quicktime\r\n\r\n".utf8)
//            body.append(contentsOf: videoData)
//            body.append(contentsOf: "\r\n".utf8)
//            body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
//            request.httpBody = body
//            
//            let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
//                if let error = error {
//                    print("Error: \(error)")
//                    return
//                }
//                
//                if let httpResponse = response as? HTTPURLResponse {
//                    print("Status code: \(httpResponse.statusCode)")
//                    
//                    if let data = data {
//                        print("Response Data:", String(data: data, encoding: .utf8) ?? "")
//                        DispatchQueue.main.async {
//                         
//                            if let nav = self.navigationController {
//                            DataManager.shared.sendMessage(title: "Message", message: "Videos Updated Succesfully", navigation: nav)
//                            }
//                        }
//                    }
//                }
//            }
//            
//            task.resume()
//        }

}
