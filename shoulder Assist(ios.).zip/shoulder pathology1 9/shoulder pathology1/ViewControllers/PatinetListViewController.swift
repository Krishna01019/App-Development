import UIKit

class PatinetListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
    @IBOutlet weak var patientTableView: UITableView!
    @IBOutlet weak var searchField: UISearchBar!
    
    
    var patientsData: [PatientListNewData] = []
    var filteredPatientListData: [PatientListNewData] = []
    
    var patientListDetails: PatientListNew? {
        didSet {
            patientsData = patientListDetails?.data ?? []
            filteredPatientListData = patientsData // Initially showing all data
            DispatchQueue.main.async {
                self.patientTableView.reloadData()
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchField.delegate = self
        
        patientTableView.delegate = self
        patientTableView.dataSource = self
        
        let cellNib = UINib(nibName: "PatientDetailsCell", bundle: nil)
        patientTableView.register(cellNib, forCellReuseIdentifier: "cell")
        
        // Initial API call to fetch patients
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        patientListApi()
    }
    
    func patientListApi() {
        let formData = [String: String]()
        
        APIHandler().postAPIValues(type: PatientListNew.self, apiUrl: ServiceAPI.patinetListURL, method: "POST", formData: formData) { [weak self] result in
            switch result {
            case .success(let data):
                print(data)
                self?.patientListDetails = data
                
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    if let navigation = self?.navigationController {
                        DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                    }
                }
            }
        }
    }
    
    @IBAction func backbtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    // MARK: - UISearchBarDelegate
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            filteredPatientListData = patientsData
        } else {
            filteredPatientListData = patientsData.filter { patient in
                return patient.name.lowercased().contains(searchText.lowercased()) || patient.patientID.lowercased().contains(searchText.lowercased())
            }
        }
        
        patientTableView.reloadData()
        
        if filteredPatientListData.isEmpty {
            showAlert(message: "The patient doesn't exist")
        }
    }
    
    func showAlert(message: String) {
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    // MARK: - UITableViewDelegate and UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredPatientListData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! PatientDetailsCell
        
        //        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? PatientDetailsCell else {
        //            return UITableViewCell()
        //        }
        let patient = filteredPatientListData[indexPath.row]
        cell.patientId.text = patient.patientID
        cell.nameFiled.text = patient.name
        loadImage(url: patient.image ?? "image/dflt.png" , imageView: cell.profileImage)
        
//        let str = patient.dp
//        if let imageData = Data(base64Encoded: str) {
//            if let image = UIImage(data: imageData) {
//                loadImageData(data: image, imageView: cell.profileImage)
//            }
//        }
        return cell
    }
        
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 100.0
        }
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            if let vc = storyboard.instantiateViewController(withIdentifier: "patientdetailsViewController") as? patientdetailsViewController {
                vc.newPatientId = filteredPatientListData[indexPath.row].patientID
                navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
    
    

