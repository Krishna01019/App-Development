//
//  ProtocolViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 04/05/24.
//

import UIKit
import WebKit

class ProtocolViewController: UIViewController {

    
    @IBOutlet weak var webView: WKWebView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
     
            let path = Bundle.main.path(forResource: "protocols", ofType: "pdf")
            let url = URL(fileURLWithPath: path!)
            let request = URLRequest(url: url)
            webView.load(request)
       
    }
    
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
}
