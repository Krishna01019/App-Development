//
//  patientdetailsViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 11/01/24.
//

import UIKit

class 
patientdetailsViewController: UIViewController , UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    
    
    
    @IBOutlet weak var viewVideosCurve: UIButton!
    
    @IBOutlet weak var videosBtnCurve: UIButton!
   
    @IBOutlet weak var submtCurve: UIButton!
    
    @IBOutlet weak var patientId: UITextField!
    
    
    @IBOutlet weak var name: UITextField!
    
    
    @IBOutlet weak var mobileNumber: UITextField!
    
    @IBOutlet weak var age: UITextField!
    
    @IBOutlet weak var gender: UITextField!
    
    
    @IBOutlet weak var admittedOn: UITextField!
    
    
    @IBOutlet weak var diagnosis: UITextView!
    
    
    @IBOutlet weak var examination: UITextView!
    
    
    @IBOutlet weak var brief: UITextView!
    
    

    @IBOutlet weak var profileImage: UIImageView!
    
    
    @IBOutlet weak var imageView: UIImageView!
    
    
    var newPatientId = String()
    
    
    
    let imagePicker = UIImagePickerController()
   
    var selectedImage = [UIImage]()
    var selectedProfileImage = [UIImage]()
 
   
    var profileUploadImage = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePicker.delegate = self
        imagePicker.allowsEditing = true

  
        videosBtnCurve.layer.cornerRadius=15
        viewVideosCurve.layer.cornerRadius=15
        submtCurve.layer.cornerRadius=15
       
       
        
        
        doctorDeatils()
        
        imageView.layer.borderWidth = 1.0
        imageView.layer.borderColor = UIColor.black.cgColor
        imageView.layer.cornerRadius = 10.0
        
        
        
        
        examination.layer.borderWidth = 1.0
        examination.layer.borderColor = UIColor.black.cgColor
        examination.layer.cornerRadius = 10.0
        
        
        examination.layer.borderWidth = 1.0
        examination.layer.borderColor = UIColor.black.cgColor
        examination.layer.cornerRadius = 10.0
        
        
        brief.layer.borderWidth = 1.0
        brief.layer.borderColor = UIColor.black.cgColor
        brief.layer.cornerRadius = 10.0
        
        
        

        
        diagnosis.layer.borderWidth = 1.0
        diagnosis.layer.borderColor = UIColor.black.cgColor
        diagnosis.layer.cornerRadius = 10.0
        
        
        

    }
    
    
    
    
    func doctorDeatils() {
          
          let formData = ["patient_id": newPatientId]
          
          APIHandler().postAPIValues(type: PatientDetails.self, apiUrl: ServiceAPI.patientDetailsURL , method: "POST", formData: formData) { [weak self] result in
                       switch result {
                       case .success(let data):
                          print(data)
                          DispatchQueue.main.async {
                              self?.name.text = data.first?.name
                              self?.patientId.text = data.first?.patientID
                              self?.mobileNumber.text = data.first?.phoneNumber
                              self?.age.text = "\(data.first?.age ?? 0)"
                              self?.gender.text = data.first?.gender
                              self?.admittedOn.text = "\(data.first?.admittedOn ?? "")"
                              self?.diagnosis.text = data.first?.diagnosis
                              self?.examination.text = data.first?.examination
                              self?.brief.text = data.first?.briefHistory
                              self?.getImageDetail()
                              self?.patientProfileImage()
                            
                              }
                       case .failure(let error):
                          print(error)
                          DispatchQueue.main.async {
                          if let navigation = self?.navigationController  {
                              DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                          }
                          }
                       }
                      
            }

      }
    
    func getImageDetail() {

        let formData = ["patient_id": newPatientId ]

        APIHandler().postAPIValues(type: GetImages.self, apiUrl: ServiceAPI.retriveImage , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.status == "success" {
                                
                            let filteredData = data.data.filter { val in
                                return val.patient_id == self?.newPatientId
                                    }
                            self?.loadImage(url: filteredData.last?.image ?? "", imageView: self?.imageView)
                                print(ServiceAPI.baseURL)
                                print(data.data.first?.image ?? "")
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                            }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                        }
                        }
                     }

          }

    }

    func patientProfileImage() {
          
        let formData = ["patient_id": newPatientId]
          
          APIHandler().postAPIValues(type: ImageRet.self, apiUrl: ServiceAPI.imageRet , method: "POST", formData: formData) { [weak self] result in
                       switch result {
                       case .success(let data):
                          print(data)
                          DispatchQueue.main.async {
                              if data.status == "success" {
                                
                                  let filteredData = data.data.filter { vals in
                                      return vals.patientID == self?.newPatientId
                                          }
                                  self?.loadImage(url: filteredData.first?.image ?? "", imageView: self?.profileImage)
                                
                              }else {
                              if let navigation = self?.navigationController  {
                                  DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                              }
                              }
                          }
                       case .failure(let error):
                          print(error)
                          DispatchQueue.main.async {
                          if let navigation = self?.navigationController  {
                              DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                          }
                          }
                       }
            }

      }



    @IBAction func profileTap(_ sender: Any) {
        
        
        if patientId.text ?? "" != "" {
            profileUploadImage = true
            presentImagePicker()
        }else {
            DispatchQueue.main.async {
            if let navigation = self.navigationController  {
                DataManager.shared.sendMessage(title: "Alert", message: "Should give patient id", navigation: navigation)
            }
            }
        }
        
    }
    
    
    
    @IBAction func bottomImage(_ sender: Any) {
        if patientId.text ?? "" != "" {
            profileUploadImage = false
            presentImagePicker()
        }else {
            DispatchQueue.main.async {
            if let navigation = self.navigationController  {
                DataManager.shared.sendMessage(title: "Alert", message: "Should give patient id", navigation: navigation)
            }
            }
        }
    }
    
    

    @IBAction func videosDetailsList(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "docaddVideosViewController")
        as! docaddVideosViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
    @IBAction func viewVideos(_ sender: Any) {
        DataManager.shared.patinetId = self.newPatientId
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "doctortaskViewController")
        as! doctortaskViewController
        self.navigationController?.pushViewController(vc, animated:true)
        
    }
    
    @IBAction func detailsVideos(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "patientdetailsViewController")
        as! patientdetailsViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    
    
    @IBAction func savetap(_ sender: Any) {
        
        addPatient()
    }
    
    
    func presentImagePicker() {
           let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
           alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
               self.openCamera()
           }))
           alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
               self.openGallery()
           }))
           alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
           present(alert, animated: true, completion: nil)
       }
       
       
    
       
       func openCamera() {
           if UIImagePickerController.isSourceTypeAvailable(.camera) {
               imagePicker.sourceType = .camera
               present(imagePicker, animated: true, completion: nil)
           } else {
               print("Camera not available")
           }
       }
       
       func openGallery() {
           imagePicker.sourceType = .photoLibrary
           present(imagePicker, animated: true, completion: nil)
       }

       func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
             if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
                
                 if profileUploadImage == false {
                     imageView.image = pickedImage
                     selectedProfileImage.append(pickedImage)
                    // addImageTobackEnd()
                 }else {
                     profileImage.image = pickedImage
                     selectedImage.append(pickedImage)
                    
                 }
                    
                
                
                
             }
             
             picker.dismiss(animated: true, completion: nil)
         }
       func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
           picker.dismiss(animated: true, completion: nil)
       }
    
    
    func uploadProfile() {
        
        let apiURL = ServiceAPI.dpUpload
        print("API URL:", apiURL)

        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var body = Data()
     
        var formData = [String: String]()

        formData["patient_id"] = patientId.text ?? ""
       

           

        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }


        let fieldNames = ["image"]

        for (index, image) in selectedImage.enumerated() {
           
            let fieldName = fieldNames[index]

            let imageData = image.jpegData(compressionQuality: 0.8)!
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
            body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
            body.append(contentsOf: imageData)
            body.append(contentsOf: "\r\n".utf8)


        }

        // Add closing boundary
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body

        request.httpBody = body

        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle the error, e.g., show an alert to the user
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")
                
                if let data = data {
                    
                    // print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    
                    if let responseData = String(data: data, encoding: .utf8) {
                        if let jsonData = responseData.data(using: .utf8) {
                            do {
                                if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                                    if let status = json["status"] as? String, let message = json["message"] as? String {
                                        
                                        DispatchQueue.main.async {
                                            if let nav = self.navigationController {
                                                DataManager.shared.sendMessage(title: "Message", message: message, navigation: nav)
                                            }
                                        }
                                    }
                                }
                            } catch {
                                print("Error parsing JSON: \(error)")
                            }
                        }
                    }
                }
            }
            
        }

        task.resume()
    }
    
    func addImageTobackEnd() {
        
        let apiURL = ServiceAPI.uploadImaage
        print("API URL:", apiURL)

        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var body = Data()
        let formData: [String: String] = [
            "patient_id": patientId.text ?? "",
          
        ]

        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }


        let fieldNames = ["image"]

        for (index, image) in selectedProfileImage.enumerated() {
           
            let fieldName = fieldNames[index]

            let imageData = image.jpegData(compressionQuality: 0.8)!
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
            body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
            body.append(contentsOf: imageData)
            body.append(contentsOf: "\r\n".utf8)


        }

        // Add closing boundary
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body

        request.httpBody = body

        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle the error, e.g., show an alert to the user
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")
                
                if let data = data {
                    
                    // print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    
                    if let responseData = String(data: data, encoding: .utf8) {
                        if let jsonData = responseData.data(using: .utf8) {
                            do {
                                if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                                    if let status = json["status"] as? String, let message = json["message"] as? String {
                                        
//                                        DispatchQueue.main.async {
//                                            if let nav = self.navigationController {
//                                                DataManager.shared.sendMessage(title: "Message", message: message, navigation: nav)
//                                            }
//                                        }
                                    }
                                }
                            } catch {
                                print("Error parsing JSON: \(error)")
                            }
                        }
                    }
                }
            }
                
            }
        

        task.resume()
    }
    
    
    func addPatient() {
           var formData = [String: String]()

           formData["patient_id"] = patientId.text ?? ""
           formData["name"] = name.text ?? ""
           formData["phone_number"] = mobileNumber.text ?? ""
           formData["age"] = age.text ?? ""
           formData["gender"] = gender.text ?? ""
           formData["diagnosis"] = diagnosis.text ?? ""
           formData["examination"] = examination.text ?? ""
           formData["brief_history"] = brief.text ?? ""
           formData["admitted_on"] = admittedOn.text ?? ""

              
           APIHandler().postAPIValues(type: EditPatientDetailsIos.self, apiUrl: ServiceAPI.editPatinetURL , method: "POST", formData: formData) { [weak self] result in
                        switch result {
                        case .success(let data):
                           print(data)
                           DispatchQueue.main.async {
                               self?.addImageTobackEnd()
                               self?.uploadProfile()
                               if data.status == true {
                                   let alertController = UIAlertController(title: "Alert", message: data.message, preferredStyle: .alert)
                                          let okAction = UIAlertAction(title: "OK", style: .default) { _ in
                                              self?.navigationController?.popViewController(animated: false)
                                             
                                          }
                                    alertController.addAction(okAction)
                                   self?.present(alertController, animated: true)
                                  
                               }else {
                                   if let navigation = self?.navigationController  {
                                       DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                                   }
                                  
                                  
                               }
                           }
                        case .failure(let error):
                           print(error)
                           DispatchQueue.main.async {
                           if let navigation = self?.navigationController  {
                               DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                           }
                           }
                        }
                       
       }
                
       }
}



