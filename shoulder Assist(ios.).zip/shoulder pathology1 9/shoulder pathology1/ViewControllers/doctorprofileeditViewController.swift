//
//  doctorprofileeditViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 25/01/24.
//

import UIKit

class doctorprofileeditViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func backbtn(_ sender: Any) {
        doctorprofileeditViewController().self
    }
    
    @IBAction func save(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "doctorprofileViewController")
        as! doctorprofileViewController
        self.navigationController?.pushViewController(vc, animated:true)
        
    }
}
//func doctorLogin()
