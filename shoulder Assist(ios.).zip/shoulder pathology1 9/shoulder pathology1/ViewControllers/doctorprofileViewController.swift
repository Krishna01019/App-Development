//
//  doctorprofileViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 25/01/24.
//

import UIKit

class doctorprofileViewController: UIViewController {
    
    
    @IBOutlet weak var doctorName: UILabel!
    @IBOutlet weak var doctorID: UILabel!
    
    @IBOutlet weak var spaciality: UILabel!
    

    @IBOutlet weak var phoneNumber: UILabel!
   
    
    
    
    override func viewDidLoad() {
       
        super.viewDidLoad()
        

    }
    
    
    override func viewWillAppear(_ animated: Bool) {
          super.viewWillAppear(true)
          self.tabBarController?.tabBar.isHidden = false
          
        doctorDeatils()
      }
      
      
      
    
    func doctorDeatils() {
          
        let formData = ["doctor_id": DataManager.shared.doctorId]
          
          APIHandler().postAPIValues(type: doctorProfileDetails.self, apiUrl: ServiceAPI.doctorProfileURL , method: "POST", formData: formData) { [weak self] result in
                       switch result {
                       case .success(let data):
                          print(data)
                          DispatchQueue.main.async {
                              if data.success == true {
                          
                                  self?.doctorName.text = data.data.name
                                  DataManager.shared.doctorName = data.data.name
                                  DataManager.shared.doctorId = data.data.doctorID
                                  self?.doctorID.text = data.data.doctorID
                                  self?.spaciality.text = data.data.spaciality
                                  self?.phoneNumber.text = data.data.phoneNumber
                                
                              }else {
                              if let navigation = self?.navigationController  {
                                  DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                              }
                              }
                          }
                       case .failure(let error):
                          print(error)
                          DispatchQueue.main.async {
                          if let navigation = self?.navigationController  {
                              DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                          }
                          }
                       }
                      
            }

      }

    

    @IBAction func backbtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    

    @IBAction func logout(_ sender: Any) {
        
    }
}


