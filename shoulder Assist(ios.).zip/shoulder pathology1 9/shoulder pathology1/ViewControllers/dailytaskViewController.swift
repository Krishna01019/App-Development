//
//  dailytaskViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 25/01/24.


import UIKit

class dailytaskViewController: UIViewController {
    
    @IBOutlet weak var calenderView: UIView!
    
    @IBOutlet weak var rangeofMovementLbl: UILabel!
    
    
    @IBOutlet weak var streachesLbl: UILabel!
    
    
    @IBOutlet weak var strengthLbl: UILabel!
    
    @IBOutlet weak var firstYes: UIButton!
    @IBOutlet weak var firstNo: UIButton!
    
    @IBOutlet weak var secondYes: UIButton!
    
    
    @IBOutlet weak var secondNo: UIButton!
    
    
    @IBOutlet weak var thirdYes: UIButton!
    
    @IBOutlet weak var submitCurve: UIButton!
    
    @IBOutlet weak var thirdNo: UIButton!
    
    @IBOutlet weak var feedbackLbl: UITextField!
    
    let datePicker = UIDatePicker()
    var date = String()
    var rangeOfMovement = String()
    var streaches = String()
    var strength = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        showDatePicker()
        submitCurve.layer.cornerRadius = 15
    }
    

    @IBAction func backbtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
  

    func showDatePicker() {
             // Formate Date
             datePicker.datePickerMode = .date

             if #available(iOS 13.4, *) {
                 datePicker.preferredDatePickerStyle = .inline
             } else {
                 datePicker.preferredDatePickerStyle = .wheels
             }
             let toolbar = UIToolbar()
             toolbar.sizeToFit()

             // done button & cancel button
             let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_:)))
           
             let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)

             let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_:)))
             
             toolbar.setItems([cancelButton, spaceButton, doneButton], animated: false)

           
             view.addSubview(datePicker)
             view.addSubview(toolbar)

             // Add constraints or frame as needed
             datePicker.translatesAutoresizingMaskIntoConstraints = false
             toolbar.translatesAutoresizingMaskIntoConstraints = false

             NSLayoutConstraint.activate([
                 // Adjust the constraints as per your layout requirements
              datePicker.topAnchor.constraint(equalTo: calenderView.topAnchor),
              datePicker.leadingAnchor.constraint(equalTo: calenderView.leadingAnchor),
              datePicker.trailingAnchor.constraint(equalTo: calenderView.trailingAnchor),
              datePicker.bottomAnchor.constraint(equalTo: calenderView.bottomAnchor,constant: -10),

                 toolbar.topAnchor.constraint(equalTo: datePicker.bottomAnchor),
                 toolbar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                 toolbar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
             ])
         }

         @objc func cancelDatePicker(_ sender: UIButton) {
           //  datePicker.removeFromSuperview()
         }

         @objc func donedatePicker(_ sender: UIButton) {
             let formatter = DateFormatter()
             formatter.dateFormat = "yyyy-MM-dd"
            date = formatter.string(from: datePicker.date)
             print(formatter.string(from: datePicker.date))

            
         }
   
    func dailyTask() {
        let formData = ["patient_id": DataManager.shared.patinetId,
                                "date": date,
                                "range_of_movement": rangeOfMovement,
                                "stretches": streaches,
                                "strengthening_exercise": strength,
                               "feedback": feedbackLbl.text ?? ""
                          ]
        APIHandler().postAPIValues(type: DailyTask.self, apiUrl: ServiceAPI.dailyTaskURL , method: "POST", formData: formData) { [weak self] result in
                             switch result {
                             case .success(let data):
                                print(data)
                            DispatchQueue.main.async {
                            if data.status == "success" {
//                                if let navigation = self?.navigationController  {
//                                    DataManager.shared.sendMessage(title: "Message", message: data.message, navigation: navigation)
//                                     }
                                
                                self?.showAlert(title: "Message", message: "\(data.message)", okActionHandler: { action in
                                    self?.navigationController?.popViewController(animated: false)
                                        })
                                        
                                }else {
                                if let navigation = self?.navigationController  {
                                    DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                                     }
                                    }
                                }
                             case .failure(let error):
                                print(error)
                                DispatchQueue.main.async {
                                if let navigation = self?.navigationController  {
                                    DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                                }
                                }
                             }
                      }
    }
    
    
    
    @IBAction func rangeOfMovementTapped(_ sender: UIButton) {
        
        switch sender.tag {
            
        case 1:
            firstYes.setImage(UIImage(named: "tick"), for: .normal)
            firstNo.setImage(UIImage(named: "select"), for: .normal)
            rangeOfMovement = "Yes"
        case 2:
            firstYes.setImage(UIImage(named: "select"), for: .normal)
            firstNo.setImage(UIImage(named: "tick"), for: .normal)
            rangeOfMovement = "No"
        default:
            print("")
        }

    }
    
  
  
   
    
    
    @IBAction func strechesTap(_ sender: UIButton) {
        
        switch sender.tag {
            
        case 1:
            secondYes.setImage(UIImage(named: "tick"), for: .normal)
            secondNo.setImage(UIImage(named: "select"), for: .normal)
            streaches = "Yes"
        case 2:
            secondYes.setImage(UIImage(named: "select"), for: .normal)
            secondNo.setImage(UIImage(named: "tick"), for: .normal)
            streaches = "No"
        default:
            print("")
        }

    }
    
    
    
    @IBAction func strengthtapped(_ sender: UIButton) {
        
        
        switch sender.tag {
            
        case 1:
            thirdYes.setImage(UIImage(named: "tick"), for: .normal)
            thirdNo.setImage(UIImage(named: "select"), for: .normal)
            strength = "Yes"
        case 2:
            thirdNo.setImage(UIImage(named: "tick"), for: .normal)
            thirdYes.setImage(UIImage(named: "select"), for: .normal)
            strength = "No"
        default:
            print("")
        }

    }
    
    
    
    
    @IBAction func submitAction(_ sender: Any) {
        if feedbackLbl.text ?? "" != "" && date != "" {
            dailyTask()
        }else {
            DispatchQueue.main.async {
            if let navigation = self.navigationController  {
                DataManager.shared.sendMessage(title: "Alert", message: "fill all the fileds", navigation: navigation)
            }
            }
        }
        
    }
    
    
}

import UIKit

extension UIViewController {
    func showAlert(title: String?, message: String?, okActionTitle: String = "OK", okActionHandler: ((UIAlertAction) -> Void)? = nil) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: okActionTitle, style: .default, handler: okActionHandler)
        alertController.addAction(okAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
}
