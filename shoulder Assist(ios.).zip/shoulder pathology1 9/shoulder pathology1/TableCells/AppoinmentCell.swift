//
//  AppoinmentCell.swift
//  shoulder pathology1
//
//  Created by SAIL on 12/12/23.
//

import UIKit

class AppoinmentCell: UITableViewCell {
    
    
    
    @IBOutlet weak var patientId: UILabel!
    
    @IBOutlet weak var patirntName: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
   
        override func layoutSubviews() {
          super.layoutSubviews()
           
         let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
          contentView.frame = contentView.frame.inset(by: margin)
            contentView.layer.cornerRadius = 5
        }
        
       
    }
    

