//
//  VideoCell.swift
//  shoulder pathology1
//
//  Created by SAIL on 29/12/23.
//

import UIKit
import AVFoundation

class VideoCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var subView: UIView!
    
    
    @IBOutlet weak var videoHeader: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    
    

        
        

}
