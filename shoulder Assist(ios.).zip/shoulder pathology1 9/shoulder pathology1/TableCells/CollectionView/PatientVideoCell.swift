//
//  PatientVideoCell.swift
//  shoulder pathology1
//
//  Created by SAIL on 25/01/24.
//

import UIKit

class PatientVideoCell: UICollectionViewCell {
    
    
    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var imageView: UIImageView!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
