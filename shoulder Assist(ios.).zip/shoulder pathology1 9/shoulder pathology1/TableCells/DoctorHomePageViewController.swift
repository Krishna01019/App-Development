//
//  DoctorHomePageViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 12/12/23.
//

import UIKit

class DoctorHomePageViewController: UIViewController {
    
    
    
    @IBOutlet weak var subView: UIView!
    

    @IBOutlet weak var patientTable: UITableView!
    
    
    var patientListDetails:PatientList?
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
        let cell = UINib(nibName: "AppoinmentCell", bundle: nil)
        patientTable.register(cell, forCellReuseIdentifier: "cell")
        subView.layer.borderWidth = 2.0
        subView.layer.cornerRadius = 10
    }
    
    
    
    
    override func viewWillAppear(_ animated: Bool) {
           super.viewWillAppear(true)
        patientListApi()
       }
       
       
       
       func patientListApi() {
           var formData = [String: String]()


           APIHandler().postAPIValues(type: PatientList.self, apiUrl: ServiceAPI.patinetListURL, method: "POST", formData: formData) { [weak self] result in
                        switch result {
                        case .success(let data):
                           print(data)
                           DispatchQueue.main.async {
                               if data.success == true {
                               self?.patientListDetails = data
                              self?.patientTable.reloadData()
                               }else {
                               if let navigation = self?.navigationController  {
                                   DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                               }
                                  
                                  
                               }
                           }
                        case .failure(let error):
                           print(error)
                           DispatchQueue.main.async {
                           if let navigation = self?.navigationController  {
                               DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                           }
                           }
                        }
                       
       }
                
       }

    

  

}
extension DoctorHomePageViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return min(self.patientListDetails?.data.count ?? 0, 3)
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! PatientDetailsCell
       cell.nameFiled.text = self.patientListDetails?.data[indexPath.row].name
       cell.patientId.text = self.patientListDetails?.data[indexPath.row].patientID
       return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       return 100.0
    }

}




