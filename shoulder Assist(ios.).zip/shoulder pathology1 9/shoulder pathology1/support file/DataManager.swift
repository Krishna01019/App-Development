//
//  DataManager.swift
//  shoulder pathology1
//
//  Created by SAIL on 30/01/24.
//

import UIKit
import AVFoundation



class DataManager {
    
  
        static let shared = DataManager()
       
        
        private init() {
            // Private initialization to ensure just one instance is created.
        }
    
    var doctorName = String()
    var doctorId = String()
    var patinetId = String()
    var totalScore = String()
    var date = String()
   
    func sendMessage(title:String,message:String,navigation:UINavigationController) {
        
       
        let alertController = UIAlertController(title: "Message", message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        navigation.present(alertController, animated: false, completion: nil)
    }
    
    
    
    func generateThumbnail(for url: URL, completion: @escaping (UIImage?) -> Void) {
        DispatchQueue.global().async {
            let asset = AVAsset(url: url)
            let assetImageGenerator = AVAssetImageGenerator(asset: asset)
            
            assetImageGenerator.appliesPreferredTrackTransform = true  // Corrects the orientation.
            
            let timestamp = CMTime(seconds: 1, preferredTimescale: 60) // Example: Get the frame at the 1-second mark.
            
            do {
                let imageRef = try assetImageGenerator.copyCGImage(at: timestamp, actualTime: nil)
                let thumbnail = UIImage(cgImage: imageRef)
                DispatchQueue.main.async {
                    completion(thumbnail)
                }
            } catch {
                print(error.localizedDescription)
                DispatchQueue.main.async {
                    completion(nil) // In case of an error, return nil.
                }
            }
        }
    }
}

extension UIViewController {
    
    func loadImage(url: String, imageView: UIImageView?) {
        
        
              
        let baseURL = ServiceAPI.baseURL
              
           
              guard let imageUrl = URL(string: baseURL + url) else {
                  return
              }
              
            
              let task = URLSession.shared.dataTask(with: imageUrl) { (data, response, error) in
                
                  guard error == nil, let imageData = data else {
                      print("Error downloading image: \(error?.localizedDescription ?? "Unknown error")")
                      return
                  }
                  
                 
                  DispatchQueue.main.async {
                      
                      if let image = UIImage(data: imageData) {
                          // Set the loaded image to the UIImageView
                          imageView?.image = image
                          
                      }
                  }
              }
              
              // Start the URL session task
              task.resume()
          }
    
    
    func loadImageData(data: UIImage, imageView: UIImageView?) {
        
        
              
        let baseURL = ServiceAPI.baseURL
              
           
          
              
            
                 
                  DispatchQueue.main.async {
                      
                     
                          // Set the loaded image to the UIImageView
                          imageView?.image = data
                          
                      
                  }
              
              
              // Start the URL session task
              
          }
}
