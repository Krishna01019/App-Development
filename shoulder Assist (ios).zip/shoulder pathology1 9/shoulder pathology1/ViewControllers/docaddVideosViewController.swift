//
//  docaddVideosViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 01/02/24.
//

import UIKit

class docaddVideosViewController: UIViewController {

    @IBOutlet weak var rangeOfVideos: UIButton!
    @IBOutlet weak var stretchesVideso: UIButton!

    @IBOutlet weak var strenghtVideos: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        rangeOfVideos.layer.borderWidth = 1.5
        rangeOfVideos.layer.borderColor = UIColor.darkGray.cgColor
        rangeOfVideos.layer.cornerRadius = 10
        rangeOfVideos.clipsToBounds = true
        
        
        stretchesVideso.layer.borderWidth = 1.5
        stretchesVideso.layer.borderColor = UIColor.darkGray.cgColor
        stretchesVideso.layer.cornerRadius = 10
        stretchesVideso.clipsToBounds = true
        
        strenghtVideos.layer.borderWidth = 1.5
        strenghtVideos.layer.borderColor = UIColor.darkGray.cgColor
        strenghtVideos.layer.cornerRadius = 10
        strenghtVideos.clipsToBounds = true


    }
    
    
    
  var upload = false
    
    @IBAction func stretchesVideso(_ sender: Any) {
        if !upload {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "UploadViewController")
            as! UploadViewController
            vc.uploadVideosApi = "1.php"
            self.navigationController?.pushViewController(vc, animated:true)
        }else {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "AddVideosController")
        as! AddVideosController
        vc.header = "1.php"
        self.navigationController?.pushViewController(vc, animated:true)
        }
    }
    @IBAction func strenghtVideos(_ sender: Any) {
        if !upload {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "UploadViewController")
            as! UploadViewController
            vc.uploadVideosApi = "2.php"
            self.navigationController?.pushViewController(vc, animated:true)
        }else {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "AddVideosController")
        as! AddVideosController
        vc.header = "2.php"
        self.navigationController?.pushViewController(vc, animated:true)
        }
    }
    @IBAction func rangeOfVideos(_ sender: Any) {
        if !upload {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "UploadViewController")
            as! UploadViewController
            vc.uploadVideosApi = ".php"
            self.navigationController?.pushViewController(vc, animated:true)
        }else {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "AddVideosController")
        as! AddVideosController
        vc.header = "video.php"
        self.navigationController?.pushViewController(vc, animated:true)
        }
    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    
    @IBAction func protocolsTap(_ sender: Any) {
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ProtocolViewController")
        as! ProtocolViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
    
}
//func doctorLogin() {
//            
//            
//            let formData = ["doctor_id": doctorId.text ?? "",
//                            "password": passwordField.text ?? ""]
//   
//
//    APIHandler().postAPIValues(type: DoctorLogin.self, apiUrl: ServiceAPI.doctorLoginURL , method: "POST", formData: formData) { [weak self] result in
//                         switch result {
//                         case .success(let data):
//                            print(data)
//                            DispatchQueue.main.async {
//                                if data.success == true {
//                                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//                                    let vc = storyBoard.instantiateViewController(withIdentifier: "doctorhomeViewController")
//                                    as! doctorhomeViewController
//                                    self?.navigationController?.pushViewController(vc, animated:true)
//                                    
//                                }else {
//                                if let navigation = self?.navigationController  {
//                                    DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
//                                }
//                                   
//                                   
//                                }
//                            }
//                         case .failure(let error):
//                            print(error)
//                            DispatchQueue.main.async {
//                            if let navigation = self?.navigationController  {
//                                DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
//                            }
//                            }
//                         }
//                        
//        }
//                 
// 
//        
//}
