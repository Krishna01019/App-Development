//
//  doctorpatientloginViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 04/01/24.
//

import UIKit

class doctorpatientloginViewController: UIViewController {

    @IBOutlet weak var uiviewradius: UIView!
    @IBOutlet weak var imageradius: UIImageView!
   
    @IBOutlet weak var patientViewradius: UIView!
    
    @IBOutlet weak var gradientView1: UIView!
    
    @IBOutlet weak var doctorViewradius: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        doctorViewradius.layer.cornerRadius=25
        
        patientViewradius.layer.cornerRadius=25
        
        
        gradientView1.applyGradient(colors: [UIColor(red: 0.44, green: 0.64, blue: 0.88, alpha: 1.00).cgColor,UIColor(red: 0.20, green: 0.76, blue: 0.66, alpha: 1.00).cgColor]
)
    
       
    
    }
                                    
                                    
    @IBAction func doctorloginbtn(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "DoctorLoginViewController")
        as! DoctorLoginViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
    @IBAction func patientLoginBtn(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "patientLoginPageViewController")
        as! patientLoginPageViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
}





