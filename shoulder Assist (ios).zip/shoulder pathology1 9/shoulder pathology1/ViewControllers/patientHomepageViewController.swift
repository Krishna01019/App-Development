//
//  patientHomepageViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 24/01/24.
//

import UIKit

class patientHomepageViewController: UIViewController,SideMenuDelegate {
    
    
    @IBOutlet weak var doctorImage: UIImageView!
    
    @IBOutlet weak var todaysTaskCurve: UIButton!
    
    @IBOutlet weak var questionsCurve: UIButton!
    @IBOutlet weak var dailyProgressCruve: UIButton!
    
    @IBOutlet weak var dashviewBorder: UIView!
    
    @IBOutlet weak var doctroName: UILabel!
    
    
    @IBOutlet weak var doctorId: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        todaysTaskCurve.layer.cornerRadius = 15
        questionsCurve.layer.cornerRadius = 15
        dailyProgressCruve.layer.cornerRadius = 15
    
        doctroName.text = DataManager.shared.doctorName
        doctorId.text = DataManager.shared.doctorId
        dashviewBorder.layer.borderWidth = 5.0
        dashviewBorder.layer.borderColor = UIColor.black.cgColor
    }
    
    
    
    func tap(index: Int) {
        if index == 1 {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "patientprofileViewController")
            as! patientprofileViewController
            self.navigationController?.pushViewController(vc, animated:true)
        }else {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "doctorpatientloginViewController")
            as! doctorpatientloginViewController
            self.navigationController?.pushViewController(vc, animated:true)
        }
    }
    
    @IBAction func todaystask(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "patienttodaytaskViewController")
        as! patienttodaytaskViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
    @IBAction func dailytask(_ sender: Any) {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "dailytaskViewController")
            as! dailytaskViewController
            self.navigationController?.pushViewController(vc, animated:true)
    }
    
    @IBAction func questions(_ sender: Any) {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "questionariespatientViewController")
            as! questionariespatientViewController
            self.navigationController?.pushViewController(vc, animated:true)

    }
    @IBAction func patientprofile(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "SideMenuViewController")
        as! SideMenuViewController
        vc.delegate = self
        vc.modalPresentationStyle = .overCurrentContext
        self.present(vc, animated: false)

    }
}

    




