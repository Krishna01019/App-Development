//
//  doctortaskViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 25/01/24.
//

import UIKit

class   doctortaskViewController: UIViewController {
    
    
    @IBOutlet weak var calenderView: UIView!
    
    
    @IBOutlet weak var romStatus: UILabel!
    
    @IBOutlet weak var stratchesStatus: UILabel!
    
    @IBOutlet weak var seStatus: UILabel!
    
    @IBOutlet weak var feedbackdisplay: UITextField!
    
    @IBOutlet weak var totalScore: UILabel!
    
    let datePicker : UIDatePicker = UIDatePicker()
    var date  = String()
    
          
    var viewTaskDetasil:ViewTask?
           override func viewDidLoad() {
               super.viewDidLoad()
               showDatePicker()
             
           }

    func showDatePicker() {
             // Formate Date
             datePicker.datePickerMode = .date

             if #available(iOS 13.4, *) {
                 datePicker.preferredDatePickerStyle = .inline
             } else {
                 datePicker.preferredDatePickerStyle = .wheels
             }
             let toolbar = UIToolbar()
             toolbar.sizeToFit()

             // done button & cancel button
             let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donedatePicker(_:)))
           
             let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)

             let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.cancelDatePicker(_:)))
             
             toolbar.setItems([cancelButton, spaceButton, doneButton], animated: false)

           
             view.addSubview(datePicker)
             view.addSubview(toolbar)

             // Add constraints or frame as needed
             datePicker.translatesAutoresizingMaskIntoConstraints = false
             toolbar.translatesAutoresizingMaskIntoConstraints = false

             NSLayoutConstraint.activate([
                 // Adjust the constraints as per your layout requirements
              datePicker.topAnchor.constraint(equalTo: calenderView.topAnchor),
              datePicker.leadingAnchor.constraint(equalTo: calenderView.leadingAnchor),
              datePicker.trailingAnchor.constraint(equalTo: calenderView.trailingAnchor),
              datePicker.bottomAnchor.constraint(equalTo: calenderView.bottomAnchor,constant: -10),

                 toolbar.topAnchor.constraint(equalTo: datePicker.bottomAnchor),
                 toolbar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                 toolbar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
             ])
         }

         @objc func cancelDatePicker(_ sender: UIButton) {
           //  datePicker.removeFromSuperview()
         }

         @objc func donedatePicker(_ sender: UIButton) {
             let formatter = DateFormatter()
             formatter.dateFormat = "yyyy-MM-dd"
            
             date = formatter.string(from: datePicker.date)
             
             patientListApi()
             print(formatter.string(from: datePicker.date))

            
         }
    
    
    
    func patientListApi() {
        let formData = ["patient_id": DataManager.shared.patinetId,
                        "date": date
        ]

        APIHandler().postAPIValues(type: ViewTask.self, apiUrl: ServiceAPI.taskretriveURL, method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.status == "success" {
                                self?.scoreApi()
                                self?.romStatus.text = data.data.rangeOfMovement
                                self?.stratchesStatus.text = data.data.stretches
                         
                                self?.seStatus.text = data.data.strengtheningExercise
                                self?.feedbackdisplay.text = data.data.feedback
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                              }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "No data available", navigation: navigation)
                        }
                        }
                     }
       }
    }
    
    
    func scoreApi() {
        let formData = ["patient_id": DataManager.shared.patinetId,
                        "date": date
        ]

        APIHandler().postAPIValues(type: RetriveScore.self, apiUrl: ServiceAPI.scoreDisplay, method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.status == "success" {
                                self?.totalScore.text = "\(data.data.first?.total_score ?? 0)"
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                              }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                        }
                        }
                     }
       }
    }

    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
}
