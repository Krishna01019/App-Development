//
//  patient_home.swift
//  shoulder pathology1
//
//  Created by SAIL on 14/12/23.
//

import UIKit

class patient_home: UIViewController {

    @IBOutlet weak var subview: UIView!
    @IBOutlet weak var patient_home: UITableView! {
        didSet {
            patient_home.delegate = self
            patient_home.dataSource = self
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let cell = UINib(nibName: "patient_cell", bundle: nil)
        patient_home.register(cell, forCellReuseIdentifier: "patient_cell")
        subview.layer.borderWidth = 2.0
        subview.layer.cornerRadius = 10
        
    }
    

    

}
extension patient_home: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "patient_cell", for: indexPath) as! patient_cell
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }
}
