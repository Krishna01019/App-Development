//
//  patientLoginPageViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 04/01/24.
//

import UIKit

class patientLoginPageViewController: UIViewController {
    
    
    @IBOutlet weak var patientIdField: UITextField!
    
    @IBOutlet weak var passwordField: UITextField!
    
    @IBOutlet weak var loginCurve: UIButton!
    
    @IBOutlet var gradientView1: UIView!
    
    
    @IBOutlet weak var gradientView2: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        gradientView1.applyGradient(colors: [UIColor(red: 0.44, green: 0.64, blue: 0.88, alpha: 1.00).cgColor,UIColor(red: 0.20, green: 0.76, blue: 0.66, alpha: 1.00).cgColor]
        )
        gradientView2.applyGradient(colors: [UIColor(red: 0.44, green: 0.64, blue: 0.88, alpha: 1.00).cgColor,UIColor(red: 0.20, green: 0.76, blue: 0.66, alpha: 1.00).cgColor]
        )
        loginCurve.layer.cornerRadius = 15
        
    }
    
    
    
 

    
    
    
    

    @IBAction func patientLoginbtn(_ sender: Any) {
        patientLogin()
        
        loginCurve.layer.cornerRadius = 15
        
    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }

func patientLogin() {


            let formData = [
                "patient_id": patientIdField.text ?? "",
                "password": passwordField.text ?? ""
            ]


    APIHandler().postAPIValues(type: DoctorLogin.self, apiUrl: ServiceAPI.patientLoginURL , method: "POST", formData: formData) { [weak self] result in
                switch result {
                case .success(let data):
                            print(data)
                    DispatchQueue.main.async {
                        if data.success == true {
                        DataManager.shared.patinetId = self?.patientIdField.text ?? ""
                            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                            let vc = storyBoard.instantiateViewController(withIdentifier: "patientHomepageViewController")
                            as! patientHomepageViewController
                            self?.navigationController?.pushViewController(vc, animated:true)

                        }else {
                        if let navigation = self?.navigationController  {
                        DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                                }

                                }
                            }
                    case .failure(let error):
                            print(error)
                    DispatchQueue.main.async {
                    if let navigation = self?.navigationController  {
                        DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                            }
                        
                            }
                         }
        }
    
     }
}
