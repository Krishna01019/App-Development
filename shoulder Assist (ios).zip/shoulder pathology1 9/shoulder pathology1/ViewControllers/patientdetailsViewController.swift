//
//  patientdetailsViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 11/01/24.
//

import UIKit

class 
patientdetailsViewController: UIViewController {
    
    
    
    
    @IBOutlet weak var viewVideosCurve: UIButton!
    
    @IBOutlet weak var videosBtnCurve: UIButton!
   
    @IBOutlet weak var submtCurve: UIButton!
    
    @IBOutlet weak var patientId: UITextField!
    
    
    @IBOutlet weak var name: UITextField!
    
    
    @IBOutlet weak var mobileNumber: UITextField!
    
    @IBOutlet weak var age: UITextField!
    
    @IBOutlet weak var gender: UITextField!
    
    
    @IBOutlet weak var admittedOn: UITextField!
    
    
    @IBOutlet weak var diagnosis: UITextView!
    
    
    @IBOutlet weak var examination: UITextView!
    
    
    @IBOutlet weak var brief: UITextView!
    
    

    @IBOutlet weak var profileImage: UIImageView!
    
    
    @IBOutlet weak var imageView: UIImageView!
    
    
    var newPatientId = String()

    override func viewDidLoad() {
        videosBtnCurve.layer.cornerRadius=15
        viewVideosCurve.layer.cornerRadius=15
        submtCurve.layer.cornerRadius=15
       
        super.viewDidLoad()
        
        
        doctorDeatils()
        
        imageView.layer.borderWidth = 1.0
        imageView.layer.borderColor = UIColor.black.cgColor
        imageView.layer.cornerRadius = 10.0
        
        
        
        
        examination.layer.borderWidth = 1.0
        examination.layer.borderColor = UIColor.black.cgColor
        examination.layer.cornerRadius = 10.0
        
        
        examination.layer.borderWidth = 1.0
        examination.layer.borderColor = UIColor.black.cgColor
        examination.layer.cornerRadius = 10.0
        
        
        brief.layer.borderWidth = 1.0
        brief.layer.borderColor = UIColor.black.cgColor
        brief.layer.cornerRadius = 10.0
        
        
        

        
        diagnosis.layer.borderWidth = 1.0
        diagnosis.layer.borderColor = UIColor.black.cgColor
        diagnosis.layer.cornerRadius = 10.0
        
        
        

    }
    
    
    
    
    func doctorDeatils() {
          
          let formData = ["patient_id": newPatientId]
          
          APIHandler().postAPIValues(type: PatientDetails.self, apiUrl: ServiceAPI.patientDetailsURL , method: "POST", formData: formData) { [weak self] result in
                       switch result {
                       case .success(let data):
                          print(data)
                          DispatchQueue.main.async {
                              self?.name.text = data.first?.name
                              self?.patientId.text = data.first?.patientID
                              self?.mobileNumber.text = data.first?.phoneNumber
                              self?.age.text = "\(data.first?.age ?? 0)"
                              self?.gender.text = data.first?.gender
                              self?.admittedOn.text = "\(data.first?.admittedOn ?? "")"
                              self?.diagnosis.text = data.first?.diagnosis
                              self?.examination.text = data.first?.examination
                              self?.brief.text = data.first?.briefHistory
                              self?.getImageDetail()
                              self?.patientProfileImage()
                            
                              }
                       case .failure(let error):
                          print(error)
                          DispatchQueue.main.async {
                          if let navigation = self?.navigationController  {
                              DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                          }
                          }
                       }
                      
            }

      }
    
    func getImageDetail() {

        let formData = ["patient_id": newPatientId ]

        APIHandler().postAPIValues(type: GetImages.self, apiUrl: ServiceAPI.retriveImage , method: "POST", formData: formData) { [weak self] result in
                     switch result {
                     case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                            if data.status == "success" {
                                
                            let filteredData = data.data.filter { val in
                                return val.patient_id == self?.newPatientId
                                    }
                            self?.loadImage(url: filteredData.last?.image ?? "", imageView: self?.imageView)
                                print(ServiceAPI.baseURL)
                                print(data.data.first?.image ?? "")
                            }else {
                            if let navigation = self?.navigationController  {
                                DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                            }
                            }
                        }
                     case .failure(let error):
                        print(error)
                        DispatchQueue.main.async {
                        if let navigation = self?.navigationController  {
                            DataManager.shared.sendMessage(title: "Alert", message: "Something Went wrong", navigation: navigation)
                        }
                        }
                     }

          }

    }

    func patientProfileImage() {
          
        let formData = ["patient_id": newPatientId]
          
          APIHandler().postAPIValues(type: ImageRet.self, apiUrl: ServiceAPI.imageRet , method: "POST", formData: formData) { [weak self] result in
                       switch result {
                       case .success(let data):
                          print(data)
                          DispatchQueue.main.async {
                              if data.status == "success" {
                                  self?.loadImage(url: data.data.first?.image ?? "", imageView: self?.profileImage)
                                
                              }else {
                              if let navigation = self?.navigationController  {
                                  DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                              }
                              }
                          }
                       case .failure(let error):
                          print(error)
                          DispatchQueue.main.async {
                          if let navigation = self?.navigationController  {
                              DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                          }
                          }
                       }
            }

      }





    @IBAction func videosDetailsList(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "docaddVideosViewController")
        as! docaddVideosViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
    @IBAction func viewVideos(_ sender: Any) {
        DataManager.shared.patinetId = self.newPatientId
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "doctortaskViewController")
        as! doctortaskViewController
        self.navigationController?.pushViewController(vc, animated:true)
        
    }
    
    @IBAction func detailsVideos(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "patientdetailsViewController")
        as! patientdetailsViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
}

