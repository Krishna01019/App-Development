//
//  addpatientpageViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 03/01/24.
//

import UIKit

class addpatientpageViewController: UIViewController, UIImagePickerControllerDelegate , UINavigationControllerDelegate{
    
    
    @IBOutlet weak var profileImage: UIImageView!
    
    @IBOutlet weak var patientIdFiled: UITextField!
    
    
    @IBOutlet weak var nameFiled: UITextField!
    
    
    @IBOutlet weak var mobilenumberFiled: UITextField!
    
    
    @IBOutlet weak var ageFiled: UITextField!
    
    
    @IBOutlet weak var genderFiled: UITextField!
    

    @IBOutlet weak var imageview: UIImageView!
    
  
    @IBOutlet weak var admittedOnFiled: UITextField!
    
    @IBOutlet weak var diagnosisFiled: UITextView!
    
    @IBOutlet weak var briefFiled: UITextView!
    @IBOutlet weak var examinationfield: UITextView!
    
    

    
    @IBOutlet weak var addVideosBtnCurve: UIButton!
    
    @IBOutlet weak var addBtnCurve: UIButton!
    
    
    let imagePicker = UIImagePickerController()
   
    var selectedImage = [UIImage]()
    var selectedProfileImage = [UIImage]()
 
   
    var profileUploadImage = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        
        addVideosBtnCurve.layer.cornerRadius=15
        addBtnCurve.layer.cornerRadius=15

        
        
        diagnosisFiled.layer.borderWidth = 1.0
        diagnosisFiled.layer.borderColor = UIColor.black.cgColor
        diagnosisFiled.layer.cornerRadius = 10.0
        
        briefFiled.layer.borderWidth = 1.0
        briefFiled.layer.borderColor = UIColor.black.cgColor
        briefFiled.layer.cornerRadius = 10.0
        
        
        
        examinationfield.layer.borderWidth = 1.0
        examinationfield.layer.borderColor = UIColor.black.cgColor
        examinationfield.layer.cornerRadius = 10.0
        
        
     
        
        
        
        imageview.layer.borderWidth = 1.0
        imageview.layer.borderColor = UIColor.black.cgColor
        imageview.layer.cornerRadius = 10.0
        
       
    }
    func addPatient() {
           var formData = [String: String]()

           formData["patient_id"] = patientIdFiled.text ?? ""
           formData["name"] = nameFiled.text ?? ""
           formData["phone_number"] = mobilenumberFiled.text ?? ""
           formData["age"] = ageFiled.text ?? ""
           formData["gender"] = genderFiled.text ?? ""
           formData["diagnosis"] = diagnosisFiled.text ?? ""
           formData["examination"] = examinationfield.text ?? ""
           formData["brief_history"] = briefFiled.text ?? ""
           formData["admitted_on"] = admittedOnFiled.text ?? ""

              
           APIHandler().postAPIValues(type: AddPatient.self, apiUrl: ServiceAPI.addPatinetURL , method: "POST", formData: formData) { [weak self] result in
                        switch result {
                        case .success(let data):
                           print(data)
                           DispatchQueue.main.async {
                               self?.addImageTobackEnd()
                               self?.uploadProfile()
                               if data.userInserted == true {
                                   let alertController = UIAlertController(title: "Alert", message: "Added patient detail succesfully", preferredStyle: .alert)
                                          let okAction = UIAlertAction(title: "OK", style: .default) { _ in
                                              self?.navigationController?.popViewController(animated: false)
                                             
                                          }
                                    alertController.addAction(okAction)
                                   self?.present(alertController, animated: true)
                                  
                               }else {
                                   if let navigation = self?.navigationController  {
                                       DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                                   }
                                  
                                  
                               }
                           }
                        case .failure(let error):
                           print(error)
                           DispatchQueue.main.async {
                           if let navigation = self?.navigationController  {
                               DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                           }
                           }
                        }
                       
       }
                
       }
    
    @IBAction func uploadProfileTapped(_ sender: Any) {
        
        if patientIdFiled.text ?? "" != "" {
            profileUploadImage = true
            presentImagePicker()
        }else {
            DispatchQueue.main.async {
            if let navigation = self.navigationController  {
                DataManager.shared.sendMessage(title: "Alert", message: "Should give patient id", navigation: navigation)
            }
            }
        }
        
       
        
    }
    
    func uploadProfile() {
        
        let apiURL = ServiceAPI.dpUpload
        print("API URL:", apiURL)

        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var body = Data()
     
        var formData = [String: String]()

        formData["patient_id"] = patientIdFiled.text ?? ""
       

           

        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }


        let fieldNames = ["image"]

        for (index, image) in selectedImage.enumerated() {
           
            let fieldName = fieldNames[index]

            let imageData = image.jpegData(compressionQuality: 0.8)!
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
            body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
            body.append(contentsOf: imageData)
            body.append(contentsOf: "\r\n".utf8)


        }

        // Add closing boundary
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body

        request.httpBody = body

        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle the error, e.g., show an alert to the user
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")
                
                if let data = data {
                    
                    // print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    
                    if let responseData = String(data: data, encoding: .utf8) {
                        if let jsonData = responseData.data(using: .utf8) {
                            do {
                                if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                                    if let status = json["status"] as? String, let message = json["message"] as? String {
                                        
                                        DispatchQueue.main.async {
                                            if let nav = self.navigationController {
                                                DataManager.shared.sendMessage(title: "Message", message: message, navigation: nav)
                                            }
                                        }
                                    }
                                }
                            } catch {
                                print("Error parsing JSON: \(error)")
                            }
                        }
                    }
                }
            }
            
        }

        task.resume()
    }
    
    func addImageTobackEnd() {
        
        let apiURL = ServiceAPI.uploadImaage
        print("API URL:", apiURL)

        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var body = Data()
        let formData: [String: String] = [
            "patient_id": patientIdFiled.text ?? "",
          
        ]

        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }


        let fieldNames = ["image"]

        for (index, image) in selectedProfileImage.enumerated() {
           
            let fieldName = fieldNames[index]

            let imageData = image.jpegData(compressionQuality: 0.8)!
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
            body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
            body.append(contentsOf: imageData)
            body.append(contentsOf: "\r\n".utf8)


        }

        // Add closing boundary
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body

        request.httpBody = body

        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle the error, e.g., show an alert to the user
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")
                
                if let data = data {
                    
                    // print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    
                    if let responseData = String(data: data, encoding: .utf8) {
                        if let jsonData = responseData.data(using: .utf8) {
                            do {
                                if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                                    if let status = json["status"] as? String, let message = json["message"] as? String {
                                        
//                                        DispatchQueue.main.async {
//                                            if let nav = self.navigationController {
//                                                DataManager.shared.sendMessage(title: "Message", message: message, navigation: nav)
//                                            }
//                                        }
                                    }
                                }
                            } catch {
                                print("Error parsing JSON: \(error)")
                            }
                        }
                    }
                }
            }
                
            }
        

        task.resume()
    }

    @IBAction func addVideosbtndoc(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "docaddVideosViewController")
        as! docaddVideosViewController
        vc.upload = false
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
    
    
    @IBAction func addTapped(_ sender: Any) {
        if patientIdFiled.text ?? "" !=  "" && nameFiled.text ?? "" != "" {
            addPatient()
        }else {
            if let navigation = self.navigationController  {
                DataManager.shared.sendMessage(title: "Alert", message: "Fill empty fields", navigation: navigation)
            }
           
        }
        
    }
    
  
    
    
    @IBAction func addpatientViewvideos(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "")
        as! AddVideosController
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
    @IBAction func addImagetap(_ sender: Any) {
        
        
        if patientIdFiled.text ?? "" != "" {
            profileUploadImage = false
            presentImagePicker()
        }else {
            DispatchQueue.main.async {
                if let navigation = self.navigationController  {
                DataManager.shared.sendMessage(title: "Alert", message: "Fill Patient id field", navigation: navigation)
            }
            }
        }
       
        
        
    }
    
    func presentImagePicker() {
           let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
           alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
               self.openCamera()
           }))
           alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
               self.openGallery()
           }))
           alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
           present(alert, animated: true, completion: nil)
       }
       
       
    
       
       func openCamera() {
           if UIImagePickerController.isSourceTypeAvailable(.camera) {
               imagePicker.sourceType = .camera
               present(imagePicker, animated: true, completion: nil)
           } else {
               print("Camera not available")
           }
       }
       
       func openGallery() {
           imagePicker.sourceType = .photoLibrary
           present(imagePicker, animated: true, completion: nil)
       }

       func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
             if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
                
                 if profileUploadImage == false {
                     imageview.image = pickedImage
                     selectedProfileImage.append(pickedImage)
                    // addImageTobackEnd()
                 }else {
                     profileImage.image = pickedImage
                     selectedImage.append(pickedImage)
                    // uploadProfile()
                 }
                    
                
                
                
             }
             
             picker.dismiss(animated: true, completion: nil)
         }
       func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
           picker.dismiss(animated: true, completion: nil)
       }
    
    
    @IBAction func addvideostopatient(_ sender: Any) {
        
       
    }
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    
}

