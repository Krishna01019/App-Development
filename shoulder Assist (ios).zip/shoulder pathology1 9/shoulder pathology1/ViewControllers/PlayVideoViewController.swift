//
//  PlayVideoViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 09/02/24.
//

import UIKit
import AVFoundation
import AVKit

class PlayVideoViewController: UIViewController {
    
    
    @IBOutlet weak var subView: UIView!
    
       
    var videoUrl = String()

      
     
        
        var player: AVPlayer?
        var playerLayer: AVPlayerLayer?
        var captureSession: AVCaptureSession!
        var name = ""
        var descriptionName = ""
       
        var isPlaying = true
        
        override func viewDidLoad() {
            super.viewDidLoad()
        
            DispatchQueue.main.async {
                self.playVideo(with: self.videoUrl)
            }
    
        
    }


func playVideo(with url: String) {
    
        let base = ServiceAPI.baseURL + url
    print("base :\(base)")

       guard let videoURL = URL(string: "\(base)") else {
           print("Invalid video URL")
         
           return
       }
      print("videoURL : \(videoURL)")
       player = AVPlayer(url: videoURL)
       
       guard let player = player else {
           //  print("Failed to initialize AVPlayer")
           return
       }
       
       let playerViewController = AVPlayerViewController()
       playerViewController.player = player
       playerViewController.entersFullScreenWhenPlaybackBegins = false
       playerViewController.allowsPictureInPicturePlayback = false
       
       addChild(playerViewController)
    subView.addSubview(playerViewController.view)
       playerViewController.view.frame = subView.bounds
       playerViewController.didMove(toParent: self)
       
       // Add observer for player status
       player.addObserver(self, forKeyPath: #keyPath(AVPlayer.status), options: .new, context: nil)
   }

   // Implement key-value observation method
   override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
       if keyPath == #keyPath(AVPlayer.status) {
           if let player = player {
               if player.status == .failed {
                   if let error = player.error {
                       print("Failed to load video: \(error)")
                   } else {
                       //print("Failed to load video with an unknown error.")
                   }
               }else {
                   player.play()
               }
           } else {
              // print("AVPlayer is nil.")
           }
       }
   }

    
    
    
        @IBAction func backBtn(_ sender: Any) {
            
            self.navigationController?.popViewController(animated: true)
        }
    
  

    @IBAction func backTap(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
}
