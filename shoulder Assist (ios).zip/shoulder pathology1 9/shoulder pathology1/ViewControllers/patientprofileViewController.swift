//
//  patientprofileViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 27/01/24.
//

import UIKit

class patientprofileViewController: UIViewController {
    
    @IBOutlet weak var profile: UIImageView!
    
    @IBOutlet weak var patientnamelabel: UILabel!
    
   
    @IBOutlet weak var phonenumberlabel: UILabel!
    
    @IBOutlet weak var patientidlabel: UILabel!
    
    @IBOutlet weak var agelabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.profile.layer.cornerRadius = 45
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
          super.viewWillAppear(true)
          self.tabBarController?.tabBar.isHidden = false
          
        patientDeatils()
        
       
       
      }
    

    func patientDeatils() {
          
        let formData = ["patient_id": DataManager.shared.patinetId]
          
          APIHandler().postAPIValues(type: PatientProfileDetails.self, apiUrl: ServiceAPI.patientProfileURL , method: "POST", formData: formData) { [weak self] result in
                       switch result {
                       case .success(let data):
                          print(data)
                          DispatchQueue.main.async {
                              if data.success == true {
                                  self?.patientDeatilsImage()
                                  self?.patientidlabel.text = data.data.patientID
                             self?.patientnamelabel.text = data.data.name
                                  self?.phonenumberlabel.text = "\(data.data.phoneNumber)"
                                  self?.agelabel.text = "\(data.data.age)"
                                
                                
                              }else {
                              if let navigation = self?.navigationController  {
                                  DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                              }
                              }
                          }
                       case .failure(let error):
                          print(error)
                          DispatchQueue.main.async {
                          if let navigation = self?.navigationController  {
                              DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                          }
                          }
                       }
            }

      }
    
    
    func patientDeatilsImage() {
          
        let formData = ["patient_id": DataManager.shared.patinetId]
          
          APIHandler().postAPIValues(type: ImageRet.self, apiUrl: ServiceAPI.imageRet , method: "POST", formData: formData) { [weak self] result in
                       switch result {
                       case .success(let data):
                          print(data)
                          DispatchQueue.main.async {
                              if data.status == "success" {
                                  self?.loadImage(url: data.data.first?.image ?? "", imageView: self?.profile)
                                
                              }else {
                              if let navigation = self?.navigationController  {
                                  DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                              }
                              }
                          }
                       case .failure(let error):
                          print(error)
                          DispatchQueue.main.async {
                          if let navigation = self?.navigationController  {
                              DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                          }
                          }
                       }
            }

      }

    @IBAction func logoutbtn(_ sender: Any) {
        
    }

    @IBAction func patientlogout(_ sender: Any) {
      

    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
        
    }
}




//func doctorLogin() {
//            
//            
//            let formData = ["doctor_id": doctorId.text ?? "",
//                            "password": passwordField.text ?? ""]
//   
//
//    APIHandler().postAPIValues(type: DoctorLogin.self, apiUrl: ServiceAPI.doctorLoginURL , method: "POST", formData: formData) { [weak self] result in
//                         switch result {
//                         case .success(let data):
//                            print(data)
//                            DispatchQueue.main.async {
//                                if data.success == true {
//                                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//                                    let vc = storyBoard.instantiateViewController(withIdentifier: "doctorhomeViewController")
//                                    as! doctorhomeViewController
//                                    self?.navigationController?.pushViewController(vc, animated:true)
//                                    
//                                }else {
//                                if let navigation = self?.navigationController  {
//                                    DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
//                                }
//                                   
//                                   
//                                }
//                            }
//                         case .failure(let error):
//                            print(error)
//                            DispatchQueue.main.async {
//                            if let navigation = self?.navigationController  {
//                                DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
//                            }
//                            }
//                         }
//                        
//        }
//                 
// 
//        
//}
