//
//  patientvideoViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 25/01/24.
//

import UIKit

class patientvideoViewController: UIViewController {
    
    
    @IBOutlet weak var collectionVIEW: UICollectionView!
    
    
    var header = String()
    
    var videosList = [ListOfVideos]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let cel = UINib(nibName: "PatientVideoCell", bundle: nil)
        collectionVIEW.register(cel, forCellWithReuseIdentifier: "cell")
        
        // did load

         let layout = CustomVerticalFlow()
        collectionVIEW.collectionViewLayout = layout
        
        
        videosListApi()
    }
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    
    @IBAction func nextTap(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
    
    
    func videosListApi() {
                
                
                let formData = ["": ""]
        
        
        
        APIHandler().getAPIValues(type: GetVideos.self, apiUrl: ServiceAPI.listVideos+header, method: "GET", onCompletion: { result in
        

//        APIHandler().postAPIValues(type: GetVideos.self, apiUrl: ServiceAPI.listVideos+header , method: "POST", formData: formData) { [weak self] result in
                             switch result {
                             case .success(let data):
                                print(data)
                                DispatchQueue.main.async {
                                    if data.status == true {
                                        self.videosList = data.data
                                        self.collectionVIEW.reloadData()
                                        
                                    }else {
                                    if let navigation = self.navigationController  {
                                        DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                                    }
                                       
                                       
                                    }
                                }
                             case .failure(let error):
                                print(error)
                                DispatchQueue.main.async {
                                if let navigation = self.navigationController  {
                                    DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                                }
                                }
                             }
                            
            }
                     
     
            
    )}

   

}



extension patientvideoViewController: UICollectionViewDelegate,UICollectionViewDataSource {


func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return self.videosList.count
    
}

func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! PatientVideoCell
    cell.titleLbl.text = self.videosList[indexPath.item].title
    
     let urlString =  self.videosList[indexPath.item].url
        if let url = URL(string: urlString) {
    DataManager.shared.generateThumbnail(for: url) { thumbnail in
           if let thumbnailImage = thumbnail {
              
               cell.imageView.image = thumbnailImage
           }
       }
        }
    
    return cell
}
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "PlayVideoViewController")
        as! PlayVideoViewController
        vc.videoUrl = self.videosList[indexPath.item].url
        self.navigationController?.pushViewController(vc, animated:true)

    }
    

}


class CustomVerticalFlow: UICollectionViewFlowLayout {
   override func prepare() {
       super.prepare()
       guard let collectionView = collectionView else { return }
       minimumLineSpacing = 10.0
       minimumInteritemSpacing = 10.0
       let availableWidth = collectionView.bounds.width - sectionInset.left - sectionInset.right - minimumInteritemSpacing
       let cellWidth = (availableWidth - minimumInteritemSpacing) / 1.0
       itemSize = CGSize(width: cellWidth, height: 200.0)
   }
}
//func doctorLogin() {
//            
//            
//            let formData = ["doctor_id": doctorId.text ?? "",
//                            "password": passwordField.text ?? ""]
//   
//
//    APIHandler().postAPIValues(type: DoctorLogin.self, apiUrl: ServiceAPI.doctorLoginURL , method: "POST", formData: formData) { [weak self] result in
//                         switch result {
//                         case .success(let data):
//                            print(data)
//                            DispatchQueue.main.async {
//                                if data.success == true {
//                                    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//                                    let vc = storyBoard.instantiateViewController(withIdentifier: "doctorhomeViewController")
//                                    as! doctorhomeViewController
//                                    self?.navigationController?.pushViewController(vc, animated:true)
//                                    
//                                }else {
//                                if let navigation = self?.navigationController  {
//                                    DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
//                                }
//                                   
//                                   
//                                }
//                            }
//                         case .failure(let error):
//                            print(error)
//                            DispatchQueue.main.async {
//                            if let navigation = self?.navigationController  {
//                                DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
//                            }
//                            }
//                         }
//                        
//        }
//                 
// 
//        
//}
