//
//  patienttodaytaskViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 25/01/24.
//

import UIKit

class patienttodaytaskViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    
    }
    
    @IBAction func rangeofmovments(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "patientvideoViewController")
        as! patientvideoViewController
        vc.header = "video.php"
        self.navigationController?.pushViewController(vc, animated:true)
        
    }
    
    
    @IBAction func strechesTapped(_ sender: Any) {
      
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "patientvideoViewController")
        as! patientvideoViewController
        vc.header = "1.php"
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
    @IBAction func strenthTapped(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "patientvideoViewController")
        as! patientvideoViewController
        vc.header = "2.php"
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
    @IBAction func protocolsTap(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "ProtocolViewController")
        as! ProtocolViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
    
    
}
