//
//  DoctorLoginViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 29/12/23.
//

import UIKit

class DoctorLoginViewController: UIViewController {
    
    @IBOutlet weak var gradientView2: UIView!
    
    @IBOutlet var gradientView1: UIView!
    @IBOutlet weak var subView: UIView!
    

    @IBOutlet weak var doctorId: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var loginBtn: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        subView.layer.cornerRadius = 15
        loginBtn.layer.cornerRadius = 20
        gradientView1.applyGradient(colors: [UIColor(red: 0.44, green: 0.64, blue: 0.88, alpha: 1.00).cgColor,UIColor(red: 0.20, green: 0.76, blue: 0.66, alpha: 1.00).cgColor]
)
        gradientView2.applyGradient(colors: [UIColor(red: 0.44, green: 0.64, blue: 0.88, alpha: 1.00).cgColor,UIColor(red: 0.20, green: 0.76, blue: 0.66, alpha: 1.00).cgColor]
)
        }
    
    
    
    
    func doctorLogin() {
                
                
                let formData = ["doctor_id": doctorId.text ?? "",
                                "password": passwordField.text ?? ""]
       

        APIHandler().postAPIValues(type: DoctorLogin.self, apiUrl: ServiceAPI.doctorLoginURL , method: "POST", formData: formData) { [weak self] result in
                             switch result {
                             case .success(let data):
                                print(data)
                                DispatchQueue.main.async {
                                    if data.success == true {
                                        DataManager.shared.doctorId = self?.doctorId.text ?? ""
                                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                                        let vc = storyBoard.instantiateViewController(withIdentifier: "doctorhomeViewController")
                                        as! doctorhomeViewController
                                        self?.navigationController?.pushViewController(vc, animated:true)
                                        
                                    }else {
                                    if let navigation = self?.navigationController  {
                                        DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                                    }
                                       
                                       
                                    }
                                }
                             case .failure(let error):
                                print(error)
                                DispatchQueue.main.async {
                                if let navigation = self?.navigationController  {
                                    DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                                }
                                }
                             }
                            
            }
                     
     
            
    }
        
        
        

    @IBAction func loginTap(_ sender: Any) {
        if doctorId.text != "" && passwordField.text != "" {
          doctorLogin()
        }
    }
    
    @IBAction func backTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: false)
    }
    
}
//extension UIView {
//    func applyGradient(colors : [CGColor]) {
//        let gradientlayer = CAGradientLayer()
//        gradientlayer.colors = colors
//        gradientlayer.startPoint = CGPoint(x: 0, y:0)
//        gradientlayer.endPoint = CGPoint(x: 1, y: 1)
//        gradientlayer.frame = bounds
//        layer.insertSublayer(gradientlayer, at: 0)
//    }
//}
extension UIView {
    func applyGradient(colors: [CGColor]) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = colors
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = bounds
        layer.insertSublayer(gradientLayer, at: 0)
        
        // Add observer for bounds changes
        addObserver(self, forKeyPath: "bounds", options: .new, context: nil)
    }
    
    // Observe bounds changes
    override open func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "bounds" {
            if let gradientLayer = layer.sublayers?.first as? CAGradientLayer {
                gradientLayer.frame = bounds
            }
        }
    }
}

//[UIColor(red: 0.44, green: 0.64, blue: 0.88, alpha: 1.00).cgColor,UIColor(red: 0.20, green: 0.76, blue: 0.66, alpha: 1.00).cgColor]
