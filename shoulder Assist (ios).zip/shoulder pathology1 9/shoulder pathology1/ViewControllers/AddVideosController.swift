//
//  AddVideosController.swift
//  shoulder pathology1
//
//  Created by SAIL on 29/12/23.
//

import UIKit

class AddVideosController: UIViewController {
    
    
    @IBOutlet weak var addbtn: UIButton!
    
    @IBOutlet weak var videoCollectionView: UICollectionView!
    
    @IBOutlet weak var addBtnCurve: UIButton!
    
    var num = 25
    
    
    var videosList = [ListOfVideos]()
    
    var header = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        addBtnCurve.layer.cornerRadius = 15
//

        let cel = UINib(nibName: "VideoCell", bundle: nil)
        videoCollectionView.register(cel, forCellWithReuseIdentifier: "cell")
        
        // did load

         let layout = CustomVerticalFlowLayout()
        videoCollectionView.collectionViewLayout = layout
        //
        videosListApi()
    }
    
    
    
    @IBAction func addtap(_ sender: Any) {
        
        var nums = 1
        num = nums + 1
        videoCollectionView.reloadData()
    }
    
    func videosListApi() {
                
                
               
        
        APIHandler().getAPIValues(type: GetVideos.self, apiUrl: ServiceAPI.listVideos+header, method: "GET", onCompletion: { result in
        
                             switch result {
                             case .success(let data):
                                print(data)
                                DispatchQueue.main.async {
                                    if data.status == true {
                                        self.videosList = data.data
                                        self.videoCollectionView.reloadData()
                                        
                                    }else {
                                    if let navigation = self.navigationController  {
                                        DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                                    }
                                       
                                       
                                    }
                                }
                             case .failure(let error):
                                print(error)
                                DispatchQueue.main.async {
                                if let navigation = self.navigationController  {
                                    DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                                }
                                }
                             }
                            
            })
                     
     
                                  }
    
    
    
    @IBAction func backBtnTap(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: false)
    }
    
  
}
extension AddVideosController: UICollectionViewDelegate,UICollectionViewDataSource {
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.videosList.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! VideoCell
        cell.videoHeader.text =  self.videosList[indexPath.item].title
        
     
       
         let urlString =  self.videosList[indexPath.item].url
            if let url = URL(string: urlString) {
        DataManager.shared.generateThumbnail(for: url) { thumbnail in
               if let thumbnailImage = thumbnail {
                  
                   cell.imageView.image = thumbnailImage
               }
           }
            }
        
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "PlayVideoViewController")
        as! PlayVideoViewController
        vc.videoUrl = self.videosList[indexPath.item].url 
        self.navigationController?.pushViewController(vc, animated:true)

    }
    
    

    
    
    
}



class CustomVerticalFlowLayout: UICollectionViewFlowLayout {
   override func prepare() {
       super.prepare()
       guard let collectionView = collectionView else { return }
       minimumLineSpacing = 10.0
       minimumInteritemSpacing = 10.0
       let availableWidth = collectionView.bounds.width - sectionInset.left - sectionInset.right - minimumInteritemSpacing
       let cellWidth = (availableWidth - minimumInteritemSpacing) / 1.0
       itemSize = CGSize(width: cellWidth, height: 200.0)
   }
}



