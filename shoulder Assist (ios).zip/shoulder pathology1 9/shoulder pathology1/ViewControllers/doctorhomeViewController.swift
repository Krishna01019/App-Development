//
//  doctorhomeViewController.swift
//  shoulder pathology1
//
//  Created by SAIL on 03/01/24.
//

import UIKit

class doctorhomeViewController: UIViewController,SideMenuDelegate {
   
    

    @IBOutlet weak var addPatientcurve: UIButton!
    
    @IBOutlet weak var listOfPatientCurve: UIButton!
    
    @IBOutlet weak var viewVideosCurve: UIButton!
    
    @IBOutlet weak var subView: UIView!
    @IBOutlet weak var patientListTable: UITableView!
    
   
    var patientListDetails:PatientList?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        subView.layer.cornerRadius = 10
        addPatientcurve.layer.cornerRadius=15
        listOfPatientCurve.layer.cornerRadius=15
        viewVideosCurve.layer.cornerRadius=15
   
        
        
      
       
        let cell = UINib(nibName: "PatientCellCell", bundle: nil)
        patientListTable.register(cell, forCellReuseIdentifier: "cell")
    }
 
    
    
    override func viewWillAppear(_ animated: Bool) {
           super.viewWillAppear(true)
        patientListApi()
       }
       
       
       
       func patientListApi() {
           var formData = [String: String]()


           APIHandler().postAPIValues(type: PatientList.self, apiUrl: ServiceAPI.patinetListURL, method: "POST", formData: formData) { [weak self] result in
                        switch result {
                        case .success(let data):
                           print(data)
                           DispatchQueue.main.async {
                               if data.success == true {
                               self?.patientListDetails = data
                              self?.patientListTable.reloadData()
                               }else {
                               if let navigation = self?.navigationController  {
                                   DataManager.shared.sendMessage(title: "Alert", message: "Already Exist", navigation: navigation)
                               }
                               }
                           }
                        case .failure(let error):
                           print(error)
                           DispatchQueue.main.async {
                           if let navigation = self?.navigationController  {
                               DataManager.shared.sendMessage(title: "Alert", message: "Error", navigation: navigation)
                           }
                           }
                        }
                       
       }
                
       }
    
    
    func tap(index: Int) {
        if index == 1 {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "doctorprofileViewController")
            as! doctorprofileViewController
            self.navigationController?.pushViewController(vc, animated:true)
        }else {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "doctorpatientloginViewController")
            as! doctorpatientloginViewController
            self.navigationController?.pushViewController(vc, animated:true)
        }
    }

    

 
    @IBAction func addpatient(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "addpatientpageViewController")
        as! addpatientpageViewController
        self.navigationController?.pushViewController(vc, animated:true)
        
    }
    @IBAction func addVideos(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "docaddVideosViewController")
        as! addpatientpageViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
    
    @IBAction func patientListBtn(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "PatinetListViewController")
        as! PatinetListViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
    @IBAction func doctorprofile(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "SideMenuViewController")
        as! SideMenuViewController
        vc.delegate = self
        vc.modalPresentationStyle = .overFullScreen
        self.navigationController?.present(vc, animated: false)
    }

    @IBAction func viewVideosbtn(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "docaddVideosViewController")
        as! docaddVideosViewController
        vc.upload = true
        self.navigationController?.pushViewController(vc, animated:true)
    }
}
extension doctorhomeViewController: UITableViewDelegate,UITableViewDataSource {
  
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let patientListDetails = self.patientListDetails else {
            return 0
        }
        let count = patientListDetails.data.count
        return min(count, 5)
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! PatientCellCell
        
        
        guard let patientListDetails = self.patientListDetails else {
                return cell
            }

           
        let index = patientListDetails.data.count - 5 + indexPath.row
           
            guard index >= 0 && index < patientListDetails.data.count else {
                return cell
            }
            
        let all =  self.patientListDetails?.data[index]

        cell.name.text = all?.name
           cell.id.text = all?.patientID
            
            let str = all?.dp ?? ""
            if let imageData = Data(base64Encoded: str) {
                if let image = UIImage(data: imageData) {
            loadImageData(data: image, imageView: cell.profileImage)
            }
        }
           return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
           return 100.0
        }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "patientdetailsViewController") as? patientdetailsViewController {
            vc.newPatientId = patientListDetails?.data[indexPath.row].patientID ?? ""
            navigationController?.pushViewController(vc, animated: true)
        }
       }

    }



