//
//  CVC1.swift
//  shoulder pathology1
//
//  Created by SAIL on 28/10/23.
//

import UIKit

class CVC1: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
