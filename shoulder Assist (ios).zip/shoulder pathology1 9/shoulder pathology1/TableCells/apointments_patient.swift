//
//  apointments_patient.swift
//  shoulder pathology1
//
//  Created by SAIL on 14/12/23.
//

import UIKit

class apointments_patient: UITableViewCell {

    @IBOutlet weak var Time: UILabel!
    @IBOutlet weak var Date: UILabel!
    @IBOutlet weak var doc_id: UILabel!
    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var appointment_patient: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    override func layoutSubviews() {
      super.layoutSubviews()
       
     let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
      contentView.frame = contentView.frame.inset(by: margin)
        contentView.layer.cornerRadius = 5
    }
    
}
