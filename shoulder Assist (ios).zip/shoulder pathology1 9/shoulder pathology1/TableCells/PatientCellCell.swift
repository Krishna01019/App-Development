//
//  PatientCellCell.swift
//  shoulder pathology1
//
//  Created by SAIL on 29/12/23.
//

import UIKit

class PatientCellCell: UITableViewCell {
    
    
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var name: UILabel!
    
    
    @IBOutlet weak var id: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    override func layoutSubviews() {
      super.layoutSubviews()
       
     let margin = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
      contentView.frame = contentView.frame.inset(by: margin)
        contentView.layer.cornerRadius = 5
    }
    
}
