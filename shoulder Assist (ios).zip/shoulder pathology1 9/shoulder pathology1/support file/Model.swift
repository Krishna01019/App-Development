//
//  Model.swift
//  shoulder pathology1
//
//  Created by SAIL on 29/01/24.
//

import Foundation


struct DoctorLogin:Codable {
    var success:Bool
    var message:String
}


struct DailyTask:Codable {
    var status:String
    var message:String
}


struct AddPatient: Codable {
    let userPasswordUpdated, userInserted, addpatientInserted, patientsdetailsInserted: Bool
    let pProfileInserted: Bool

    enum CodingKeys: String, CodingKey {
        case userPasswordUpdated = "user_password_updated"
        case userInserted = "user_inserted"
        case addpatientInserted = "addpatient_inserted"
        case patientsdetailsInserted = "patientsdetails_inserted"
        case pProfileInserted = "p_profile_inserted"
    }
}


struct PatientList: Codable {
    let success: Bool
    let data: [Datum]
}

struct Datum: Codable {
    let patientID, name, dp: String

    enum CodingKeys: String, CodingKey {
        case patientID = "patient_id"
        case name
        case dp
    }
}
struct PatientProfileDetails: Codable {
    let success: Bool
    let data: DataClass
    let message: String
}

// MARK: - DataClass
struct DataClass: Codable {
    let sNo: Int
    let patientID, name: String

    let age: Int
    let gender: String
    let phoneNumber: Int

    enum CodingKeys: String, CodingKey {
        case sNo = "s.no"
        case patientID = "patient_id"
        case name, age, gender
        case phoneNumber = "phone_number"
    }
}


struct doctorProfileDetails: Codable {
    let success: Bool
    let data: DoctorData
    let message: String
}

// MARK: - DataClass
struct DoctorData: Codable {
    let sNo: Int
    let doctorID, name: String
    let spaciality: String
    let phoneNumber: String
    enum CodingKeys: String, CodingKey {
        case sNo = "s.no"
        case doctorID = "doctor_id"
        case name, spaciality
        case phoneNumber = "phone_number"
    }
}



struct Patient: Codable {
    let sNo: Int
    let patientID, name: String
    let age: Int
    let gender, phoneNumber: String
    let admittedOn: String
    let diagnosis, examination, briefHistory: String

    enum CodingKeys: String, CodingKey {
        case sNo = "s.no"
        case patientID = "patient_id"
        case name, age, gender
        case phoneNumber = "phone_number"
        case admittedOn = "admitted_on"
        case diagnosis, examination
        case briefHistory = "brief_history"
    }
}

typealias PatientDetails = [Patient]


//struct ListOfVideos: Codable {
//    let status: String
//    let videos:[VideosList]
//}
//struct VideosList: Codable {
//    var video_path:String
//    var video_title:String
//
//}

//struct ListOfVideos: Codable {
//    let status: String
//    let videos: [VideosList]
//}
//
//struct VideosList: Codable {
//    let videoPath, videoTitle: String
//
//    enum CodingKeys: String, CodingKey {
//        case videoPath = "video_path"
//        case videoTitle = "video_title"
//    }
//}


struct GetVideos: Codable {
    let status: Bool
    let message: String
    let data: [ListOfVideos]
}

// MARK: - Datum
struct ListOfVideos: Codable {
    let url, title: String
}
struct newListOfVideos: Codable {
    let status: Bool
    let message: String
    let data: [newVideosList]
}

// MARK: - Datum
struct newVideosList: Codable {
    let url, title: String
}



struct ViewTask: Codable {
    let status: String
    let data: ViewTaskData
   }

 struct ViewTaskData: Codable {
        let feedback, rangeOfMovement, stretches, strengtheningExercise: String

        enum CodingKeys: String, CodingKey {
            case feedback
            case rangeOfMovement = "range_of_movement"
            case stretches
            case strengtheningExercise = "strengthening_exercise"
    }
}

//    let status: String
//    let taskData: TaskData
//    let feedbackData: FeedbackData
//
//    enum CodingKeys: String, CodingKey {
//        case status
//        case taskData = "task_data"
//        case feedbackData = "feedback_data"
//    }
//}
//
//struct FeedbackData: Codable {
//    let id, yesNo, feedback, date1: String
//
//    enum CodingKeys: String, CodingKey {
//        case id
//        case yesNo = "yes/no"
//        case feedback, date1
//    }
//}

struct TaskData: Codable {
    let patientID, date, rangeOfMovement, stretches: String
    let strengtheningExercises: String

    enum CodingKeys: String, CodingKey {
        case patientID = "patient_id"
        case date
        case rangeOfMovement = "range_of_movement"
        case stretches
        case strengtheningExercises = "Strengthening_exercises"
    }
}


struct GetImages: Codable {
    
    let status: String
    let message:String
    let data:[ImageData]
}
struct ImageData:Codable {
    let patient_id:String
    let image:String
}


struct RetriveScore: Codable {
    
    let status: String
    let data:[ScoreData]
}

struct ScoreData:Codable {
    let date:String
    let total_score:Int
}



struct ImageRet: Codable {
    let status, message: String
    let data: [ImageRetdata]
}

struct ImageRetdata: Codable {
    let patientID, image: String

    enum CodingKeys: String, CodingKey {
        case patientID = "patient_id"
        case image
    }
}
