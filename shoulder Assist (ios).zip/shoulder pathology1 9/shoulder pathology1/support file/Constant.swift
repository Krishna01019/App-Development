//
//  Constant.swift
//  shoulder pathology1
//
//  Created by SAIL on 30/01/24.




import Foundation
import UIKit


struct ServiceAPI {

   static let baseURL = "http://192.168.195.195/Shoulder/"
   static let doctorLoginURL = baseURL+"d_login.php"
   static let patientLoginURL = baseURL+"patient_login.php"
   static let addPatinetURL = baseURL+"addpatient.php"
   static let patinetListURL = baseURL+"patientlist.php"
   static let patientProfileURL = baseURL+"p_profile.php"
   static let doctorProfileURL = baseURL+"d_profile.php"
   static let patientDetailsURL = baseURL+"patientdetails.php"
   static let listVideos = baseURL+"display"
   static let dailyTaskURL = baseURL+"daily_task.php"
   static let taskretriveURL = baseURL+"retDis.php"
   static let uploadImaage = baseURL+"iosimg.php"
   static let retriveImage = baseURL+"iosimgret.php"
   static let uploadVideo = baseURL+"videos"
   static let scoreDisplay = baseURL+"score_display.php"
   static let scoreUpdate = baseURL+"score.php"
   static let dpUpload = baseURL+"iosdp.php"
    static let imageRet = baseURL+"iosdpret.php"
    static let profileImaage = baseURL+"iosdp.php"


}


extension UIViewController {
    
   
    class LoadingIndicator {

        static let shared = LoadingIndicator()

        private let activityIndicator: UIActivityIndicatorView = {
            let indicator = UIActivityIndicatorView(style: .large)
            indicator.color = .red
            indicator.hidesWhenStopped = true
            return indicator
        }()

        private init() {}

        func showLoading(on view: UIView) {
            DispatchQueue.main.async {
                self.activityIndicator.center = view.center
                view.addSubview(self.activityIndicator)
                self.activityIndicator.startAnimating()
            }
        }

        func hideLoading() {
            DispatchQueue.main.async {
                self.activityIndicator.stopAnimating()
                self.activityIndicator.removeFromSuperview()
            }
        }
    }
  
      



}
