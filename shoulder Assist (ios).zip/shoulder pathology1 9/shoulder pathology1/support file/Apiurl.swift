//
//  Apiurl.swift
//  shoulder pathology1
//
//  Created by SAIL on 29/01/24.
//

import Foundation




struct ServiceAPI {

static let baseURL = "http://172.20.10.10/Shoulder/"

static let doctorLoginURL = baseURL+"d_login.php"
}
