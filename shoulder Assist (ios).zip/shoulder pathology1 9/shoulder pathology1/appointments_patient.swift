//
//  appointments_patient.swift
//  shoulder pathology1
//
//  Created by SAIL on 14/12/23.
//

import UIKit

class appointments_patient: UIViewController {
    
    
    
    @IBOutlet weak var appoinmentTable: UITableView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
     
    let cell = UINib(nibName:"apointments_patient", bundle: nil)
    appoinmentTable.register(cell, forCellReuseIdentifier: "cell")
        
        
      
        
    }
    

    @IBAction func plusBtnTapped(_ sender: Any) {
        
        
        
    }
    

}
extension appointments_patient: UITableViewDelegate,UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! apointments_patient
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }
    
}



